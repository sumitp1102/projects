class apb_driver extends uvm_driver #(apb_trans);
	
	`uvm_component_utils(apb_driver)

	virtual apb_if.APB_DRV vif;

	apb_agent_config apb_agt_cfg;

	function new(string name="apb_driver", uvm_component parent);
		super.new(name, parent);
	endfunction
		
	function void build_phase(uvm_phase phase);

		if(!uvm_config_db #(apb_agent_config)::get(this, "", "apb_agent_config", apb_agt_cfg))
			`uvm_fatal("APB DRV","GET CONFIG FAILED")
		

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=apb_agt_cfg.vif;
	endfunction

	task reset_dut;

		@(vif.apb_drv_cb);
		vif.apb_drv_cb.presetn<=1'b0;
		repeat(3)
			@(vif.apb_drv_cb);
		vif.apb_drv_cb.presetn<=1'b1;
	
	endtask

	task send_to_dut(apb_trans xtn);
	
        
		vif.apb_drv_cb.presetn<=1'b1;
		vif.apb_drv_cb.paddr<=xtn.paddr;
		vif.apb_drv_cb.pwrite<=xtn.pwrite;
		vif.apb_drv_cb.pselx<=1'b1;
		vif.apb_drv_cb.penable<=1'b0;
		if(xtn.pwrite)
			vif.apb_drv_cb.pwdata<=xtn.pwdata;


		@(vif.apb_drv_cb);
		vif.apb_drv_cb.penable<=1'b1;

		wait(vif.apb_drv_cb.pready)
		if(!xtn.pwrite)
			xtn.prdata=vif.apb_drv_cb.prdata;

		vif.apb_drv_cb.pselx<=1'b0;
		vif.apb_drv_cb.penable<=1'b0;
		@(vif.apb_drv_cb);

		`uvm_info("APB DRV", $sformatf("DATA FROM APB DRIVER : %s", xtn.sprint()), UVM_NONE)
		
		
		

	endtask
	

	task run_phase(uvm_phase phase);

		reset_dut;
		forever
		begin
			seq_item_port.get_next_item(req);
			send_to_dut(req);
			seq_item_port.item_done();
		end

	endtask

endclass

