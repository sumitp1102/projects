class apb_monitor extends uvm_monitor;

	`uvm_component_utils(apb_monitor)

	apb_agent_config apb_agt_cfg;

	virtual apb_if.APB_MON vif;
	
	apb_trans xtn;
	
	uvm_analysis_port #(apb_trans) analysis_port;

	function new(string name="apb_monitor", uvm_component parent);
		super.new(name, parent);
		analysis_port=new("analysis_port", this);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

		if(!uvm_config_db #(apb_agent_config)::get(this, "", "apb_agent_config", apb_agt_cfg))
			`uvm_fatal("APB MON","GET CONFIG FAILED")

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=apb_agt_cfg.vif;
	endfunction

	task collect_data;

		xtn=apb_trans::type_id::create("xtn");
	
	
		wait(vif.apb_mon_cb.penable && vif.apb_mon_cb.pready)
		
		xtn.presetn=vif.apb_mon_cb.presetn;
		xtn.paddr=vif.apb_mon_cb.paddr;
		xtn.pwrite=vif.apb_mon_cb.pwrite;
		xtn.pselx=vif.apb_mon_cb.pselx;
		xtn.penable=vif.apb_mon_cb.penable;

		if(vif.apb_mon_cb.pwrite)
			xtn.pwdata=vif.apb_mon_cb.pwdata;
		else
			xtn.prdata=vif.apb_mon_cb.prdata;

		xtn.pready=vif.apb_mon_cb.pready;
		xtn.pslverr=vif.apb_mon_cb.pslverr;
		
		
		@(vif.apb_mon_cb);
		`uvm_info("APB_MON", $sformatf("DATA FROM APB MONITOR IS : %s", xtn.sprint), UVM_NONE)

		analysis_port.write(xtn);

		
	
	endtask

	task run_phase(uvm_phase phase);
		
		forever
			collect_data;

	endtask

endclass
