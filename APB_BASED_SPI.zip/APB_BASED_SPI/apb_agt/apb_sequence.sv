class apb_sequence extends uvm_sequence #(apb_trans);

	`uvm_object_utils(apb_sequence)
	
	env_config env_cfg;
	spi_reg_block spi_rg_blk;

	uvm_status_e status;
	logic [7:0] data1, data2, data3, data4, data5;
	bit [7:0] cr1;

	function new(string name="apb_sequence");
		super.new(name);
	endfunction

	task body();
		
		if(! uvm_config_db #(env_config)::get(null, get_full_name(), "env_config", env_cfg))
			`uvm_fatal("APB_SEQ", "GET ENV CONFIG FAILED")

		spi_rg_blk=env_cfg.spi_rg_blk;
	endtask


endclass

class apb_reset_sequence extends apb_sequence;

	`uvm_object_utils(apb_reset_sequence)
	

	function new(string name="apb_reset_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr==3'd0;});
				finish_item(req);
			end
	
	
			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr==3'd1;});
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr==3'd2;});
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr==3'd3;});
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr==3'd5;});
				finish_item(req);
			end
		end
	endtask

endclass


class apb_read_sequence extends apb_sequence;

	`uvm_object_utils(apb_read_sequence)

	function new(string name="apb_read_sequence");
		super.new(name);
	endfunction

	task body();
		
		super.body();

		repeat(1)
		begin
			req=apb_trans::type_id::create("req");
			start_item(req);
			assert(req.randomize() with {req.presetn==1; req.pwrite==0; req.paddr==5;});
			finish_item(req);
		end
	endtask

endclass


class apb_cpha1_cpol1_lsb1_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha1_cpol1_lsb1_sequence)

		

	function new(string name="apb_cpha1_cpol1_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass



class apb_cpha1_cpol0_lsb1_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha1_cpol0_lsb1_sequence)

		

	function new(string name="apb_cpha1_cpol0_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass

class apb_cpha0_cpol1_lsb1_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha0_cpol1_lsb1_sequence)

		

	function new(string name="apb_cpha0_cpol1_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass

class apb_cpha0_cpol0_lsb1_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha0_cpol0_lsb1_sequence)

		

	function new(string name="apb_cpha0_cpol0_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass


class apb_cpha1_cpol1_lsb0_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha1_cpol1_lsb0_sequence)

		

	function new(string name="apb_cpha1_cpol1_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass



class apb_cpha1_cpol0_lsb0_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha1_cpol0_lsb0_sequence)

		

	function new(string name="apb_cpha1_cpol0_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass

class apb_cpha0_cpol1_lsb0_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha0_cpol1_lsb0_sequence)

		

	function new(string name="apb_cpha0_cpol1_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass

class apb_cpha0_cpol0_lsb0_sequence extends apb_sequence;

	`uvm_object_utils(apb_cpha0_cpol0_lsb0_sequence)

		

	function new(string name="apb_cpha0_cpol0_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass


class apb_low_power_sequence extends apb_sequence;

	`uvm_object_utils(apb_low_power_sequence)

	bit[1:0] low_power;

	function new(string name="apb_low_power_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[1:0])::get(null, get_full_name(), "low_power", low_power))
			`uvm_fatal("SPI_MON", "GET LOW POWER FAILED")


		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")



		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1010;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass


class apb_slv_low_power_sequence extends apb_sequence;

	`uvm_object_utils(apb_slv_low_power_sequence)

		

	function new(string name="apb_slv_low_power_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass


class apb_rand_sequence extends apb_sequence;

	`uvm_object_utils(apb_rand_sequence)

		

	function new(string name="apb_rand_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		if(!uvm_config_db #(bit[7:0])::get(null, get_full_name(), "spi_cr1_val", cr1))
			`uvm_fatal(get_type_name(), "GET SPI CR1 BIT CONFIG FAILED ")

		repeat(1)
		begin
			begin
				req=apb_trans::type_id::create("req");

				data1=cr1;
				data2=8'b0001_1000;
				data3=8'b0001_0001;

				start_item(req);

				assert(req.randomize() with {req.presetn==1'b1; req.pwrite==1'b0; req.paddr!=3'd5;});
		
				spi_rg_blk.spi_cr1.write(status, data1, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_cr2.write(status, data2, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
				spi_rg_blk.spi_baud.write(status, data3, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map), .parent(this));
	
				finish_item(req);
			end

			begin
				req=apb_trans::type_id::create("req");
				start_item(req);
				assert(req.randomize() with {req.presetn==1; req.pwrite==1; req.paddr==5;});
				finish_item(req);
			end

		end

	endtask
endclass







		
		


			

			

			
			

	




