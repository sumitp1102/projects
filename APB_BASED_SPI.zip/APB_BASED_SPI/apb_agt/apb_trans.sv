class apb_trans extends uvm_sequence_item;

	`uvm_object_utils(apb_trans)
	
	rand bit [2:0] paddr;
	rand bit [7:0] pwdata;
	rand bit presetn;
	rand bit pwrite;
	bit pselx;
	bit penable;
	bit pready;
	bit [7:0] prdata;
	bit pslverr;

	function new(string name="apb_trans");
		super.new(name);
	endfunction

	constraint valid_addr{
				if(!pwrite)
					paddr inside {[0:3], 5};
				else
					paddr inside{[0:2], 5};}

	constraint valid_reset{presetn dist{0:=1, 1:=99};}

	function void post_randomize();
		bit [7:0] cr1_mask=8'hff;
		bit [7:0] cr2_mask=8'h1b;
		bit [7:0] baud_mask=8'h77;
		bit [7:0] sr_mask=8'h00;
		bit [7:0] data_mask=8'hff;
		
		if(pwrite)
		begin
			case(paddr)
			3'b000:pwdata=pwdata	&	cr1_mask;
			3'b001:pwdata=pwdata	&	cr2_mask;
			3'b010:pwdata=pwdata	&	baud_mask;
			3'b011:pwdata=pwdata	&	sr_mask;
			3'b101:pwdata=pwdata	&	data_mask;
			default:pwdata=pwdata	&	data_mask;
			endcase
		end
	endfunction

	function void do_print(uvm_printer printer);
		super.do_print(printer);
		printer.print_field("presetn", 		this.presetn, 	1, 	UVM_BIN);
		printer.print_field("pselx", 		this.pselx, 	1, 	UVM_BIN);
		printer.print_field("penable", 		this.penable, 	1, 	UVM_BIN);
		printer.print_field("pwrite", 		this.pwrite, 	1, 	UVM_BIN);
		printer.print_field("pwdata", 		this.pwdata, 	8, 	UVM_BIN);
		printer.print_field("paddr", 		this.paddr, 	3, 	UVM_BIN);
		printer.print_field("prdata", 		this.prdata, 	8, 	UVM_BIN);
		printer.print_field("pready", 		this.pready, 	1, 	UVM_BIN);
		printer.print_field("pslverr", 		this.pslverr, 	1, 	UVM_BIN);
	endfunction
	
endclass

