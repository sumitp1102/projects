class reg_block extends uvm_reg_block;
	`uvm_object_utils(reg_block)

	rand reg_integer_file reg_file;
	uvm_reg_map reg_map;

	function new(string name="reg_block");
		super.new(name,"UVM_NO_COVERAGE");
	endfunction

	function void build();
		reg_file=reg_integer_file::type_id::create("reg_file");
		reg_file.configure(this,"");
		add_hdl_path("top.DUV.DUT","RTL");
		reg_file.add_hdl_path_slice("IRF.reg_file",0,32);
		reg_map=create_map("reg_map",'h0,4,UVM_LITTLE_ENDIAN,0);
		reg_map.add_mem(reg_file,5'h0,"RW");
		

	endfunction

	endclass


class reg_block_for_pc extends uvm_reg_block;
	`uvm_object_utils(reg_block_for_pc)
	
	rand pc_reg pc_h;
	uvm_reg_map reg_map;
	
	function new(string name="reg_block_for_pc");
		super.new(name,"UVM_NO_COVERAGE");
	endfunction

	function void build();
		pc_h=pc_reg::type_id::create("pc_h");
		pc_h.configure(this,null,"");
		add_hdl_path("top.DUV.DUT","RTL");
		pc_h.add_hdl_path_slice("REG1.pc_out",0, 32);//REG1_PC_OUT
		reg_map=create_map("reg_map",'h0,4,UVM_LITTLE_ENDIAN,0);	
		reg_map.add_reg(pc_h,5'h0,"RW");
		lock_model();
	endfunction

	endclass

