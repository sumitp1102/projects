class reg_integer_file extends uvm_mem;
	`uvm_object_utils(reg_integer_file)
	
	function new(string name="reg_integer_file");	
		super.new(name,32,32,"RW","UVM_NO_COVERAGE");
	endfunction
endclass

class pc_reg extends uvm_reg;
	`uvm_object_utils(pc_reg)

	rand uvm_reg_field pc1;
	function  new(string name="pc_reg");
		super.new(name,32,"UVM_COVERAGE");
	endfunction

	function void build();
		pc1=uvm_reg_field::type_id::create("pc1");
		pc1.configure(this, 32, 0, "RW", 0, 32'h000000, 1, 1, 0);
	endfunction

endclass

