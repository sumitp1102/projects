class spi_reg_block extends uvm_reg_block;

	`uvm_object_utils(spi_reg_block)

	spi_reg_file_cr1 spi_cr1;
	spi_reg_file_cr2 spi_cr2;
	spi_reg_file_baud_reg spi_baud;
	spi_reg_file_sr_reg spi_sr;
	spi_reg_file_data_reg spi_data;

	uvm_reg_map spi_map;

	function new(string name="spi_reg_block");
		super.new(name, build_coverage(UVM_CVR_ALL));
	endfunction

	virtual function void build();

		spi_cr1=spi_reg_file_cr1::type_id::create("spi_cr1");
		spi_cr2=spi_reg_file_cr2::type_id::create("spi_cr2");
		spi_baud=spi_reg_file_baud_reg::type_id::create("spi_baud");
		spi_sr=spi_reg_file_sr_reg::type_id::create("spi_sr");
		spi_data=spi_reg_file_data_reg::type_id::create("spi_data");

		spi_cr1.configure(this, null, "");
		spi_cr2.configure(this, null, "");
		spi_baud.configure(this, null, "");
		spi_sr.configure(this, null, "");
		spi_data.configure(this, null, "");

		spi_cr1.build();
		spi_cr2.build();
		spi_baud.build();
		spi_sr.build();
		spi_data.build();

		add_hdl_path("top.DUV", "RTL");

		spi_cr1.add_hdl_path_slice("APB_SLAVE_INTERFACE.spi_cr1_reg", 0, 8);
		spi_cr2.add_hdl_path_slice("APB_SLAVE_INTERFACE.spi_cr2_reg", 0, 8);
		spi_baud.add_hdl_path_slice("APB_SLAVE_INTERFACE.spi_baud_reg", 0, 8);
		spi_sr.add_hdl_path_slice("APB_SLAVE_INTERFACE.spi_status_reg", 0, 8);
		spi_data.add_hdl_path_slice("APB_SLAVE_INTERFACE.spi_data_reg", 0, 8);

		


		spi_map=create_map("spi_map", 'h0, 1, UVM_LITTLE_ENDIAN, 0);

		spi_map.add_reg(spi_cr1, 8'h0, "RW");
		spi_map.add_reg(spi_cr2, 8'h1, "RW");
		spi_map.add_reg(spi_baud, 8'h2, "RW");
		spi_map.add_reg(spi_sr, 8'h3, "RO");
		spi_map.add_reg(spi_data, 8'h5, "RW");


		lock_model();

	endfunction

endclass





