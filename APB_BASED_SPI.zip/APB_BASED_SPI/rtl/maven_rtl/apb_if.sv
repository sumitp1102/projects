interface apb_if(input bit pclk);

	logic pselx, pwrite, penable, pready, pslverr,presetn;
	logic [2:0] paddr;
	logic [7:0] pwdata, prdata;

	clocking apb_drv_cb@(posedge pclk);
		
		output pselx, pwrite, penable, presetn;
		output paddr;
		output pwdata;
		input prdata;
		input pready;

	endclocking

	clocking apb_mon_cb@(posedge pclk);
	
		input pselx, pwrite, penable, pready, pslverr, presetn;
		input paddr;
		input pwdata, prdata;

	endclocking

	modport APB_DRV(clocking apb_drv_cb);
	modport APB_MON(clocking apb_mon_cb);

endinterface
