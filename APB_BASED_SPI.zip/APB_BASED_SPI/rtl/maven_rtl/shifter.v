
/********************************************************************************************

Copyright 2024 - Maven Silicon Softech Pvt Ltd.  
www.maven-silicon.com

All Rights Reserved.

This source code is an unpublished work belongs to Maven Silicon Softech Pvt Ltd.
It is not to be shared with or used by any third parties who have not enrolled for our paid 
training courses or received any written authorization from Maven Silicon.

Filename                :       shifter.v   

module Name             :       shifter

Description             :       Shifter Module for APB based SPI Core Design

Author Name             :       Bindu Prasad C S

Support e-mail          :       For any queries, reach out to us on "techsupport_vm@maven-silicon.com" 

Version                 :       1.0

*********************************************************************************************/

  `define APB_DATA_WIDTH 8
  `define SPI_REG_WIDTH 8
  `define APB_ADDR_WIDTH 3

 module shifter(input PCLK,
  		input PRESETn,
  		input ss,
  		input send_data,
  		input lsbfe,
  		input cpha,
  		input cpol,
  		input flag_low,
  		input flag_high, 
  		input flags_low,
  		input flags_high,
  		input [`APB_DATA_WIDTH-1:0] data_mosi,
  		input miso,
  		input receive_data,
  		output [`APB_DATA_WIDTH-1:0] data_miso,
  		output reg mosi);

  reg [`APB_DATA_WIDTH-1:0] shift_register;

  reg [`APB_DATA_WIDTH-1:0] temp_reg;

  reg [2:0] count;
  reg [2:0] count1;
  reg [2:0] count2;
  reg [2:0] count3;

  // Logic to receivce the data  to the shift register
  always@(posedge PCLK or negedge PRESETn)
    begin
      if(!PRESETn)
        begin
          shift_register <= 8'b0;
        end
      else if(send_data)
	begin
	  shift_register <= data_mosi;
        end
    end

  // Logic to send the received miso data to the data register  
  assign data_miso=receive_data?temp_reg:8'b0000_0000;

  // Logic to send the mosi data
  always@(posedge PCLK or negedge PRESETn)
    begin
      if(!PRESETn)
        begin
	  mosi <= 1'b0;
	  count <= 3'd0;
	  count1 <= 3'd7;
        end
      else
        begin
	  if(!ss)
	    begin
              if((!cpha && cpol)||(cpha && !cpol))
	        begin
	          if(lsbfe)
	            begin
		      if(count <= 3'd7)
	                begin
		          if(flags_high)
			    begin
			      mosi<= shift_register[count];
			      count <= count + 1'b1;
			    end
		        end
		      else
		        count <= 3'd0;
		    end
		  else
		    begin
		      if(count1 >= 3'd0)
	                begin
		          if(flags_high)
			    begin
			      mosi<= shift_register[count1];
			      count1 <= count1 -1'b1;
			    end
		        end
		      else
		        count1 <= 3'd7;
		    end
	        end
	      else
	        begin
	          if(lsbfe)
	            begin
		      if(count <= 3'd7)
	                begin
		          if(flags_low)
			    begin
			      mosi<= shift_register[count];
			      count <= count + 1'b1;
			    end
		        end
		      else
		        count <= 3'd0;
		    end
		  else
		    begin
		      if(count1 >= 3'd0)
	                begin
		          if(flags_low)
			    begin
			      mosi<= shift_register[count1];
			      count1 <= count1- 1'b1;
			    end
		        end
		      else
		        count1 <= 3'd7;
		    end
	        end
	    end
	 end
    end

  // Logic to receive the miso data
  always@(posedge PCLK or negedge PRESETn)
    begin
      if(!PRESETn)
        begin
	  count2 <= 3'd0;
	  count3 <= 3'd7;
	  temp_reg<= 8'b0;
        end
      else
        begin
	  if(!ss)
	    begin
              if((!cpha && cpol)||(cpha && !cpol))
	        begin
	          if(lsbfe)
	            begin
		      if(count2 <= 3'd7)
	                begin
		          if(flag_high)
			    begin
			      temp_reg[count2] <= miso;
			      count2 <= count2 + 1'b1;
			    end
		        end
		      else
		        count2 <= 3'd0;
		    end
		  else
		    begin
		      if(count3 >= 3'd0)
	                begin
		          if(flag_high)
			    begin
			      temp_reg[count3] <= miso;
			      count3 <= count3 -1'b1;
			    end
		        end
		      else
		        count3 <= 3'd7;
		    end
	        end
	      else
	        begin
	          if(lsbfe)
	            begin
		      if(count2 <= 3'd7)
	                begin
		          if(flag_low)
			    begin
			      temp_reg[count2] <= miso;
			      count2 <= count2 + 1'b1;
			    end
		        end
		      else
		        count2 <= 3'd0;
		    end
		  else
		    begin
		      if(count3 >= 3'd0)
	                begin
		          if(flag_low)
			    begin
			      temp_reg[count3] <= miso;
			      count3 <= count3- 1'b1;
			    end
		        end
		      else
		        count3 <= 3'd7;
		    end
	        end
	    end
	end
    end
 endmodule

