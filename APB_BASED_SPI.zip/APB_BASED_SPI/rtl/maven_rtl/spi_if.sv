interface spi_if(input bit pclk);

	logic mosi, miso, ss, spi_interrupt_request, sclk;

	clocking spi_drv_cb@(posedge pclk);
		output miso;
		input ss, sclk;
	endclocking

	clocking spi_mon_cb@(posedge pclk);
		input mosi, ss, spi_interrupt_request, sclk, miso;
	endclocking

	modport SPI_DRV(clocking spi_drv_cb);
	modport SPI_MON(clocking spi_mon_cb);

endinterface

