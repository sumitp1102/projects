/*`include "../apb_slave_interface.v"
`include "../baud_generator.v"
`include "../shift_register.v"
`include "../slave_select_generator.v"*/

//-------------------------------SLAVE_SELECT------------------------------------------------------

module slave_select_generator(pclk, presetn, mstr, spi_mode, baud_rate_divisor, send_data, spiswai, ss, tip, receive_data);

input pclk, presetn, mstr, send_data, spiswai;
input [11:0] baud_rate_divisor;
input [1:0] spi_mode;

output tip;
output reg ss, receive_data;

reg [15:0]count;
wire [15:0] target;
reg rcv;


assign target=16*baud_rate_divisor;
assign tip=!ss;

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
	begin
		ss<=1'b1;
		rcv<=1'b0;
		count<=16'd65535;
	end
	else if(mstr & ((spi_mode==2'b00) | (spi_mode==2'b01)) & (!spiswai))
	begin	
		if(send_data)
		begin
			count<=16'b0;
			ss<=1'b0;
			rcv<=1'b0;
		end

		else if(count < target)
		begin
			count<=count+1'b1;
			ss<=1'b0;
			rcv<=1'b0;
		end

		else if(count==target)
		begin
			rcv<=1'b1;
			ss<=1'b1;
			count<=16'd65535;
		end
		else
		begin
			ss<=1'b1;
			rcv<=1'b0;
			count<=16'd65535;
		end
	end
	else
	begin
		ss<=1'b1;
		rcv<=1'b0;
		count<=16'd65535;
	end	
end

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		receive_data<=1'b0;
	else
		receive_data<=rcv;
end
endmodule

//--------------------------------------SHIFT_REGISTER----------------------------------------------------------------------

module shift_register(pclk, presetn, ss, send_data, lsbfe, cpha, cpol, miso_receive_sclk, mosi_send_sclk, mosi_send_sclk0, miso_receive_sclk0, data_mosi, miso, receive_data, mosi, data_miso);

input pclk, presetn, ss, send_data, lsbfe, cpha, cpol, miso_receive_sclk, miso_receive_sclk0, mosi_send_sclk, mosi_send_sclk0, miso, receive_data;
input [7:0] data_mosi;
output reg mosi;
output reg [7:0] data_miso;

reg [7:0] count, count1, count2, count3;
reg [7:0] shift_register, temp_lsb, temp_msb;


always@(*)
begin
	if(!presetn)
		data_miso<=8'd0;
	else
	begin
		if(receive_data)
		begin
			if(lsbfe)
				data_miso<=temp_lsb;
			else
				data_miso<=temp_msb;
		end
		else
			data_miso<=data_miso;
	end
end

//--------shift_register-----------//

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		shift_register<=8'd0;
	else
		shift_register<=send_data?data_mosi:shift_register;
end


	
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
	begin
		count<=3'd0;
		count1<=3'd7;
		count2<=3'd0;
		count3<=3'd7;
		temp_lsb<=8'd0;
		temp_msb<=8'd0;
		mosi<=1'b0;
		
	end
	else
	begin
		//--------------temp------------//
		temp_lsb[count2]<=ss? temp_lsb[count2]:((cpha^cpol) ? (lsbfe ? ((count2<=3'd7) ? (miso_receive_sclk0 ? miso : temp_lsb[count2]) : temp_lsb[count2]) :temp_lsb[count2]) : (lsbfe ? ((count2<=3'd7) ? (miso_receive_sclk ? miso : temp_lsb[count2]) : temp_lsb[count2]):temp_lsb[count2]));


		temp_msb[count3]<=ss? temp_msb[count3] :((cpha^cpol) ? (lsbfe ? temp_msb[count3]:((count3>=3'd0) ? (miso_receive_sclk0 ? miso : temp_msb[count3]):temp_msb[count3])) : (lsbfe ? temp_msb[count3] : ((count3>=3'd0) ? (miso_receive_sclk ? miso : temp_msb[count3]) :temp_msb[count3])));


		//--------------count----------//
		
		count<=ss?count:((cpha^cpol)?(lsbfe?(mosi_send_sclk?((count==3'd7)?3'd0:(count+1'b1)):count):3'd0):(lsbfe?(mosi_send_sclk0?((count==3'd7)?3'd0:(count+1'b1)):count):3'd0));

		//------------count1-----------//
		
		count1<=ss?count1:((cpha^cpol)?(lsbfe? 3'd7:(mosi_send_sclk?((count1==3'd0)?3'd7:(count1-1'b1)):count1)):(lsbfe? 3'd7:(mosi_send_sclk0?((count1==3'd0)?3'd7:(count1-1'b1)):count1)));

		//-----------count2----------//

		count2<=ss?count2:((cpha^cpol)?(lsbfe?(miso_receive_sclk0?((count2==3'd7)?3'd0:(count2+1'b1)):count2):3'd0):(lsbfe?(miso_receive_sclk?((count2==3'd7)?3'd0:(count2+1'b1)):count2):3'd0));

		//----------count3---------//
		
		count3<=ss?count3:((cpha^cpol)?(lsbfe?3'd7:(miso_receive_sclk0?((count3==3'd0)?3'd7:(count3-1'b1)):count3)):(lsbfe?3'd0:(miso_receive_sclk?((count3==3'd0)?3'd7:(count3-1'b1)):count3)));

		//----------mosi-----------//

		mosi<=ss? 1'b0 : ((cpha^cpol)?(lsbfe?((count<=3'd7)?(mosi_send_sclk?(shift_register[count]):mosi):1'b0):((count1>=3'd0)?(mosi_send_sclk?(shift_register[count1]):mosi):1'b0)):(lsbfe?((count<=3'd7)?(mosi_send_sclk0?(shift_register[count]):mosi):1'b0):((count1>=3'd0)?(mosi_send_sclk0?(shift_register[count1]):mosi):1'b0)));

/*		mosi<=ss? 1'b0 : ((cpha^cpol)?(lsbfe?((count<=3'd7)?(mosi_send_sclk?(shift_register[count]):mosi):1'b0):((count1>=3'd0)?(mosi_send_sclk?(shift_register[count1]):mosi):3'd7)):(lsbfe?((count<=3'd7)?(mosi_send_sclk0?(shift_register[count]):mosi):3'd0):((count1>=3'd0)?(mosi_send_sclk0?(shift_register[count1]):mosi):3'd7)));*/


	end
end

endmodule

//-----------------------------------------BAUD_RATE_GENERATOR----------------------------------------------------

module baud_generator(pclk, presetn, spi_mode, spiswai, sppr, spr, cpol, cpha, ss, sclk, flag_low, flag_high, flags_low, flags_high, baud_rate_divisor);

input pclk, presetn, spiswai, cpol, cpha, ss;
input [2:0] sppr, spr;
input [1:0] spi_mode;

output reg sclk, flag_low, flag_high, flags_low, flags_high;
output [11:0] baud_rate_divisor;


wire pre_sclk;
reg [11:0] count;


assign baud_rate_divisor=((sppr+1)*(2**(spr+1)));
assign pre_sclk=cpol;

//---------------------------flag_low-----------------------------------------------------------------------


always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		flag_low<=1'b0;
	else
		flag_low<=(cpol^cpha)?flag_low:(sclk? 1'b0:(count==(baud_rate_divisor-1'b1))? 1'b1: 1'b0);

end


//----------------------------flag_high------------------------------------------------------------------

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		flag_high<=1'b0;
	else
		flag_high<=(cpha^cpol)?(sclk?((count==(baud_rate_divisor-1'b1))? 1'b1:1'b0):1'b0):flag_high;

end

//---------------------------flags_low----------------------------------------------------------------------


always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		flags_low<=1'b0;
	else
		flags_low<=(cpha^cpol)?flags_low:(sclk? 1'b0:((count==(baud_rate_divisor-2'b10))? 1'b1: 1'b0));
end


//---------------------------flags_high---------------------------------------------------------------------------


always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		flags_high<=1'b0;
	else
		flags_high<=(cpol^cpha)?(sclk?((count==(baud_rate_divisor-2'b10))? 1'b1:1'b0):1'b0):flags_high;

end


//-----------------------------count---------------------------------------------------------------------------------

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		count<=12'd0;
	else
		count<=(((spi_mode==2'b00) | (spi_mode==2'b01)) & (!ss) & (!spiswai))?((count==(baud_rate_divisor-1'b1))? 12'd0:(count+1'b1)):12'd0;

end

//-----------------------------sclk----------------------------------------------------------

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		sclk<=pre_sclk;
	else
		sclk<=(((spi_mode==2'b00) | (spi_mode==2'b01)) & (!ss) & (!spiswai))?((count==(baud_rate_divisor-1'b1))?(!sclk):sclk):pre_sclk;
end

endmodule


//===================================================my_baud_rate_gen==============================================================================


/*module baud_generator(pclk, presetn, spi_mode, spiswai, sppr, spr, cpol, cpha, ss, sclk, flag_low, flag_high, flags_low, flags_high, baud_rate_divisor);

input pclk, presetn, spiswai, cpol, cpha, ss;
input [2:0] sppr, spr;
input [1:0] spi_mode;

output reg sclk;
output reg flag_low, flag_high, flags_low, flags_high;
output [11:0] baud_rate_divisor;


wire pre_sclk;
reg [11:0] count;



assign baud_rate_divisor=((sppr+1)*(2**(spr+1)));
assign pre_sclk=cpol;




//---------------------------flag_low-----------------------------------------------------------------------


always@(*)
begin
	if(!presetn)
		flags_low<=1'b0;
	else
		flags_low<=ss?1'b0:((cpol^cpha)?flags_low:(sclk? 1'b0:(count==(baud_rate_divisor/2)-1'b1)? 1'b1: 1'b0));

end


//----------------------------flag_high------------------------------------------------------------------

always@(*)
begin
	if(!presetn)
		flags_high<=1'b0;
	else
		flags_high<=ss?1'b0:((cpha^cpol)?(sclk?((count==(baud_rate_divisor/2)-1'b1)? 1'b1:1'b0):1'b0):flags_high);

end

//---------------------------flags_low----------------------------------------------------------------------


always@(*)
begin
	if(!presetn)
		flag_low<=1'b0;
	else
		flag_low<=ss?1'b0:((cpol^cpha)?flag_low:(sclk?((count==0)? 1'b1: 1'b0):1'b0));
end


//---------------------------flags_high---------------------------------------------------------------------------


always@(*)
begin
	if(!presetn)
		flag_high<=1'b0;
	else
		flag_high<=ss?1'b0:((cpol^cpha)?(sclk?1'b0:((count==0)? 1'b1:1'b0)):flag_high);

end


//-----------------------------count---------------------------------------------------------------------------------

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		count<=12'd0;
	else
		count<=(((spi_mode==2'b00) | (spi_mode==2'b01)) & (!ss) & (!spiswai))?((count==(baud_rate_divisor/2-1'b1))? 12'd0:(count+1'b1)):12'd0;

end

//-----------------------------sclk----------------------------------------------------------

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		sclk<=pre_sclk;
	else
		sclk<=(((spi_mode==2'b00) | (spi_mode==2'b01)) & (!ss) & (!spiswai))?((count==((baud_rate_divisor/2)-1'b1))?(!sclk):sclk):pre_sclk;
end

endmodule*/

//===============================================================================================================================================================


//----------------------------APB_SLAVE_INTERFACE-----------------------------------------------

module apb_slave_interface(pclk, presetn, paddr, pwrite, pselx, penable, pwdata, ss, miso_data, receive_data, tip, prdata, mstr, cpol, cpha, lsbfe, spiswai, sppr, spr, spi_interrupt_req, pready, pslverr, send_data, mosi_data, spi_mode);

input pclk, presetn, pwrite, pselx, penable, ss, receive_data, tip;
input [7:0] pwdata, miso_data;
input [2:0] paddr;

output mstr, cpol, cpha, lsbfe, spiswai, spi_interrupt_req, pready, pslverr;
output reg send_data;
output [1:0] spi_mode;
output reg [7:0] mosi_data;
output [7:0] prdata;
output [2:0] spr, sppr;

parameter apb_idle=2'b00, apb_setup=2'b01, apb_enable=2'b10, spi_run=2'b01, spi_wait=2'b00, spi_stop=2'b10;
parameter cr2_mask=8'b0001_1011;
parameter baud_mask=8'b0111_0111;

reg [1:0] apb_present_state, apb_next_state, spi_present_state, spi_next_state;
reg [7:0] spi_cr1_reg, spi_cr2_reg, spi_baud_reg, spi_data_reg, spi_status_reg;
wire spe, spie, sptie, modfen, sptef, modf, spif, ssoe; 
wire wr_en, rd_en;

assign spi_mode=spi_present_state;
assign wr_en=(pwrite && (apb_present_state==apb_enable)) ? 1'b1 : 1'b0;
assign rd_en=((!pwrite) && (apb_present_state==apb_enable)) ? 1'b1: 1'b0;
assign pready=(apb_present_state==apb_enable) ? 1'b1:1'b0;
assign pslverr=(apb_present_state==apb_enable)? tip:1'b0;

//---------------SR-----------------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		spi_status_reg<=8'h20;
	else
		spi_status_reg<={spif, 1'b0, sptef, modf, 4'b0};
end


//-----------------CR1---------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		spi_cr1_reg<=8'h04;
	else
		spi_cr1_reg<=wr_en?((paddr==3'd0)?pwdata:spi_cr1_reg):spi_cr1_reg;
end

//----------------CR2------------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		spi_cr2_reg<=8'h0;
	else
		spi_cr2_reg<=wr_en?((paddr==3'd1)?(pwdata & cr2_mask): spi_cr2_reg):spi_cr2_reg;
end

//----------------BAUD-------------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		spi_baud_reg<=8'd0;
	else
		spi_baud_reg<=wr_en?((paddr==3'd2)?(pwdata & baud_mask):spi_baud_reg):spi_baud_reg;
end

//------------------DATA REG---------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		spi_data_reg<=8'd0;
	else
		spi_data_reg<=wr_en?((paddr==3'd5)?pwdata:spi_data_reg):(((spi_data_reg == pwdata) & (spi_data_reg != miso_data) & ((spi_mode == spi_run) | (spi_mode == spi_wait))?8'd0:(((spi_mode == spi_run) | (spi_mode == spi_wait)) & receive_data)?miso_data:spi_data_reg));
end

//----------------SEND DATA---------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		send_data<=1'b0;
	else
		send_data<=wr_en?send_data:(((spi_data_reg == pwdata) & (spi_data_reg != miso_data) & ((spi_mode == spi_run) | (spi_mode == spi_wait)))? 1'b1 :(((spi_mode == spi_run) | (spi_mode == spi_wait)) & receive_data)? 1'b0: 1'b0);
end

//--------CR1 bits-----------------------
assign lsbfe	=	spi_cr1_reg[0];
assign ssoe	=	spi_cr1_reg[1];
assign cpha	=	spi_cr1_reg[2];
assign cpol	=	spi_cr1_reg[3];
assign mstr	=	spi_cr1_reg[4];
assign sptie	=	spi_cr1_reg[5];
assign spe	=	spi_cr1_reg[6];
assign spie	=	spi_cr1_reg[7];

//---------CR2 bits-----------------------
//assign spc0	=	spi_cr2_reg[0];
assign spiswai	=	spi_cr2_reg[1];
//assign bidiroe	=	spi_cr2_reg[3];
assign modfen	=	spi_cr2_reg[4];

//---------SR bits-----------------------
assign sptef	=	(spi_data_reg==8'd0)? 1'b1:1'b0;
assign spif	=	(spi_data_reg!=8'd0)? 1'b1:1'b0;
assign modf	=	((!ss) & mstr & modfen & (!ssoe));

//--------BR bits-------------------------
assign sppr	=	spi_baud_reg[6:4];
assign spr	=	spi_baud_reg[2:0];

//-----------PRADATA----------------------
/*always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
		prdata<=8'd0;
	else
	begin
		if(rd_en)
		begin
			case(paddr)
				3'd0:prdata<=spi_cr1_reg;
				3'd1:prdata<=spi_cr2_reg;
				3'd2:prdata<=spi_baud_reg;
				3'd3:prdata<=spi_status_reg;
				3'd5:prdata<=spi_data_reg;
				default:prdata<=8'd0;
			endcase
		end
		else
			prdata<=prdata;
	end
end*/

assign prdata=(!presetn)?8'd0:(rd_en?((paddr==3'd0)?spi_cr1_reg:((paddr==3'd1)?spi_cr2_reg:((paddr==3'd2)?spi_baud_reg:((paddr==3'd3)?spi_status_reg:((paddr==3'd5)?spi_data_reg:8'd0))))):8'd0);


//------------MOSI_DATA-----------------
always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
	begin
		mosi_data<=8'd0;
	end
	else 
	begin
		if((spi_data_reg==pwdata) && (spi_data_reg != miso_data) && ((spi_mode == spi_run) || spi_mode == spi_wait) && !wr_en)
		begin
			mosi_data<=spi_data_reg;
		end
		else
			mosi_data<=mosi_data;
	end
end


//------------SPI_INTERRUPT----------------
assign spi_interrupt_req=((!spie) & (!sptie))? 1'b0:(((!sptie) & spie)? (spif | modf) : ((!spie) & sptie)?sptef:(spif | modf |sptef));

always@(posedge pclk or negedge presetn)
begin
	if(!presetn)
	begin
		apb_present_state<=apb_idle;
		spi_present_state<=spi_run;
	end
	else
	begin
		apb_present_state<=apb_next_state;
		spi_present_state<=spi_next_state;
	end
end



always@(*)
begin
	case(apb_present_state)
		apb_idle:
		begin
			//if(pselx && (pwrite != 1'bx) && (paddr != 3'dx) && (!penable))
			if(pselx)
				apb_next_state=apb_setup;
			else
				apb_next_state=apb_idle;
		end

		apb_setup:
		begin
			//if(pselx && penable && (pwrite != 1'bx) && (paddr != 3'dx))
			if(pselx && penable)

				apb_next_state=apb_enable;
			//else if(pselx && (!penable) && (pwrite != 1'bx) && (paddr != 3'dx))
			else if(pselx && (!penable))

				apb_next_state=apb_setup;
			else
				apb_next_state=apb_idle;
		end

		apb_enable:
		begin
			//if(pselx && penable && (!pready) && (pwrite != 1'bx) && (paddr != 3'dx))
			if(pselx && penable)
				apb_next_state=apb_enable;
			//else if(pselx && (!penable) && (pwrite != 1'bx) && (paddr != 3'dx))
			else if(pselx && (!penable))
				apb_next_state=apb_setup;
			else 
				apb_next_state=apb_idle;
		end

		default:apb_next_state=apb_idle;
	endcase
end

always@(*)
begin
	case(spi_present_state)
		spi_run:
		begin
			if(!spe)
				spi_next_state=spi_wait;
			else
				spi_next_state=spi_run;
		end

		spi_wait:
		begin
			if(spiswai)
				spi_next_state=spi_stop;
			else if(spe)
				spi_next_state=spi_run;
			else
				spi_next_state=spi_wait;
		end

		spi_stop:
		begin
			if(spe)
				spi_next_state=spi_run;
			else if(!spiswai)
				spi_next_state=spi_wait;
			else
				spi_next_state=spi_stop;
		end

		default:spi_next_state=spi_run;
	endcase
end

endmodule

//---------------------------------------TOP_MODULE-----------------------------------------------------------------

module apb_based_spi_top(pclk, presetn, paddr, pwrite, pselx, penable, pwdata, miso, ss, sclk, spi_interrupt_request, mosi, prdata, pready, pslverr);

input pclk, presetn, pwrite, pselx, penable, miso;
input [2:0] paddr;
input [7:0] pwdata;
output mosi;
output ss, sclk, spi_interrupt_request, pready, pslverr;
output [7:0] prdata;

wire lsbfe_w, tip_w, spiswai_w, cpol_w, cpha_w, mstr_w, send_data_w, receive_data_w, miso_receive_sclk_w, miso_receive_sclk0_w, mosi_send_sclk_w, mosi_send_sclk0_w;
wire [1:0]spi_mode_w; 
wire [2:0]sppr_w, spr_w;
wire [11:0] baud_rate_divisor_w;
wire [7:0] data_miso_w, data_mosi_w;

apb_slave_interface APB_SLAVE_INTERFACE(
						.pclk(pclk), 
						.presetn(presetn), 
						.paddr(paddr), 
						.pwrite(pwrite), 
						.pselx(pselx), 
						.penable(penable), 
						.pwdata(pwdata), 
						.ss(ss), 
						.miso_data(data_miso_w), 
						.receive_data(receive_data_w), 
						.tip(tip_w), 
						.prdata(prdata), 
						.mstr(mstr_w), 
						.cpol(cpol_w), 
						.cpha(cpha_w), 
						.lsbfe(lsbfe_w), 
						.spiswai(spiswai_w), 
						.sppr(sppr_w), 
						.spr(spr_w), 
						.spi_interrupt_req(spi_interrupt_request), 
						.pready(pready), 
						.pslverr(pslverr), 
						.send_data(send_data_w), 
						.mosi_data(data_mosi_w), 
						.spi_mode(spi_mode_w));

slave_select_generator SLAVE_SELECT_GENERATOR(
						.pclk(pclk), 
						.presetn(presetn), 
						.mstr(mstr_w), 
						.spi_mode(spi_mode_w), 
						.baud_rate_divisor(baud_rate_divisor_w), 
						.send_data(send_data_w), 
						.spiswai(spiswai_w), 
						.ss(ss), 
						.tip(tip_w), 
						.receive_data(receive_data_w));

shift_register SHIFT_REGISTER(
						.pclk(pclk), 
						.presetn(presetn), 
						.ss(ss), 
						.send_data(send_data_w), 
						.lsbfe(lsbfe_w), 
						.cpha(cpha_w), 
						.cpol(cpol_w), 
						.miso_receive_sclk(miso_receive_sclk_w), 
						.mosi_send_sclk(mosi_send_sclk_w), 
						.mosi_send_sclk0(mosi_send_sclk0_w), 
						.miso_receive_sclk0(miso_receive_sclk0_w), 
						.data_mosi(data_mosi_w), 
						.miso(miso), 
						.receive_data(receive_data_w), 
						.mosi(mosi), 
						.data_miso(data_miso_w));

baud_generator BAUD_RATE_GENERATOR(
						.pclk(pclk), 
						.presetn(presetn), 
						.spi_mode(spi_mode_w), 
						.spiswai(spiswai_w), 
						.sppr(sppr_w), 
						.spr(spr_w), 
						.cpol(cpol_w), 
						.cpha(cpha_w), 
						.ss(ss), 
						.sclk(sclk), 
						.flag_low(miso_receive_sclk_w), 
						.flag_high(miso_receive_sclk0_w), 
						.flags_low(mosi_send_sclk0_w), 
						.flags_high(mosi_send_sclk_w), 
						.baud_rate_divisor(baud_rate_divisor_w));

endmodule

/*
module apb_based_spi_tb();

wire mosi;
reg pclk, presetn, pwrite, pselx, penable, miso;
reg [2:0] paddr;
reg [7:0] pwdata;
wire ss, sclk, spi_interrupt_request, pready, pslverr;
wire [7:0] prdata;

apb_based_spi_top DUT(pclk, presetn, paddr, pwrite, pselx, penable, pwdata, miso, ss, sclk, spi_interrupt_request, mosi, prdata, pready, pslverr);



task reset;
	begin
		@(negedge pclk)
		presetn=1'b0;
		@(negedge pclk)
		presetn=1'b1;
	end
endtask

task initialize();
	begin
		paddr=3'd0;
		pwrite=1'b0;
		pselx=1'b0;
		penable=1'b0;
		pwdata=8'd0;
		miso=1'b0;
	end
endtask

task read_stimulus(input [7:0] cr1, cr2, br);
	begin
		@(negedge pclk)
	begin
		pwrite=1'b1;
		pselx=1'b1;
		@(negedge pclk)
		penable=1'b1;
		#20;
		penable=1'b0;
	end
		@(negedge pclk)
	begin
		paddr=3'd0;
		pwdata=cr1;
		penable=1'b1;
		#20;
		penable=1'b0;


	end
		@(negedge pclk)
	begin
		paddr=3'd1;
		pwdata=cr2;
		penable=1'b1;
		#20;
		penable=1'b0;

	end
		@(negedge pclk)
	begin
		paddr=3'd2;
		pwdata=br;
		penable=1'b1;
		#20;
		penable=1'b0;

	end

		@(negedge pclk)
	begin
		paddr=3'd5;
		pwdata=8'd0;
		penable=1'b1;
		#20;
		penable=1'b0;

	end

		@(negedge pclk)
		penable=1'b1;
		repeat(8)
	begin
		miso=~miso;
		repeat(8)
		@(negedge pclk);

	end
	#1000;
end
endtask



task write_stimulus(input [7:0] cr1, cr2, br, dr);
	begin
		@(negedge pclk)
	begin
		pwrite=1'b1;
		pselx=1'b1;
		@(negedge pclk)
		penable=1'b1;
		#20;
		penable=1'b0;
	end
		@(negedge pclk)
	begin
		paddr=3'd0;
		pwdata=cr1;
		penable=1'b1;
		#20;
		penable=1'b0;


	end
		@(negedge pclk)
	begin
		paddr=3'd1;
		pwdata=cr2;
		penable=1'b1;
		#20;
		penable=1'b0;

	end
		@(negedge pclk)
	begin
		paddr=3'd2;
		pwdata=br;
		penable=1'b1;
		#20;
		penable=1'b0;

	end
		@(negedge pclk)
	begin
		paddr=5;
		pwdata=dr;
		penable=1'b1;
		#20;
		penable=1'b0;

	end
		@(negedge pclk)
	//	penable=1'b1;
		repeat(8)
	begin
		miso=~miso;
		repeat(10)
		@(negedge pclk);

	end


	#20;
	penable=1'b0;
	#1000;
end
endtask

initial
begin
	pclk=1'b0;
	forever #5 pclk=!pclk;
end

initial
begin
	initialize;
	reset;
	write_stimulus(8'b1111_0000, 8'b1100_0001, 8'b0000_0001, 8'b1010_1010);
	reset;
	read_stimulus(8'b1111_0000, 8'b1100_0001, 8'b0000_0001);
	
	#1000;
	$finish;
end
endmodule



*/








