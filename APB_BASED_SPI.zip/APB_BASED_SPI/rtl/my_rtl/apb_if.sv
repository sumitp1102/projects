interface apb_if(input bit pclk);

	logic pselx, pwrite, penable, pready, pslverr,presetn;
	logic [2:0] paddr;
	logic [7:0] pwdata, prdata;

	clocking apb_drv_cb@(posedge pclk);
		
		output pselx, pwrite, penable, presetn;
		output paddr;
		output pwdata;
		input prdata;
		input pready;

	endclocking

	clocking apb_mon_cb@(posedge pclk);
	
		input pselx, pwrite, penable, pready, pslverr, presetn;
		input paddr;
		input pwdata, prdata;

	endclocking

	modport APB_DRV(clocking apb_drv_cb);
	modport APB_MON(clocking apb_mon_cb);

  /*property signals_stable;
     @(posedge pclk) $rose(pselx)|-> ($stable(pwrite) && 
					$stable(paddr) &&
					$stable(pwdata)) until pready[->1];
   endproperty

   property penable_stable;
     @(posedge pclk) $rose(penable)|->($stable(pselx) && 
			$stable(penable)) until pready [->1];
   endproperty

   property psel_to_pready;
     @(posedge pclk) (pselx && penable ) |->##[0:$] pready;
   endproperty

   property address_reserved;
     @(posedge pclk) pselx |-> ((paddr!=3'b100) || (paddr !=3'b110)||(paddr!=3'b111)); 
   endproperty

   property penable_deassert;
     @(posedge pclk) (!pselx) |-> (!penable);
   endproperty

   property valid_write_data_transfer;
     @(posedge pclk) (pselx && penable && pwrite) |->(pwdata !== 'hx);
   endproperty

   property valid_read_data_transfer;
     @(posedge pclk) (pselx && penable && (!pwrite)) |-> (prdata !== 'hx);
   endproperty

   property pready_low_at_start;
     @(posedge pclk) (pselx && (!penable))|-> (!pready);
   endproperty

   property pready_deassert;
     @(posedge pclk) (!pselx) |-> (!pready);
   endproperty

   SIGNAL_STABLE	: assert property(signals_stable);
   penable_STABLE	: assert property(penable_stable);
   pselx_TO_pready	: assert property(psel_to_pready);
   ADDRESS_RESERVED	: assert property(address_reserved);
   penable_DEASSERT	: assert property(penable_deassert);
   pwdata_TRANSFER	: assert property(valid_write_data_transfer);
   prdata_TRANSFER	: assert property(valid_read_data_transfer);
   pready_START		: assert property(pready_low_at_start);
   pready_DEASSERT	: assert property(pready_deassert);
	*/

endinterface
