class spi_driver extends uvm_driver #(spi_trans);
	
	`uvm_component_utils(spi_driver)

	spi_agent_config spi_agt_cfg;

	virtual spi_if.SPI_DRV vif;

	bit reset_test_bit;

	bit [7:0] crtl;
	bit lsb;
	bit cpol, cpha;
	bit[1:0] low_power;

	function new(string name="spi_driver", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

		

	
		if(!uvm_config_db #(spi_agent_config)::get(this, "", "spi_agent_config", spi_agt_cfg))
			`uvm_fatal("SPI DRV","GET CONFIG FAILED")

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=spi_agt_cfg.vif;
	endfunction

	task send_to_dut(spi_trans xtn);

		if(!uvm_config_db #(bit[1:0])::get(this, "", "low_power", low_power))
			`uvm_fatal("SPI_MON", "GET LOW POWER FAILED")

		if(!uvm_config_db #(bit[7:0])::get(this, "", "spi_cr1_val", crtl))
			`uvm_fatal("SPI_DRV", "GET BIT VALUE FAILED")



		lsb=crtl[0];
		cpha=crtl[2];
		cpol=crtl[3];
		if(low_power!=2'b01)
		begin
			wait(!vif.spi_drv_cb.ss)

		if(lsb)
		begin
			if(!cpha && !cpol)
			begin
				vif.spi_drv_cb.miso<=xtn.miso[0];
				for(int i=1; i<=7; i++)
				begin
					@(negedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end
			else if(!cpha && cpol)
			begin
				vif.spi_drv_cb.miso<=xtn.miso[0];
				for(int i=1; i<=7; i++)
				begin
					@(posedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end

			else if(cpha && !cpol)
			begin
				for(int i=0; i<=7; i++)
				begin
					@(posedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end

			else if(cpha && cpol)
			begin
				for(int i=0; i<=7; i++)
				begin
					@(negedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end
		end

		else
		begin
			if(!cpha && !cpol)
			begin
				vif.spi_drv_cb.miso<=xtn.miso[7];
				for(int i=6; i>=0; i--)
				begin
					@(negedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end
			else if(!cpha && cpol)
			begin
				vif.spi_drv_cb.miso<=xtn.miso[7];
				for(int i=6; i>=0; i--)
				begin
					@(posedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end

			else if(cpha && !cpol)
			begin
				for(int i=7; i>=0; i--)
				begin
					@(posedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end

			else if(cpha && cpol)
			begin
				for(int i=7; i>=0; i--)
				begin
					@(negedge vif.spi_drv_cb.sclk)
					vif.spi_drv_cb.miso<=xtn.miso[i];
				end
			end
		end
		end

		`uvm_info(get_type_name(), $sformatf("DATA FROM SPI DRIVER : %s", xtn.sprint), UVM_LOW)
	
	
	endtask

	task run_phase(uvm_phase phase);
		forever
		begin
			seq_item_port.get_next_item(req);
			send_to_dut(req);
			seq_item_port.item_done();
		end
	endtask




endclass
