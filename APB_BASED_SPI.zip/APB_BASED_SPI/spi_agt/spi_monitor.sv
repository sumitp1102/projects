class spi_monitor extends uvm_monitor;

	`uvm_component_utils(spi_monitor)

	virtual spi_if.SPI_MON vif;

	spi_agent_config spi_agt_cfg;
	bit [1:0] low_power;
	spi_trans xtn;

	bit [7:0] crtl;
	bit lsb, cpha, cpol;

	uvm_analysis_port #(spi_trans) analysis_port;

	function new(string name="spi_monitor", uvm_component parent);
		super.new(name, parent);
		analysis_port=new("analysis_port", this);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		if(!uvm_config_db #(spi_agent_config)::get(this, "", "spi_agent_config", spi_agt_cfg))
			`uvm_fatal("SPI MON","GET CONFIG FAILED")


	endfunction
	
	function void connect_phase(uvm_phase phase);
		vif=spi_agt_cfg.vif;
	endfunction

	task collect_data();

		if(!uvm_config_db #(bit[1:0])::get(this, "", "low_power", low_power))
			`uvm_fatal("SPI_MON", "GET LOW POWER FAILED")


		if(!uvm_config_db #(bit[7:0])::get(this, "", "spi_cr1_val", crtl))
			`uvm_fatal("SPI_MON", "GET CR1 CONFIG FAILED")

		xtn=spi_trans::type_id::create("xtn");
	
		
		lsb=crtl[0];
		cpha=crtl[2];
		cpol=crtl[3];
		
		if(low_power!=2'b01)
		begin
			wait(!vif.spi_mon_cb.ss)

		if(lsb)
		begin
			if(cpol^cpha)
			begin
				for(int i=0; i<=7; i++)
				begin
					@(negedge vif.spi_mon_cb.sclk)
					xtn.mosi[i]=vif.spi_mon_cb.mosi;
					xtn.sclk=vif.spi_mon_cb.sclk;
					xtn.ss=vif.spi_mon_cb.ss;
					xtn.spi_interrupt_request=vif.spi_mon_cb.spi_interrupt_request;
					xtn.miso[i]=vif.spi_mon_cb.miso;
				end
			end

			else
			begin
				for(int i=0; i<=7; i++)
				begin
					@(posedge vif.spi_mon_cb.sclk)
					xtn.mosi[i]=vif.spi_mon_cb.mosi;
					xtn.sclk=vif.spi_mon_cb.sclk;
					xtn.ss=vif.spi_mon_cb.ss;
					xtn.spi_interrupt_request=vif.spi_mon_cb.spi_interrupt_request;
					xtn.miso[i]=vif.spi_mon_cb.miso;

				end
			end
		end

		else
		begin
			if(cpol^cpha)
			begin
				for(int i=7; i>=0; i--)
				begin
					@(negedge vif.spi_mon_cb.sclk)
					xtn.mosi[i]=vif.spi_mon_cb.mosi;
					xtn.sclk=vif.spi_mon_cb.sclk;
					xtn.ss=vif.spi_mon_cb.ss;
					xtn.spi_interrupt_request=vif.spi_mon_cb.spi_interrupt_request;
					xtn.miso[i]=vif.spi_mon_cb.miso;
				end
			end

			else
			begin
				for(int i=7; i>=0; i--)
				begin
					@(posedge vif.spi_mon_cb.sclk)
					xtn.mosi[i]=vif.spi_mon_cb.mosi;
					xtn.sclk=vif.spi_mon_cb.sclk;
					xtn.ss=vif.spi_mon_cb.ss;
					xtn.spi_interrupt_request=vif.spi_mon_cb.spi_interrupt_request;
					xtn.miso[i]=vif.spi_mon_cb.miso;

				end
			end
		end
		@(vif.spi_mon_cb);

		analysis_port.write(xtn);
		`uvm_info(get_type_name(), $sformatf("DATA FROM SPI MONITOR : %s", xtn.sprint), UVM_LOW)

		end
		else
		begin
			analysis_port.write(xtn);
			`uvm_info(get_type_name(), $sformatf("DATA FROM SPI MONITOR : %s", xtn.sprint), UVM_LOW)
			wait(!vif.spi_mon_cb.ss)
			@(vif.spi_mon_cb);
		end

			

			
		


	endtask

	task run_phase(uvm_phase phase);

		forever
			collect_data();

	endtask

	
		

endclass

