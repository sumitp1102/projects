class spi_sequence extends uvm_sequence #(spi_trans);
	
	`uvm_object_utils(spi_sequence)

	spi_reg_block spi_rg_blk;
	
	env_config env_cfg;

	function new(string name="spi_sequence");
		super.new(name);
	endfunction

	task body();
		
		if(!uvm_config_db #(env_config)::get(null, get_full_name(), "env_config", env_cfg))
			`uvm_fatal(get_type_name(), "GET CONFIG FAILED")

		spi_rg_blk=env_cfg.spi_rg_blk;
	endtask

endclass

class spi_cpha1_cpol1_sequence extends spi_sequence;

	`uvm_object_utils(spi_cpha1_cpol1_sequence)

	function new(string name="spi_cpha1_cpol1_sequence");
		super.new(name);
	endfunction

	task body();
		super.body();
		repeat(1)
		begin
			req=spi_trans::type_id::create("req");
			start_item(req);
			assert(req.randomize());
			finish_item(req);
		end
	endtask

endclass
/*
class spi_read_sequence extends spi_sequence;

	`uvm_object_utils(spi_read_sequence)

	function new(string name="spi_read_sequence");
		super.new(name);
	endfunction

	task body();
		super.body();
		repeat(1)
		begin
			req=spi_trans::type_id::create("req");
			start_item(req);
			assert(req.randomize());
			finish_item(req);
		end
	endtask

endclass*/

