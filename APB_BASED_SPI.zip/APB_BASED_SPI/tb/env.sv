class env extends uvm_env;
	
	`uvm_component_utils(env)

	env_config env_cfg;
	scoreboard sbh;
	virtual_sequencer vseqrh;
	apb_agent apb_agt;
	spi_agent spi_agt;

	function new(string name="env", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		if(!uvm_config_db #(env_config)::get(this, "", "env_config", env_cfg))
			`uvm_fatal("ENV", "GET ENV CONFIG FAILED")

		if(env_cfg.has_spi_agt)
			spi_agt=spi_agent::type_id::create("spi_agt", this);
		if(env_cfg.has_apb_agt)
			apb_agt=apb_agent::type_id::create("apb_agt", this);

		uvm_config_db #(spi_agent_config)::set(this, "spi_agt*", "spi_agent_config", env_cfg.spi_agt_cfg);
		uvm_config_db #(apb_agent_config)::set(this, "apb_agt*", "apb_agent_config", env_cfg.apb_agt_cfg);

		if(env_cfg.has_scoreboard)
			sbh=scoreboard::type_id::create("sbh", this);

		if(env_cfg.has_virtual_sequencer)
			vseqrh=virtual_sequencer::type_id::create("vseqrh", this);

	endfunction

	function void connect_phase(uvm_phase phase);

		if(env_cfg.has_virtual_sequencer)
		begin
			vseqrh.spi_seqrh=spi_agt.spi_seqrh;
			vseqrh.apb_seqrh=apb_agt.apb_seqrh;
		end

		if(env_cfg.has_scoreboard)
		begin
			apb_agt.apb_monh.analysis_port.connect(sbh.apb_fifoh.analysis_export);
			spi_agt.spi_monh.analysis_port.connect(sbh.spi_fifoh.analysis_export);
		end

	endfunction

endclass


			

		
