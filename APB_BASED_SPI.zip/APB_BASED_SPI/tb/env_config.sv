class env_config extends uvm_object;

	`uvm_object_utils(env_config)

	spi_agent_config spi_agt_cfg;
	apb_agent_config apb_agt_cfg;
	spi_reg_block spi_rg_blk;
	bit has_spi_agt;
	bit has_apb_agt;
	bit has_scoreboard;
	bit has_virtual_sequencer;

	function new(string name = "env_config");
		super.new(name);
	endfunction

endclass

