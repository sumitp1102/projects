class scoreboard extends uvm_scoreboard;

	`uvm_component_utils(scoreboard)
	
	uvm_tlm_analysis_fifo #(spi_trans) spi_fifoh;
	uvm_tlm_analysis_fifo #(apb_trans) apb_fifoh;

	env_config env_cfg;

	spi_reg_block spi_rg_blk;
	uvm_status_e status;
	bit [1:0] low_power;

	apb_trans apb_rcv_data_h;
	spi_trans spi_rcv_data_h;
	apb_trans apb_cov;
	spi_trans spi_cov;

	covergroup apb_cg;
		option.per_instance=1;
		RESET	: coverpoint apb_cov.presetn{bins reset_x={0,1};}
		ADDR	: coverpoint apb_cov.paddr{bins paddr_x={0, 1, 2, 3, 5};}
		SELX	: coverpoint apb_cov.pselx{bins pselx_x={0,1};}
		ENABLE 	: coverpoint apb_cov.penable{bins penable_x={0,1};}
		WRITE 	: coverpoint apb_cov.pwrite{bins write_x={0,1};}
		READY  	: coverpoint apb_cov.pready{bins ready_x={0,1};}
		ERROR	: coverpoint apb_cov.pslverr{bins slverr_x={0,1};}
		WDATA	: coverpoint apb_cov.pwdata{bins low_wdata_x={[8'h00:8'h80]};
							bins high_wdata_x={[8'h81:8'hff]};}
		RDATA  	: coverpoint apb_cov.prdata{bins low_rdata_x={[8'h00:8'h80]};
							bins high_rdata_x={[8'h81:8'hff]};}
	endgroup

	covergroup spi_cg;
		option.per_instance=1;
		SS	: coverpoint spi_cov.ss{bins ss_x={0,1};}
		MISO	: coverpoint spi_cov.miso{bins low_miso_x={[8'h00:8'h80]};
							bins high_miso_x={[8'h81:8'hff]};}
		MOSI	: coverpoint spi_cov.mosi{bins low_mosi_x={[8'h00:8'h80]};
							bins high_mosi_x={[8'h81:8'hff]};}
		IRQ	: coverpoint spi_cov.spi_interrupt_request{bins irq_x={0,1};}
	endgroup

	bit reset_test_bit, spi_irq;

	bit [7:0] spi_cr1_data, spi_cr2_data, spi_baud_data, spi_sr_data, spi_data_data;

	function new(string name="scoreboard", uvm_component parent);
		super.new(name, parent);
		spi_fifoh=new("spi_fifoh", this);
		apb_fifoh=new("apb_fifoh", this);
		apb_cg=new();
		spi_cg=new();
	endfunction

	task compare_values(apb_trans xtn);

		if(!uvm_config_db #(bit[1:0])::get(this, "", "low_power", low_power))
			`uvm_fatal("SB", "GET LOW POWER FAILED")

		if(low_power!=2'b01)
		begin
		if(spi_rcv_data_h!=null)
		begin
			if(apb_rcv_data_h.pwrite && apb_rcv_data_h.paddr==5)
				begin
					this.spi_rg_blk.spi_sr.read(status, spi_sr_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
					spi_irq=(spi_sr_data[7] | spi_sr_data[5] | spi_sr_data[4])?1'b1:1'b0;

					
					$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
					$display("-------------------------------SCOREBOARD REPORT-------------------------");
					if(spi_rcv_data_h.mosi == apb_rcv_data_h.pwdata && spi_rcv_data_h.spi_interrupt_request==spi_irq)
					$display("---------------------------WRITE DATA COMPARE SUCCESSFULL-----------------------");
					else
					$display("--------------------------WRITE DATA COMPARE UNSUCCESSFULL----------------------");
					$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				end
		end
		end
		else
		begin
			$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			$display("@@@@@@@@@@@@@@---SCOREBOARD---@@@@@@@@@@@@@@@@@@@");
			$display("---------------IT IS LOW POWER MODE--------------");
			$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		end

	endtask

	task check_cpha_cpol_align;

		if(!uvm_config_db #(bit[1:0])::get(this, "", "low_power", low_power))
			`uvm_fatal("SB", "GET LOW POWER FAILED")

		if(!uvm_config_db #(bit)::get(this, "", "reset_test_bit", reset_test_bit))
			`uvm_fatal("SB", "GET RESET TEST FAILED")


		if(low_power!=2'b01)
		begin
		if(reset_test_bit)
		begin
			this.spi_rg_blk.spi_cr1.read(status, spi_cr1_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
			this.spi_rg_blk.spi_cr2.read(status, spi_cr2_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
			this.spi_rg_blk.spi_baud.read(status, spi_baud_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
			this.spi_rg_blk.spi_sr.read(status, spi_sr_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
			this.spi_rg_blk.spi_data.read(status, spi_data_data, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));

			$display("----------------------------SCOREBOARD--------------------------------");
			if(spi_cr1_data == 8'h04 && spi_cr2_data == 8'h00 && spi_baud_data == 8'h00 && spi_sr_data == 8'h20 && spi_data_data == 8'h00)
			`uvm_info(get_type_name(), "RESET HAS BEEN SUCCESSFULLY APPLIED", UVM_LOW)
			else
			`uvm_info(get_type_name(), "RESET HAS BEEN FAILED BETTER LUCK NEXT TIME", UVM_LOW)
			$display("------------------------------REPORT-------------------------------------\n");

		end

		if(spi_rcv_data_h!=null && apb_rcv_data_h!=null)
		begin
			if(!apb_rcv_data_h.pwrite && apb_rcv_data_h.paddr==5)
			begin	
				$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				$display("-------------------------------SCOREBOARD REPORT-------------------------");
				if(spi_rcv_data_h.miso == apb_rcv_data_h.prdata)
				$display("---------------------------READ DATA COMPARE SUCCESSFULL-----------------------");
				else
				$display("--------------------------READ DATA COMPARE UNSUCCESSFULL----------------------");
				$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			end
		end
		end
		else
		begin
			$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			$display("@@@@@@@@@@@@@@---SCOREBOARD---@@@@@@@@@@@@@@@@@@@");
			$display("---------------IT IS LOW POWER MODE--------------");
			$display("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		end


	endtask


		

	function void build_phase(uvm_phase phase);

		if(! uvm_config_db #(env_config)::get(this, "", "env_config", env_cfg))
			`uvm_fatal("SCOREBOARD", "GET ENV CFG FAILED")

		
		spi_rg_blk=env_cfg.spi_rg_blk;

	endfunction

	task run_phase(uvm_phase phase);

		fork
			forever
			begin
				spi_fifoh.get(spi_rcv_data_h);
				spi_cov=new spi_rcv_data_h;
				compare_values(apb_rcv_data_h);
				spi_cg.sample();
				$display("@@@@@@@@---SPI_COVERAGE---IS---:---%0d---@@@@@@@@", spi_cg.get_coverage());

								
				
			end
			forever
			begin
				apb_fifoh.get(apb_rcv_data_h);
				apb_cov=new apb_rcv_data_h;
				check_cpha_cpol_align;
				apb_cg.sample();
				$display("@@@@@@@@---APB_COVERAGE---IS---:---%0d---@@@@@@@@", apb_cg.get_coverage());

	
			end


		join
		

	endtask

/*	function void report_phase(uvm_phase phase);


	endfunction*/

		

	



endclass

