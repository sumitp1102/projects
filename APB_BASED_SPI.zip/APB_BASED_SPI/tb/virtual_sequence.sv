class virtual_sequence extends uvm_sequence #(uvm_sequence_item);

	`uvm_object_utils(virtual_sequence)

	env_config env_cfg;
	spi_reg_block spi_rg_blk;

	virtual_sequencer vseqrh;
	spi_sequencer spi_seqrh;
	apb_sequencer apb_seqrh;

//	rand uvm_reg_data_t data;
//	uvm_status_e status;

	function new(string name="virtual_sequence");
		super.new(name);
	endfunction

	task body();	
		
		if(!uvm_config_db #(env_config)::get(null, get_full_name(), "env_config", env_cfg))

			`uvm_fatal("VIRTUAL SEQ","GET ENV CONFIG FAILED")

		this.spi_rg_blk=env_cfg.spi_rg_blk;

		if(!$cast(vseqrh, m_sequencer))
		begin
			`uvm_fatal(get_full_name(),"CASTING FAILED")
		end
		
		spi_seqrh=vseqrh.spi_seqrh;
		apb_seqrh=vseqrh.apb_seqrh;
	
	endtask

endclass

class apb_virtual_reset_sequence extends virtual_sequence;

	`uvm_object_utils(apb_virtual_reset_sequence)

	apb_reset_sequence apb_rst_seq_h;

	function new(string name="apb_virtual_reset_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();
		apb_rst_seq_h=apb_reset_sequence::type_id::create("apb_rst_seq_h");
		apb_rst_seq_h.start(apb_seqrh);

	endtask

endclass

class virtual_apb_read_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_apb_read_sequence)

	apb_read_sequence apb_rd_seq_h;

	function new(string name="virtual_apb_read_sequence");
		super.new(name);
	endfunction

	task body();
		super.body();
		apb_rd_seq_h=apb_read_sequence::type_id::create("apb_rd_seq_h");
		apb_rd_seq_h.start(apb_seqrh);
	endtask

endclass


class virtual_cpha1_cpol1_lsb1_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha1_cpol1_lsb1_sequence)

	apb_cpha1_cpol1_lsb1_sequence apb_cpha1_cpol1_lsb1_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha1_cpol1_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha1_cpol1_lsb1_h=apb_cpha1_cpol1_lsb1_sequence::type_id::create("apb_cpha1_cpol1_lsb1_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha1_cpol1_lsb1_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	endtask

endclass

class virtual_cpha1_cpol0_lsb1_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha1_cpol0_lsb1_sequence)

	apb_cpha1_cpol0_lsb1_sequence apb_cpha1_cpol0_lsb1_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha1_cpol0_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha1_cpol0_lsb1_h=apb_cpha1_cpol0_lsb1_sequence::type_id::create("apb_cpha1_cpol0_lsb1_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha1_cpol0_lsb1_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_cpha0_cpol1_lsb1_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha0_cpol1_lsb1_sequence)

	apb_cpha0_cpol1_lsb1_sequence apb_cpha0_cpol1_lsb1_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha0_cpol1_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha0_cpol1_lsb1_h=apb_cpha0_cpol1_lsb1_sequence::type_id::create("apb_cpha0_cpol1_lsb1_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha0_cpol1_lsb1_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_cpha0_cpol0_lsb1_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha0_cpol0_lsb1_sequence)

	apb_cpha0_cpol0_lsb1_sequence apb_cpha0_cpol0_lsb1_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha0_cpol0_lsb1_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha0_cpol0_lsb1_h=apb_cpha0_cpol0_lsb1_sequence::type_id::create("apb_cpha0_cpol0_lsb1_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha0_cpol0_lsb1_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_cpha1_cpol1_lsb0_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha1_cpol1_lsb0_sequence)

	apb_cpha1_cpol1_lsb0_sequence apb_cpha1_cpol1_lsb0_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha1_cpol1_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha1_cpol1_lsb0_h=apb_cpha1_cpol1_lsb0_sequence::type_id::create("apb_cpha1_cpol1_lsb0_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha1_cpol1_lsb0_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass

class virtual_cpha1_cpol0_lsb0_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha1_cpol0_lsb0_sequence)

	apb_cpha1_cpol0_lsb0_sequence apb_cpha1_cpol0_lsb0_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha1_cpol0_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha1_cpol0_lsb0_h=apb_cpha1_cpol0_lsb0_sequence::type_id::create("apb_cpha1_cpol0_lsb0_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha1_cpol0_lsb0_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_cpha0_cpol1_lsb0_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha0_cpol1_lsb0_sequence)

	apb_cpha0_cpol1_lsb0_sequence apb_cpha0_cpol1_lsb0_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha0_cpol1_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha0_cpol1_lsb0_h=apb_cpha0_cpol1_lsb0_sequence::type_id::create("apb_cpha0_cpol1_lsb0_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha0_cpol1_lsb0_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_cpha0_cpol0_lsb0_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_cpha0_cpol0_lsb0_sequence)

	apb_cpha0_cpol0_lsb0_sequence apb_cpha0_cpol0_lsb0_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_cpha0_cpol0_lsb0_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_cpha0_cpol0_lsb0_h=apb_cpha0_cpol0_lsb0_sequence::type_id::create("apb_cpha0_cpol0_lsb0_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_cpha0_cpol0_lsb0_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_low_power_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_low_power_sequence)

	apb_low_power_sequence apb_low_power_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_low_power_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_low_power_h=apb_low_power_sequence::type_id::create("apb_low_power_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_low_power_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_slv_low_power_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_slv_low_power_sequence)

	apb_slv_low_power_sequence apb_slv_low_power_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_slv_low_power_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_slv_low_power_h=apb_slv_low_power_sequence::type_id::create("apb_slv_low_power_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_slv_low_power_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass


class virtual_rand_sequence extends virtual_sequence;

	`uvm_object_utils(virtual_rand_sequence)

	apb_rand_sequence apb_rand_h;
	spi_cpha1_cpol1_sequence spi_cpha1_cpol1_h;

	function new(string name="virtual_rand_sequence");
		super.new(name);
	endfunction

	task body();

		super.body();

		apb_rand_h=apb_rand_sequence::type_id::create("apb_rand_h");
		spi_cpha1_cpol1_h=spi_cpha1_cpol1_sequence::type_id::create("spi_cpha1_cpol1_h");
		fork
		apb_rand_h.start(apb_seqrh);
		spi_cpha1_cpol1_h.start(spi_seqrh);
		join
	
	endtask

endclass






		

		

		

	


