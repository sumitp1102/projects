package pkg;

	import uvm_pkg::*;
	`include "uvm_macros.svh"
	`include "spi_reg_file.sv"
	`include "spi_reg_block.sv"
	`include "apb_trans.sv"
	`include "spi_trans.sv"
	`include "spi_agent_config.sv"
	`include "apb_agent_config.sv"
	`include "env_config.sv"
	`include "spi_sequence.sv"
	`include "apb_sequence.sv"
	`include "spi_driver.sv"
	`include "apb_driver.sv"
	`include "spi_monitor.sv"
	`include "apb_monitor.sv"
	`include "spi_sequencer.sv"
	`include "apb_sequencer.sv"
	`include "spi_agent.sv"
	`include "apb_agent.sv"
	`include "virtual_sequencer.sv"
	`include "virtual_sequence.sv"
	`include "scoreboard.sv"
	`include "env.sv"
	`include "test.sv"

endpackage
