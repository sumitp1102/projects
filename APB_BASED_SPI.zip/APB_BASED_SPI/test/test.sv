class test extends uvm_test;

	`uvm_component_utils(test)

	env_config env_cfg;
	env envh;
	spi_reg_block spi_rg_blk;
	apb_agent_config apb_agt_cfg;
	spi_agent_config spi_agt_cfg;
	bit has_scoreboard=1;
	bit has_spi_agt=1;
	bit has_apb_agt=1;
	bit has_virtual_sequencer=1;
	uvm_status_e status;
	bit [7:0] data_out=5;
	bit [7:0] data_in=254;
	bit reset_test_bit;
	bit [7:0] cr1;
	bit [1:0] low_power;


	function new(string name="test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

		env_cfg=env_config::type_id::create("env_cfg");
		apb_agt_cfg=apb_agent_config::type_id::create("apb_agt_cfg");
		spi_agt_cfg=spi_agent_config::type_id::create("spi_agt_cfg");
		spi_rg_blk=spi_reg_block::type_id::create("spi_rg_blk");
		spi_rg_blk.build();
		env_cfg.spi_rg_blk=spi_rg_blk;



		if(!uvm_config_db #(virtual apb_if)::get(this, "", "apb_if", apb_agt_cfg.vif))
			`uvm_fatal("TEST","GET CONFIG APB FAILED")

		if(!uvm_config_db #(virtual spi_if)::get(this, "", "spi_if", spi_agt_cfg.vif))
			`uvm_fatal("TEST","GET CONFIG SPI FAILED")

		


		apb_agt_cfg.is_active=UVM_ACTIVE;
		spi_agt_cfg.is_active=UVM_ACTIVE;

		env_cfg.apb_agt_cfg=apb_agt_cfg;
		env_cfg.spi_agt_cfg=spi_agt_cfg;

		env_cfg.has_spi_agt=has_spi_agt;
		env_cfg.has_apb_agt=has_apb_agt;

		env_cfg.has_scoreboard=has_scoreboard;
		env_cfg.has_virtual_sequencer=has_virtual_sequencer;

		uvm_config_db #(env_config)::set(this,"*", "env_config", env_cfg);
		envh=env::type_id::create("envh", this);


	endfunction

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

	task run_phase(uvm_phase phase);
	
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		cr1=8'h00;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

/*		phase.raise_objection(this);
		this.spi_rg_blk.spi_cr1.write(status, data_in, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
		$display("wrire spi_cr1=%0d and status is = %s", data_in, status);
		#5;
		this.spi_rg_blk.spi_cr1.read(status, data_out, .path(UVM_BACKDOOR), .map(spi_rg_blk.spi_map));
		$display("read spi_cr1=%0d and status is = %s", data_out, status);
		phase.drop_objection(this);*/

	endtask


endclass

class reset_test extends test;

	`uvm_component_utils(reset_test)
	
	apb_virtual_reset_sequence apb_rst_vir_seq_h;

	function new(string name="reset_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);
		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'h00;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);

		reset_test_bit=1'b1;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);
		apb_rst_vir_seq_h=apb_virtual_reset_sequence::type_id::create("apb_rst_vir_seq_h");
		apb_rst_vir_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction



endclass

class cpha1_cpol1_lsb1_test extends test;

	`uvm_component_utils(cpha1_cpol1_lsb1_test)


	virtual_cpha1_cpol1_lsb1_sequence vir_cpha1_cpol1_lsb1_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha1_cpol1_lsb1_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hff;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);


		vir_cpha1_cpol1_lsb1_h=virtual_cpha1_cpol1_lsb1_sequence::type_id::create("vir_cpha1_cpol1_lsb1_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha1_cpol1_lsb1_h.start(envh.vseqrh);
		#150;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha1_cpol0_lsb1_test extends test;

	`uvm_component_utils(cpha1_cpol0_lsb1_test)

	virtual_cpha1_cpol0_lsb1_sequence vir_cpha1_cpol0_lsb1_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha1_cpol0_lsb1_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hf7;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);



		vir_cpha1_cpol0_lsb1_h=virtual_cpha1_cpol0_lsb1_sequence::type_id::create("vir_cpha1_cpol0_lsb1_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha1_cpol0_lsb1_h.start(envh.vseqrh);
		#150;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha0_cpol1_lsb1_test extends test;

	`uvm_component_utils(cpha0_cpol1_lsb1_test)

	virtual_cpha0_cpol1_lsb1_sequence vir_cpha0_cpol1_lsb1_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha0_cpol1_lsb1_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hfb;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);


		vir_cpha0_cpol1_lsb1_h=virtual_cpha0_cpol1_lsb1_sequence::type_id::create("vir_cpha0_cpol1_lsb1_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha0_cpol1_lsb1_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha0_cpol0_lsb1_test extends test;

	`uvm_component_utils(cpha0_cpol0_lsb1_test)

	virtual_cpha0_cpol0_lsb1_sequence vir_cpha0_cpol0_lsb1_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha0_cpol0_lsb1_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hf3;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);


		vir_cpha0_cpol0_lsb1_h=virtual_cpha0_cpol0_lsb1_sequence::type_id::create("vir_cpha0_cpol0_lsb1_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha0_cpol0_lsb1_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass


class cpha1_cpol1_lsb0_test extends test;

	`uvm_component_utils(cpha1_cpol1_lsb0_test)

	virtual_cpha1_cpol1_lsb0_sequence vir_cpha1_cpol1_lsb0_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha1_cpol1_lsb0_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hfe;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);


		vir_cpha1_cpol1_lsb0_h=virtual_cpha1_cpol1_lsb0_sequence::type_id::create("vir_cpha1_cpol1_lsb0_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha1_cpol1_lsb0_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha1_cpol0_lsb0_test extends test;

	`uvm_component_utils(cpha1_cpol0_lsb0_test)

	virtual_cpha1_cpol0_lsb0_sequence vir_cpha1_cpol0_lsb0_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;


	function new(string name="cpha1_cpol0_lsb0_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hf6;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		vir_cpha1_cpol0_lsb0_h=virtual_cpha1_cpol0_lsb0_sequence::type_id::create("vir_cpha1_cpol0_lsb0_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha1_cpol0_lsb0_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha0_cpol1_lsb0_test extends test;

	`uvm_component_utils(cpha0_cpol1_lsb0_test)

	virtual_cpha0_cpol1_lsb0_sequence vir_cpha0_cpol1_lsb0_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha0_cpol1_lsb0_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hfa;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		vir_cpha0_cpol1_lsb0_h=virtual_cpha0_cpol1_lsb0_sequence::type_id::create("vir_cpha0_cpol1_lsb0_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha0_cpol1_lsb0_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass

class cpha0_cpol0_lsb0_test extends test;

	`uvm_component_utils(cpha0_cpol0_lsb0_test)

	virtual_cpha0_cpol0_lsb0_sequence vir_cpha0_cpol0_lsb0_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="cpha0_cpol0_lsb0_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b00;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'hf2;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		vir_cpha0_cpol0_lsb0_h=virtual_cpha0_cpol0_lsb0_sequence::type_id::create("vir_cpha0_cpol0_lsb0_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_cpha0_cpol0_lsb0_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass


class low_power_test extends test;

	`uvm_component_utils(low_power_test)

	bit [1:0] low_power;

	virtual_low_power_sequence vir_low_power_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="low_power_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);

		low_power=2'b01;
		uvm_config_db #(bit[1:0])::set(this, "*", "low_power", low_power);

		cr1=8'h1b;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		vir_low_power_h=virtual_low_power_sequence::type_id::create("vir_low_power_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_low_power_h.start(envh.vseqrh);
		#10;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#10;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass


class slv_low_power_test extends test;

	`uvm_component_utils(slv_low_power_test)

	bit [1:0] low_power;

	virtual_slv_low_power_sequence vir_slv_low_power_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="slv_low_power_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);
		cr1=8'h0b;
		low_power=2'd1;
		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);

		uvm_config_db #(bit[1:0])::set(this, "*", "low_power_mode", low_power);
		vir_slv_low_power_h=virtual_slv_low_power_sequence::type_id::create("vir_slv_low_power_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_slv_low_power_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass


class rand_test extends test;

	`uvm_component_utils(rand_test)

//	bit [7:0] cr1=8'h1b;
//	bit [1:0] low_power=2'd1;


	virtual_rand_sequence vir_rand_h;
	virtual_apb_read_sequence vir_apb_rd_seq_h;

	function new(string name="rand_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	function void build_phase(uvm_phase phase);

		super.build_phase(phase);

//		uvm_config_db #(bit[7:0])::set(this, "*", "spi_cr1_val", cr1);
//		uvm_config_db #(bit[1:0])::set(this, "*", "low_power_mode", low_power);


	endfunction

	task run_phase(uvm_phase phase);

		phase.raise_objection(this);
		reset_test_bit=1'b0;
		uvm_config_db #(bit)::set(this, "*", "reset_test_bit", reset_test_bit);
		vir_rand_h=virtual_rand_sequence::type_id::create("vir_rand_h");
		vir_apb_rd_seq_h=virtual_apb_read_sequence::type_id::create("vir_apb_rd_seq_h");
		
		vir_rand_h.start(envh.vseqrh);
		#250;
		vir_apb_rd_seq_h.start(envh.vseqrh);
		#100;
		phase.drop_objection(this);

	endtask

	function void end_of_elaboration_phase(uvm_phase phase);
		uvm_top.print_topology();
	endfunction

endclass







	

	
	
		





	



		


