module top;
	
	import uvm_pkg::*;
	import pkg::*;

	bit pclk=0;


	always #5 pclk=~pclk;

	spi_if SPI_IF(pclk);
	apb_if APB_IF(pclk);

	apb_based_spi_top DUV(.pclk(pclk), 
				.presetn(APB_IF.presetn), 
				.paddr(APB_IF.paddr), 
				.pwrite(APB_IF.pwrite), 
				.pselx(APB_IF.pselx), 
				.penable(APB_IF.penable), 
				.pwdata(APB_IF.pwdata), 
				.miso(SPI_IF.miso), 
				.ss(SPI_IF.ss), 
				.sclk(SPI_IF.sclk), 
				.spi_interrupt_request(SPI_IF.spi_interrupt_request), 
				.mosi(SPI_IF.mosi), 
				.prdata(APB_IF.prdata), 
				.pready(APB_IF.pready), 
				.pslverr(APB_IF.pslverr));

	/*spi_core DUV(.PCLK(pclk), 
				.PRESETn(APB_IF.presetn), 
				.PADDR(APB_IF.paddr), 
				.PWRITE(APB_IF.pwrite), 
				.PSEL(APB_IF.pselx), 
				.PENABLE(APB_IF.penable), 
				.PWDATA(APB_IF.pwdata), 
				.miso(SPI_IF.miso), 
				.ss(SPI_IF.ss), 
				.sclk(SPI_IF.sclk), 
				.spi_interrupt_request(SPI_IF.spi_interrupt_request), 
				.mosi(SPI_IF.mosi), 
				.PRDATA(APB_IF.prdata), 
				.PREADY(APB_IF.pready), 
				.PSLVERR(APB_IF.pslverr));*/




	initial
	begin
		uvm_config_db #(virtual spi_if)::set(null, "*", "spi_if", SPI_IF);
		uvm_config_db #(virtual apb_if)::set(null, "*", "apb_if", APB_IF);
		run_test("");
	end

endmodule

		
