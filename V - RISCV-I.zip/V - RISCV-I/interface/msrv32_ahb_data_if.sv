`timescale 1ns/1ps

interface msrv32_ahb_data_if(input logic ms_riscv32_mp_clk_in);

 wire [31:0] ms_riscv32_mp_dmaddr_out;
 wire [31:0] ms_riscv32_mp_data_in;
 wire [31:0] ms_riscv32_mp_dmdata_out;
 wire [3:0 ] ms_riscv32_mp_dmwr_mask_out;

//Newly created please check with alistair
// logic [3:0 ] ms_riscv32_mp_dmwr_out;

 wire ms_riscv32_mp_dmwr_req_out;
 wire ms_riscv32_mp_data_hready_in;
 wire ms_riscv32_mp_hresp_in;
 wire [1:0] ms_riscv32_mp_data_htrans_out;

 clocking drv_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input ms_riscv32_mp_dmaddr_out;
    input ms_riscv32_mp_dmdata_out;
    input ms_riscv32_mp_dmwr_req_out;
    input ms_riscv32_mp_dmwr_mask_out;
    input ms_riscv32_mp_data_htrans_out;
    output ms_riscv32_mp_data_hready_in;
    output ms_riscv32_mp_data_in;
    output ms_riscv32_mp_hresp_in;

 endclocking

 clocking rm_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    output ms_riscv32_mp_dmaddr_out;
    output ms_riscv32_mp_dmdata_out;
    output ms_riscv32_mp_dmwr_req_out;
    output ms_riscv32_mp_dmwr_mask_out;
    output ms_riscv32_mp_data_htrans_out;
    input ms_riscv32_mp_data_hready_in;
    input ms_riscv32_mp_data_in;
    input ms_riscv32_mp_hresp_in;

 endclocking


 clocking mon_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input ms_riscv32_mp_dmaddr_out;
    input ms_riscv32_mp_dmdata_out;
    input ms_riscv32_mp_dmwr_req_out;
    input ms_riscv32_mp_dmwr_mask_out;
    input ms_riscv32_mp_data_in;
    input ms_riscv32_mp_data_hready_in;
    input ms_riscv32_mp_hresp_in;


 endclocking  

 modport DRV_MP(clocking drv_cb);
 modport MON_MP(clocking mon_cb);
 modport RM_MP(clocking rm_cb);

endinterface
