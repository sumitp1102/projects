`timescale 1ns/1ps

interface msrv32_ahb_instr_if(input logic ms_riscv32_mp_clk_in);

 wire [31:0] ms_riscv32_mp_imaddr_out;
 wire [31:0] ms_riscv32_mp_instr_in;
 wire ms_riscv32_mp_instr_hready_in;
 
 clocking drv_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input ms_riscv32_mp_imaddr_out;
    output ms_riscv32_mp_instr_in;
    output ms_riscv32_mp_instr_hready_in;
 endclocking

 clocking mon_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input ms_riscv32_mp_imaddr_out;
    input ms_riscv32_mp_instr_in;
 endclocking 

 clocking rm_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    output ms_riscv32_mp_imaddr_out;
    input ms_riscv32_mp_instr_in;
    input ms_riscv32_mp_instr_hready_in;    
 endclocking

 modport DRV_MP(clocking drv_cb);
 modport MON_MP(clocking mon_cb);
 modport RM_MP(clocking rm_cb);
endinterface

