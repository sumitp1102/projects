`timescale 1ns/1ps

interface msrv32_irq_if(input logic ms_riscv32_mp_clk_in);

  logic  ms_riscv32_mp_eirq_in;
  logic  ms_riscv32_mp_tirq_in;
  logic  ms_riscv32_mp_sirq_in;

 clocking drv_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    output  ms_riscv32_mp_eirq_in;
    output  ms_riscv32_mp_tirq_in;
    output  ms_riscv32_mp_sirq_in;
 
endclocking

 clocking rm_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input  ms_riscv32_mp_eirq_in;
    input  ms_riscv32_mp_tirq_in;
    input  ms_riscv32_mp_sirq_in;

 endclocking


 clocking mon_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input  ms_riscv32_mp_eirq_in;
    input  ms_riscv32_mp_tirq_in;
    input  ms_riscv32_mp_sirq_in;
 
endclocking  

 modport DRV_MP(clocking drv_cb);
 modport MON_MP(clocking mon_cb);
 modport RM_MP(clocking rm_cb);
endinterface
