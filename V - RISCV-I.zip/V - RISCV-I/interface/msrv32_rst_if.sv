`timescale 1ns/1ps

interface msrv32_rst_if(input logic ms_riscv32_mp_clk_in);
 wire mp_rst_in;
 wire [63:0] mp_rc_in;

 clocking drv_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    output mp_rst_in;
    output mp_rc_in;
 endclocking

 clocking rm_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input mp_rst_in;
    input mp_rc_in;
 endclocking


 clocking mon_cb @(posedge ms_riscv32_mp_clk_in);
    default input #1 output #0;
    input mp_rst_in;
    input mp_rc_in;
 endclocking  

 modport DRV_MP(clocking drv_cb);
 modport MON_MP(clocking mon_cb);
 modport RM_MP(clocking rm_cb);
endinterface
