/*********************************

//File Name: msrv32_top.v

//Module Name: msrv32_top

//Description: This module will be used to hold the address of next instruction to be executed.

//Dependencies: msrv32_decoder.v
//              msrv32_immediate_generator.v
//              msrv32_alu.v
//              msrv32_branch_unit.v
//              msrv32_load_unit.v
//              msrv32_reg_bloc.v

//Version: 1.0

//Engineer: Alistair, Nishikant, Prasanna

//Email: tech_support@maven-silicon.com

//************************************/

`timescale 1ns / 1ps
/*
`include "msrv32_alu.v"
`include "msrv32_bu.v"
`include "msrv32_dec.v"
`include "msrv32_immediate_adder.v"
`include "msrv32_img.v"
`include "msrv32_instruction_decoder.v"
`include "msrv32_integer_file.v"
`include "msrv32_lu.v"
`include "msrv32_pc.v"
`include "msrv32_reg_block_1.v"
`include "msrv32_reg_block_2.v"
`include "msrv32_store_unit.v"
`include "msrv32_wb_mux_sel_unit.v"
`include "wr_en_generator.v"
`include "msrv32_csr_file.v"
`include "msrv32_machine_control.v"

`include "csr_data_mux_unit.v"
`include "data_wr_mux_unit.v"
`include "machine_counter_setup.v"
`include "machine_counter.v"
`include "mcause_reg.v"
`include "mepc_and_mscratch_reg.v"
`include "mie_reg.v"
`include "mip_reg.v"
`include "misa_and_pre_data.v"
`include "mstatus_reg.v"
`include "mtval_reg.v"
`include "mtvec_reg.v"
*/
module msrv32_top #(

   parameter BOOT_ADDRESS = 32'h00000000
    
   )(
     input  ms_riscv32_mp_clk_in,
     input  ms_riscv32_mp_rst_in,
      
   // connection with Real Time Counter
     input   [63:0] ms_riscv32_mp_rc_in,
     
   // connections with Instruction Memory
     output  [31:0] ms_riscv32_mp_imaddr_out,
     input   [31:0] ms_riscv32_mp_instr_in,
     input  ms_riscv32_mp_instr_hready_in,           //AHB ready

   // connections with Data Memory
     output  [31:0] ms_riscv32_mp_dmaddr_out,
     output  [31:0] ms_riscv32_mp_dmdata_out,
     output         ms_riscv32_mp_dmwr_req_out,
     output  [3:0 ] ms_riscv32_mp_dmwr_mask_out,
     input   [31:0] ms_riscv32_mp_data_in,
     input  ms_riscv32_mp_data_hready_in,            //AHB ready
     input  ms_riscv32_mp_hresp_in,                  //AHB response
     output [1:0] ms_riscv32_mp_data_htrans_out,     //AHB data trans
     
   //connections with Interrupt Controller
     input  ms_riscv32_mp_eirq_in,
     input  ms_riscv32_mp_tirq_in,
     input  ms_riscv32_mp_sirq_in
    );
    
   //
   // writeback selection
   parameter WB_ALU               =  3'b000;
   parameter WB_LU                =  3'b001;
   parameter WB_IMM               =  3'b010;
   parameter WB_IADDER_OUT        =  3'b011;
   parameter WB_CSR               =  3'b100;
   parameter WB_PC_PLUS           =  3'b101;

   // ---------------------------------
   // Internal wires and registers
   // ---------------------------------
   wire [31:0] iaddr;
   wire [31:0] pc;
   wire [31:0] pc_plus_4;
   wire        misaligned_instr;
   wire [31:0] pc_mux;
   wire [31:0] rs2;
   wire        mem_wr_req;
   
   wire 	   flush;
   wire [6:0 ] opcode;
   wire [2:0 ] funct3;
   wire [6:0 ] funct7;
   wire [4:0 ] rs1_addr;
   wire [4:0 ] rs2_addr;
   wire [4:0 ] rd_addr;
   wire [11:0] csr_addr;
   wire [31:7] instr_31_to_7;
   wire [31:0] rs1;
   wire [31:0] imm;
   wire        iadder_src;
   wire 	   wr_en_csr_file;
   wire 	   wr_en_integer_file;
   wire [11:0] csr_addr_reg;
   wire [2:0] csr_op_reg;
   wire [31:0] imm_reg;
   wire [31:0] rs1_reg;
   wire [31:0] pc_reg2;
   wire i_or_e;
   wire set_cause;
   wire [3:0 ] cause;
      wire set_epc;
   wire instret_inc;
   wire mie_clear;
   wire mie_set;
   wire misaligned_exception;
   wire mie;
   wire meie_out;
   wire mtie_out;
   wire msie_out;
   wire meip_out;
   wire mtip_out;
   wire msip_out;
   wire  rf_wr_en_reg;
   wire csr_wr_en_reg;
   wire csr_wr_en_reg_file;
   wire integer_wr_en_reg_file;
   wire [4:0] rd_addr_reg;
   wire [2:0] wb_mux_sel;
   wire [2:0] wb_mux_sel_reg; 
   wire [31:0] lu_output;
   wire [31:0] alu_result;
   wire [31:0] csr_data;
   wire [31:0] pc_plus_4_reg;
   wire [31:0] iadder_out_reg;
   wire [31:0] rs2_reg;
   wire alu_src_reg;
   wire [31:0] wb_mux_out;
   wire [31:0] alu_2nd_src_mux;
   
   wire illegal_instr;
   wire branch_taken;
   wire [31:0] next_pc;
   reg [31:0] pc_reg;
   wire misaligned_load;
   wire misaligned_store;
   wire [3:0] cause_in;
   wire [1:0] pc_src;
   wire trap_taken;
   wire [1:0] load_size_reg;
   wire [3:0] alu_opcode_reg;
   wire load_unsigned_reg;
/////////////////////////////////////////////////
         
   
   
   
   
   wire [31:0] iadder_out;
   
   wire [31:0] epc;
   wire [31:0] trap_address;
   
   wire [3:0] alu_opcode;
   
   wire [3:0] mem_wr_mask;
   wire [1:0] load_size;
   
   wire load_unsigned;
   
   wire alu_src;
   
   wire csr_wr_en;
   wire rf_wr_en;
   
   
   wire [2:0] imm_type;
   wire [2:0] csr_op;
   
   
   

   
   
   wire [31:0] su_data_out;
   wire [31:0] su_d_addr;
   wire [3:0] su_wr_mask;
   wire su_wr_req;
   
    
   // ---------------------------------
   // PIPELINE STAGE 1
   // ---------------------------------
    
   // PC MUX
    
   msrv32_pc PC(.rst_in(ms_riscv32_mp_rst_in),
                .ahb_ready_in(ms_riscv32_mp_instr_hready_in),
     	        .pc_src_in(pc_src),
    	        .epc_in(epc),
                .trap_address_in(trap_address),
   	        .branch_taken_in(branch_taken),
   	        .iaddr_in(iaddr[31:1]),
    	        .pc_in(pc),
     	        .pc_plus_4_out(pc_plus_4),
	        .misaligned_instr_out(misaligned_instr),
    	        .pc_mux_out(pc_mux),
		.i_addr_out(ms_riscv32_mp_imaddr_out)
               );
			   
   msrv32_reg_block_1 REG1 (.clk_in(ms_riscv32_mp_clk_in),
							.rst_in(ms_riscv32_mp_rst_in),
							.pc_mux_in(pc_mux),
							.pc_out(pc)
							);
     
   // ---------------------------------
   // PIPELINE STAGE 2
   // ---------------------------------       
   //Instruction_decoder
    //complete
   msrv32_instruction_decoder ID (.flush_in(flush),
								  .instr_in(ms_riscv32_mp_instr_in),
								  .opcode_out(opcode),
								  .funct3_out(funct3),
								  .funct7_out(funct7),
								  .rs1_addr_out(rs1_addr),
								  .rs2_addr_out(rs2_addr),
								  .rd_addr_out(rd_addr),
								  .csr_addr_out(csr_addr),
								  .instr_31_7_out(instr_31_to_7)
                                 );
    
    //complete
   msrv32_store_unit SU (
                         .funct3_in(funct3[1:0]), 
                         .ahb_ready_in(ms_riscv32_mp_data_hready_in),
                         .iadder_in(iaddr), 
                         .rs2_in(rs2),
                         .mem_wr_req_in(mem_wr_req),
                         .data_out(ms_riscv32_mp_dmdata_out),
                         .d_addr_out(ms_riscv32_mp_dmaddr_out),
                         .wr_mask_out(ms_riscv32_mp_dmwr_mask_out),
                         .wr_req_out(ms_riscv32_mp_dmwr_req_out),
                         .ahb_htrans_out(ms_riscv32_mp_data_htrans_out)
                        );
    
    //Decoder

   msrv32_dec DEC (
                   .opcode_in(opcode),
                   .funct7_5_in(funct7[5]),
                   .funct3_in(funct3),
                   .iadder_1_to_0_in(iaddr[1:0]),
                   .trap_taken_in(trap_taken),
                    
                   .alu_opcode_out(alu_opcode),
                   .mem_wr_req_out(mem_wr_req),
                   .load_size_out(load_size),
                   .load_unsigned_out(load_unsigned),
                   .alu_src_out(alu_src),
                   .iadder_src_out(iadder_src),
                   .csr_wr_en_out(csr_wr_en),
                   .rf_wr_en_out(rf_wr_en),
                   .wb_mux_sel_out(wb_mux_sel),
                   .imm_type_out(imm_type),
                   .csr_op_out(csr_op),
                   .illegal_instr_out(illegal_instr),
                   .misaligned_load_out(misaligned_load),
                   .misaligned_store_out(misaligned_store)
                  );
    
   //Immediate Generator

   msrv32_img IMG (
                   .instr_in(instr_31_to_7),
                   .imm_type_in(imm_type),
                   .imm_out(imm)
                  );
    

   // Immediate Adder
    //complete
   msrv32_immediate_adder imm_adder(.pc_in(pc),
									.rs1_in(rs1),
									.imm_in(imm),
									.iadder_src_in(iadder_src),
									.iadder_out(iaddr)

   );
    
   //Branch Unit

   msrv32_bu BU (
                 .opcode_6_to_2_in(opcode[6:2]),
                 .funct3_in(funct3),
                 .rs1_in(rs1),
                 .rs2_in(rs2),
                 .branch_taken_out(branch_taken)
                );
    
       
   //Integer File

   msrv32_integer_file IRF(
    
        .clk_in(ms_riscv32_mp_clk_in),
        .reset_in(ms_riscv32_mp_rst_in),
        .rs_1_addr_in(rs1_addr),
        .rs_2_addr_in(rs2_addr),    
        .rs_1_out(rs1),
        .rs_2_out(rs2),
        
        .rd_addr_in(rd_addr_reg),
        .wr_en_in(integer_wr_en_reg_file),
        .rd_in(wb_mux_out)

    );

//msrv32_integer_file IRF(ms_riscv32_mp_clk_in,ms_riscv32_mp_rst_in,rs2_addr,rd_addr_reg,integer_wr_en_reg_file,wb_mux_out,rs1_addr,rs1,rs2);
    
   msrv32_wr_en_generator WREN (.flush_in(flush),
							    .rf_wr_en_reg_in(rf_wr_en_reg),
								.csr_wr_en_reg_in(csr_wr_en_reg),
								.wr_en_integer_file_out(integer_wr_en_reg_file),
								.wr_en_csr_file_out(csr_wr_en_reg_file)
							   );
		
   //CSR file

   msrv32_csr_file CSRF(.clk_in(ms_riscv32_mp_clk_in),
						.rst_in(ms_riscv32_mp_rst_in),
						.wr_en_in(csr_wr_en_reg_file),
						.csr_addr_in(csr_addr_reg),
						.csr_op_in(csr_op_reg),
						.csr_uimm_in(imm_reg[4:0]),
						.csr_data_in(rs1_reg),
						.csr_data_out(csr_data),
						.pc_in(pc_reg2),
						.iadder_in(iadder_out_reg),
						.e_irq_in(ms_riscv32_mp_eirq_in),
						.t_irq_in(ms_riscv32_mp_tirq_in),
						.s_irq_in(ms_riscv32_mp_sirq_in),
						.i_or_e_in(i_or_e),
						.set_cause_in(set_cause),
						.cause_in(cause),
						.set_epc_in(set_epc),
						.instret_inc_in(instret_inc),
						.mie_clear_in(mie_clear),
						.mie_set_in(mie_set),
						.misaligned_exception_in(misaligned_exception),
						.mie_out(mie),
						.meie_out(meie),
						.mtie_out(mtie),
						.msie_out(msie),
						.meip_out(meip),
						.mtip_out(mtip),
						.msip_out(msip),
						.real_time_in(ms_riscv32_mp_rc_in),
						.epc_out(epc),
						.trap_address_out(trap_address)

    );
    
    //Machine Control
   
   msrv32_machine_control MC(

        .clk_in(ms_riscv32_mp_clk_in),
        .reset_in(ms_riscv32_mp_rst_in),
        
        .illegal_instr_in(illegal_instr),
        .misaligned_instr_in(misaligned_instr),
        .misaligned_load_in(misaligned_load),
        .misaligned_store_in(misaligned_store),
        
        .opcode_6_to_2_in(opcode[6:2]),
        .funct3_in(funct3),
        .funct7_in(funct7),
        .rs1_addr_in(rs1_addr),
        .rs2_addr_in(rs2_addr),
        .rd_addr_in(rd_addr),
        
        .e_irq_in(ms_riscv32_mp_eirq_in),
        .t_irq_in(ms_riscv32_mp_tirq_in),
        .s_irq_in(ms_riscv32_mp_sirq_in),
        
        .i_or_e_out(i_or_e),   //i_or_e use this local wire
        .set_cause_out(set_cause), //   set_cause use this local wire

        .cause_out(cause),   //cause use this local wire
        .set_epc_out(set_epc), //set_epc use this local wire
        .instret_inc_out(instret_inc), //instret_inc use this local wire
        .mie_clear_out(mie_clear), //mie_clear use this local wire
        .mie_set_out(mie_set), //mie_set use this local wire
        .misaligned_exception_out(misaligned_exception), //misaligned_exception use this local wire
        .mie_in(mie),   //mie use this local wire
        .meie_in(meie),
        .mtie_in(mtie),
        .msie_in(msie),
        .meip_in(meip),
        .mtip_in(mtip),
        .msip_in(msip),
        
        .pc_src_out(pc_src),
        
        .flush_out(flush),
        
        .trap_taken_out(trap_taken)

   );    

    
   // Stages 1/2 interface registers
   msrv32_reg_block_2  REG2 (
                             .rd_addr_in(rd_addr),
	                     .csr_addr_in(csr_addr),
	                     .rs1_in(rs1),
	                     .rs2_in(rs2),
	                     .pc_in(pc),
	                     .pc_plus_4_in(pc_plus_4),
	                     .iadder_in(iaddr),
	                     .imm_in(imm),
	                     .alu_opcode_in(alu_opcode),
	                     .load_size_in(load_size),
	                     .wb_mux_sel_in(wb_mux_sel),
	                     .csr_op_in(csr_op),
	                     .load_unsigned_in(load_unsigned),
	                     .alu_src_in(alu_src),
	                     .csr_wr_en_in(csr_wr_en),
	                     .rf_wr_en_in(rf_wr_en),
	                     .branch_taken_in(branch_taken),
	    
		 	     .clk_in(ms_riscv32_mp_clk_in),
	                     .reset_in(ms_riscv32_mp_rst_in),

                             .rd_addr_reg_out(rd_addr_reg),
	                     .csr_addr_reg_out(csr_addr_reg),
	                     .rs1_reg_out(rs1_reg),
                             .rs2_reg_out(rs2_reg),
	                     .pc_reg_out(pc_reg2),
	                     .pc_plus_4_reg_out(pc_plus_4_reg),
	                     .iadder_out_reg_out(iadder_out_reg),
	                     .imm_reg_out(imm_reg),
	                     .alu_opcode_reg_out(alu_opcode_reg),
	                     .load_size_reg_out(load_size_reg),
	                     .wb_mux_sel_reg_out(wb_mux_sel_reg),
	                     .csr_op_reg_out(csr_op_reg),
	                     .load_unsigned_reg_out(load_unsigned_reg),
	                     .alu_src_reg_out(alu_src_reg),   // 
	                     .csr_wr_en_reg_out(csr_wr_en_reg),
	                     .rf_wr_en_reg_out(rf_wr_en_reg)
                            );
    
   // ---------------------------------
   // PIPELINE STAGE 3
   // ---------------------------------
    
   // Load Unit

   msrv32_lu LU (
                 .load_size_in(load_size_reg),
                 .clk_in(ms_riscv32_mp_clk_in),
                 //.misaligned_load_in(misaligned_load),
                 .load_unsigned_in(load_unsigned_reg),
                 .data_in(ms_riscv32_mp_data_in),
                 .iadder_1_to_0_in(iadder_out_reg[1:0]),
                 .lu_output(lu_output),
                 .ahb_resp_in(ms_riscv32_mp_hresp_in)
                );

    
      
   //ALU

   msrv32_alu ALU (
                   .op_1_in(rs1_reg),
                   .op_2_in(alu_2nd_src_mux),
                   .opcode_in(alu_opcode_reg),
                   .result_out(alu_result)
                  );    
    
   msrv32_wb_mux_sel_unit WBMUX(.wb_mux_sel_reg_in(wb_mux_sel_reg), 
                                .alu_result_in(alu_result),.lu_output_in(lu_output),.imm_reg_in(imm_reg),
			                    .iadder_out_reg_in(iadder_out_reg),.csr_data_in(csr_data),.pc_plus_4_reg_in(pc_plus_4_reg),.rs2_reg_in(rs2_reg),   
			                    .alu_source_reg_in(alu_src_reg),
			                    .wb_mux_out(wb_mux_out), 
				                .alu_2nd_src_mux_out(alu_2nd_src_mux));   
   
    
endmodule


/*

module ms_riscv32_mp_tb();

reg mp_clk_in,mp_rst_in,mp_instr_hready_in,mp_data_hready_in,mp_eirq_in,mp_tirq_in,mp_sirq_in,mp_hresp_in;
reg [3:0]mp_dmwr_mask_in;
reg [31:0]mp_dmdata_in,mp_instr_in;
reg [63:0]mp_rc_in;

wire  mp_dmwr_req_out;
wire [31:0]mp_imaddr_out,mp_dmaddr_out,mp_dmdata_out;
wire [1:0]mp_data_htrans_out;
wire [3:0]mp_dmwr_mask_out;

msrv32_top DUT(
      mp_clk_in,
       mp_rst_in,
      
   // connection with Real Time Counter
         mp_rc_in,
     
   // connections with Instruction Memory
      mp_imaddr_out,
        mp_instr_in,
       mp_instr_hready_in,           //AHB ready

   // connections with Data Memory
       mp_dmaddr_out,
	 mp_dmdata_out,
              mp_dmwr_req_out,
        mp_dmwr_mask_out,
       mp_dmdata_in,
       mp_data_hready_in,            //AHB ready
       mp_hresp_in,                  //AHB response
       mp_data_htrans_out,     //AHB data trans
     
   //connections with Interrupt Controller
       mp_eirq_in,
       mp_tirq_in,
       mp_sirq_in
    );


//Parameter constants

parameter tsetup=2,thold=2,cycle=10;

parameter ADD=4'b0000, SUB=4'b0001,XOR=4'b0010,OR=4'b0011, AND=4'b0100, SLL=4'b0101, SRL=4'b0110, SRA=4'b0111, SLT=4'b1000, SLTU=4'b1001;

parameter ADDi=4'b0000, XORi=4'b0001, ORi=4'b0010, ANDi=4'b0011, SLLi=4'b0100, SRLi=4'b0101, SRAi=4'b0110, SLTi=4'b0111, SLTUi=4'b1000;

parameter LB=3'b000, LH=3'b001, LW=3'b010, LBU=3'b011, LHU=3'b100;

parameter SB=2'b00,SH=2'b01, SW=2'b10;

parameter BEQ=3'b000, BNE=3'b001, BLT=3'b010, BGE=3'b011, BLTU=3'b100, BGTE=3'b101;


//Clock generation

initial
begin
	mp_clk_in=1'b0;
forever
	#(cycle/2) mp_clk_in=~mp_clk_in;
end
//Initialize

task initialize;
begin
	mp_rst_in=1'b0;
	mp_rc_in=64'd0;
	mp_instr_hready_in=1'b0;
	mp_dmdata_in=32'd0;
	mp_data_hready_in=1'b0;
	mp_hresp_in=1'b0;
	mp_eirq_in=1'b0;
	mp_tirq_in=1'b0;
	mp_sirq_in=1'b0;
end
endtask

//Reset task

task reset_dut;
begin:r1
	integer i;
	mp_rst_in=1'b1;
	repeat(2)
	@(posedge mp_clk_in);
	#thold;

	if(mp_imaddr_out !== 32'd0)
	begin
		$display("Program counter address is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	for(i=0;i<32;i=i+1)
	begin
		if(DUT.IRF.reg_file[i] !== 32'd0)
		begin
			$display("Processors registers are not reset properly");
			$display("Error at time %t", $time); 
			$stop;
		end
	end
	if(DUT.MC.misaligned_exception_out !== 1'd0)
	begin
		$display("Machine controls misaligned_exception out is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MS.mie_out != 1'b0 || DUT.CSRF.MS.mpie_out != 1'b1)
	begin
		$display("CSR files Mstatus Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end 
	if(DUT.CSRF.MIE_REG.meie != 1'b0 || DUT.CSRF.MIE_REG.mtie != 1'b0 || DUT.CSRF.MIE_REG.msie != 1'b0)
	begin
		$display("CSR files MIE Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MTVEC_REG.mtvec_mode != 2'b0 || DUT.CSRF.MTVEC_REG.mtvec_base != 30'b0)
	begin
		$display("CSR files MIVEC Registers is not reset properly");
		$display("Error at time %t ",$time);
		$stop;
	end 
	if(DUT.CSRF.MM_REG.mscratch_out != 32'd0 || DUT.CSRF.MM_REG.mepc_out != 32'd0)
	begin
		$display("CSR files MEPC and Mscratch Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end 
	if(DUT.CSRF.MCAUSE_REG.cause_out != 4'b0000 || DUT.CSRF.MCAUSE_REG.cause_rem != 27'b0 || DUT.CSRF.MCAUSE_REG.int_or_exc_out != 1'b0)
	begin
		$display("CSR files MCAUSE Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MIP_REG.meip_out != 1'b0 || DUT.CSRF.MIP_REG.mtip_out != 1'b0 || DUT.CSRF.MIP_REG.msip_out != 1'b0)
	begin
		$display("CSR files MIP Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MTVAL_REG.mtval_out != 32'd0)
	begin 
		$display("CSR files MTVAL Registers is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MCS.mcountinhibit_cy_out != 1'b0 || DUT.CSRF.MCS.mcountinhibit_ir_out != 1'b0)
	begin
		$display("CSR files Machine Counter Setup is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MCS.mcountinhibit_cy_out != 1'b0 || DUT.CSRF.MCS.mcountinhibit_ir_out != 1'b0)
	begin
		$display("CSR files Machine Counter Setup is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.CSRF.MC.mcycle_out != 64'b0 || DUT.CSRF.MC.minstret_out != 64'b0 || DUT.CSRF.MC.mtime_out != 64'b0 )
	begin
		$display("CSR files Machine Counter is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	if(DUT.REG2.rd_addr_reg_out != 5'b00000 || DUT.REG2.csr_addr_reg_out != 12'b000000000000 || DUT.REG2.rs1_reg_out != 32'h00000000|| DUT.REG2.rs2_reg_out != 32'h00000000 || DUT. REG2.pc_reg_out != 32'b0 || DUT.REG2.pc_plus_4_reg_out != 32'h00000000 || DUT.REG2.iadder_out_reg_out != 32'h00000000|| DUT.REG2.alu_opcode_reg_out != 4'b0000 || DUT.REG2.load_size_reg_out != 2'b00|| DUT.REG2.load_unsigned_reg_out != 1'b0 || DUT.REG2.alu_src_reg_out != 1'b0|| DUT.REG2.csr_wr_en_reg_out != 1'b0 || DUT.REG2.rf_wr_en_reg_out != 1'b0 || DUT.REG2.wb_mux_sel_reg_out != 3'b000 || DUT.REG2.csr_op_reg_out != 3'b000 || DUT.REG2.imm_reg_out != 32'h00000000)
	begin
		$display("Reg_block_2 is not reset properly");
		$display("Error at time %t", $time);
		$stop;
	end
	$display("RESET is perfect for RISCV IP core\n\n");
	mp_rst_in= 1'b0;
	#(cycle - thold - tsetup);
end:r1
endtask


//R type instruction

task automatic Rtype_inst(input [3:0] operation);
begin:R1
	reg signed [31:0]op1;
	reg signed [31:0]op2;
	reg [6:0]Opcode;
	reg [2:0]funct3;
	reg [6:0] funct7;
	reg [4:0]rs1;
	reg [4:0]rs2;
	reg [4:0]rd;
	reg [31:0] result;
	reg [4*8:0]string_cmd;
	op1={$random}%16;
	op2={$random}%16;
	Opcode=7'b011_0011;
	funct3=3'b000;
	funct7=7'b000_0000;
	rs1=5'd2;
	rs2=5'd3;
	rd=5'd5;
	DUT.IRF.reg_file[rs1]=op1;
	DUT.IRF.reg_file[rs2]=op2;
	mp_instr_hready_in=1'b1;
	case(operation)
		ADD:
		begin
			result=op1+op2;
			string_cmd="ADD";
		end
		SUB:
		begin
			funct7=7'b010_0000;
			result=op1-op2;
			string_cmd="SUB";
		end
		XOR:
		begin
			funct3=3'b100;
			result=op1^op2;
			string_cmd="XOR";
		end
		OR:	
		begin
			funct3=3'b110;
			result=op1|op2;
			string_cmd="OR";
		end
		AND:
		begin
			funct3=3'b111;
			result=op1&op2;
			string_cmd="AND";
		end
		SLL:
		begin
			funct3=3'b001;
			result=op1<<op2;
			string_cmd="SLL";
		end
		SRL:
		begin
			funct3=3'b101;
			result=op1>>op2;
			string_cmd="SRL";
		end
		SRA:
		begin
			funct3=3'b101;
			funct7=7'b010_0000;
			result=op1>>>op2;
			string_cmd="SRA";
		end
		SLT:
		begin
			funct3=3'b010;
			result=op1<op2?32'd1:32'd0;
			result=op1[31]^op2[31]?op1[31]:(op1<op2 ? 32'd1 : 32'd0);
			string_cmd="SLT";
		end
		SLTU:
		begin
			funct3=3'b011;
			result=op1<op2?32'd1:32'd0;
			string_cmd="SLTU";
		end
	endcase
		mp_instr_in={funct7, rs2, rs1, funct3, rd, Opcode};
		@(posedge mp_clk_in);
		#thold;
		if(DUT.ALU.result_out != result)
		begin
			$display("The R Type %s instruction is not working",string_cmd);
			$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The R Type instruction %s is working perfect", string_cmd);
		$display ("The Program counter is byte addressable >> PC=%d",mp_imaddr_out);
		$display("The operands RS1 %d \t -RS2 %d and the result Expected %d and SAMPLED DUT result %d",op1,op2,result,DUT.ALU.result_out);
		$display("the address from PC is %d and iadder_out %d",DUT.PC.pc_mux_out,DUT.PC.i_addr_out);
		mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask



//I type instruction

task automatic Itype_inst(input [3:0] operation);
begin:i1

	reg signed [31:0]op1;
	reg [6:0]Opcode;
	reg [2:0] funct3;
	reg [4:0] rs1;
	reg [11:0]immi;
	reg [4:0]rd;
	reg [31:0] resulti;
	reg [5*8:0] string_cmd;
	reg [31:0] IMMI;
	op1={$random}%16;
	Opcode=7'b001_0011;
	funct3=3'b000;
	rs1=5'd2;
	immi={$random}%(2**10);
	rd=5'd5;
	IMMI=immi[11]?({{20{1'b1}},immi}):({{20{1'b0}},immi});
	DUT.IRF.reg_file[rs1]=op1;
	mp_instr_hready_in=1'b1;
	case(operation)
	ADDi:
	begin
		resulti=op1+IMMI;
		string_cmd="ADDi";
	end
	XORi:
	begin
		funct3=3'b100;
		resulti=op1^IMMI;
		string_cmd="XORi";
	end
	ORi:
	begin
		funct3=3'b110;
		resulti=op1|IMMI;
		string_cmd="ORi";
	end	
	ANDi:
	begin
		funct3=3'b111;
		resulti=op1&IMMI;
		string_cmd="ANDi";
	end
	SLLi:
	begin
		funct3=3'b001;
		resulti=op1<<IMMI[4:0];
		immi={7'b000_0000,immi[4:0]};
		string_cmd="SLLi";
	end
	SRLi:
	begin
		funct3=3'b101;
		resulti=op1>>IMMI[4:0];
		immi={7'b000_0000,immi[4:0]};
		string_cmd="SRLi";
	end
	SRAi:
	begin
		funct3=3'b101;
		resulti=op1>>>IMMI[4:0];
		immi={7'b000_0000,immi[4:0]};
		string_cmd="SRAi";
	end
	SLTi:
	begin
		funct3=3'b010;
		resulti=op1[31]^IMMI[31]?op1[31]:(op1<IMMI?32'd1:32'd0);
		string_cmd="SLTi";
	end
	SLTUi:
	begin
		funct3=3'b011;
		resulti=op1<IMMI?32'd1:32'd0;
		string_cmd="SLTUi";
	end
	endcase
	mp_instr_in={immi, rs1, funct3, rd, Opcode};
		@(posedge mp_clk_in);
		#thold;
		if(DUT.ALU.result_out != resulti)
		begin
			$display("The I Type %s instruction is not working",string_cmd);
			$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The I Type instruction %s is working perfect", string_cmd);
		$display ("The Program counter is byte addressable >> PC=%d",mp_imaddr_out);
		$display("The operands RS1 %d \t immediate %d and the result Expected %d and SAMPLED DUT result %d",op1,IMMI,resulti,DUT.ALU.result_out);
		mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask


//JAL type instruction

task automatic JAL_type_inst();
begin:j1
	reg [6:0]Opcode;
	reg [20:1]immi;
	reg [4:0]rd;
	reg [31:0]IMMJ;
	Opcode=7'b110_1111;
	immi=20'd12;
	rd=5'd6;
	mp_instr_hready_in=1'b1;
	IMMJ=immi[20]?{{11{1'b1}},immi[20:1],1'b0}:{{11{1'b0}},immi[20:1],1'b0};
	mp_instr_in={immi[20],immi[10:1],immi[11],immi[19:12],rd, Opcode};
	@(posedge mp_clk_in);
	#thold;
	if(DUT.IRF.rd_addr_in !== DUT.REG2.pc_plus_4_reg_out)
	begin
		$display("The JAL Type instruction is not working ");
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
	if(((DUT.REG1.pc_out)+IMMJ) !== mp_imaddr_out)
	begin
		$display("The JAL Type instruction is not working ");
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The JAL Type instruction is working perfect");
		$display ("The RD value =%d && PC\+4 value =%d",DUT.IRF.rd_in,DUT.REG2.pc_plus_4_reg_out);
		$display("The expected PC value =%d && sampled address value =%d",((DUT.REG1.pc_out)+IMMJ),mp_imaddr_out);
		mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask


//JALR type instruction

task automatic JALR_type_inst();
begin:J2
	reg [6:0]Opcode;
	reg [11:0]immi;
	reg [4:0]rd;
	reg [4:0]rs1;
	reg [31:0]IMMJI,rs1_out;
	Opcode=7'b110_0111;
	immi=12'd12;
	rd=5'd7;
	rs1=5'd2;
	mp_instr_hready_in=1'b1;
	IMMJI=immi[11]?{{20{1'b1}},immi}:{{20{1'b0}},immi};
	rs1_out={$random}%50;
	DUT.IRF.reg_file[rs1]={rs1_out[31:2],2'b00};
	mp_instr_in={immi,rs1,3'b000,rd, Opcode};
	@(posedge mp_clk_in);
	#thold;
	if(DUT.IRF.rd_addr_in !== DUT.REG2.pc_plus_4_reg_out)
	begin
		$display("The JALR Type instruction is not working with data");
		$display("the DUT value rd_in=%d and DUT pc_plus_4=%d",DUT.IRF.rd_in,DUT.REG2.pc_plus_4_reg_out);
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
	if(((DUT.IRF.rs_1_out)+IMMJI) !== mp_imaddr_out)
	begin
		$display("The JALR Type instruction is not working with address");
		//$display("the DUT value rd_in=%d and DUT pc_plus_4=%d",DUT.IRF.rd_addr_in,DUT.REG2.pc_plus_4_reg_out);
		//$display("the DUT value rd_in=%d and imaddr_out=%d and DUT pc_out=%d",DUT.REG1.pc_out,mp_imaddr_out,DUT.PC.pc_mux_out);

		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The JALR Type instruction is working perfect");
		$display ("The RD value =%d && PC\+4 value =%d",DUT.IRF.rd_in,DUT.REG2.pc_plus_4_reg_out);
		$display("The expected PC value =%d && sampled address value =%d",((DUT.REG1.pc_out)+IMMJI),mp_imaddr_out);
		mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask	


//Load upper Immediate type instruction 
task automatic LUI_type_inst();
begin:L1
	reg [6:0] Opcode;	
	reg [19:0]immi;
	reg [4:0]rd;
	reg [31:0] IMMU;	
	Opcode=7'b011_0111;
	immi={$random}%(2**10);
	rd=5'd8;
	mp_instr_hready_in=1'b1;
	mp_instr_in={immi,rd, Opcode};
	IMMU={immi,12'b0};
	$display("Immediate value=%d", IMMU);
	@(posedge mp_clk_in);
	#thold;
	@(posedge mp_clk_in);
	#thold;
	if(DUT.IRF.reg_file[rd] !== IMMU)
	begin
		$display("The U Type instruction is not working");
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
	$stop;
	end
		$display("The U Type instruction is working perfect");
		$display ("The RD value =%d && immediate values =%d are same",DUT.IRF.reg_file[rd],IMMU);
	mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask


//Load instruction

task automatic Load_inst(input [2:0]operation);
begin:LL
	reg signed [31:0]op1;
	reg [6:0]Opcode;
	reg [2:0] funct3;
	reg [4:0] rs1;
	reg [11:0]immi;
	reg [4:0]rd;
	reg [31:0] resultl;
	reg [5*8:0] string_cmd;
	reg [31:0] IMMI;
	reg [31:0] DataMem [0:1023];
	reg [31:0] temp_add;
	reg [7:0] data_byte;
	reg [15:0] data_half;
	op1={$random}%20;
	Opcode=7'b000_0011;
	funct3=3'b000;
	rs1=5'd2;
	immi={$random}%20;
	rd=5'd5;
	IMMI=immi[11]?{{20{1'b1}},immi}:{{20{1'b0}},immi};
	DUT.IRF.reg_file[rs1]=op1;
	DataMem[op1+IMMI]=32'hfedcba98;
	mp_dmdata_in=DataMem[op1+IMMI];
	mp_instr_hready_in=1'b1;
	mp_data_hready_in=1'b0;
	case(operation)
	LB:
	begin
		temp_add=op1+IMMI;
		case(temp_add[1:0])
			2'b00: data_byte=mp_dmdata_in[7:0];
			2'b01: data_byte=mp_dmdata_in[15:8];
			2'b10: data_byte=mp_dmdata_in[23:16];
			2'b11: data_byte=mp_dmdata_in[31:24];
		endcase
		resultl= {{24{data_byte[7]}},data_byte};
		string_cmd="LB";
	end
	LH:
	begin
		temp_add=op1+IMMI;
		case(temp_add[1])
			1'b0: data_half = mp_dmdata_in[15:0];
			1'b1: data_half = mp_dmdata_in[31:16];
		endcase
		resultl = {{16{data_half[15]}},data_half};
		funct3=3'b001;
		string_cmd="LH";
	end
	LW:
	begin
		temp_add=op1+IMMI;
		resultl=mp_dmdata_in;
		funct3=3'b010;
		string_cmd="LW";
	end
	LBU:
	begin
		temp_add=op1+IMMI;
		case(temp_add[1:0])
			2'b00: data_byte=mp_dmdata_in[7:0];
			2'b01: data_byte=mp_dmdata_in[15:8];
			2'b10: data_byte=mp_dmdata_in[23:16];
			2'b11: data_byte=mp_dmdata_in[31:24];
		endcase
		resultl= {24'b0,data_byte};
		funct3=3'b100;
		string_cmd="LBU";
	end
	LHU:
	begin
		temp_add=op1+IMMI;
		case(temp_add[1])
			1'b0: data_half = mp_dmdata_in[15:0];
			1'b1: data_half = mp_dmdata_in[31:16];
		endcase
		resultl = {16'b0,data_half};
		funct3=3'b101;
		string_cmd="LHU";
	end
	endcase
	mp_instr_in = {immi,rs1,funct3,rd,Opcode};
	repeat(3)
	@(posedge mp_clk_in);
	#thold;
	if(DUT.LU.lu_output !== resultl)
	begin
		$display("The Load Type instruction %s is not working",string_cmd);
		$display("from tb result %d and from dut %h and op1 %h",resultl,DUT.LU.lu_output,op1);
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The Load Type instruction %s is working perfect",string_cmd);
		$display ("The result EXEPECTED in load unit =%h && sampled DUT result in LU =%h",resultl,DUT.LU.lu_output);
	mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask


//Store instruction

task automatic Store_inst(input [2:0] operation);
begin:S1
	reg signed [31:0]op1;
	reg signed [31:0]op2;
	reg [6:0] Opcode;
	reg [2:0] funct3;
	reg [4:0] rs2;
	reg [4:0] rs1;
	reg [11:0]immi;
	reg [4:0]rd;
	reg [31:0] results;
	reg [5*8:0] string_cmd;
	reg [31:0] IMMI;
	reg [31:0] DataMem [0:1023];
	reg [31:0] temp_add;
	reg [31:0] temp_add2;
	reg [31:0] byte_dout;
	reg [31:0] halfword_dout;
	op1={$random}%20;
	op2=32'h12345678;
	Opcode=7'b010_0011;
	funct3=3'b000;
	rs2=5'd5;
	rs1=5'd2;
	immi=12'd10;
	rd=5'd8;
	IMMI=immi[11]?{{20{1'b1}},immi}:{{20{1'b0}},immi};
	DUT.IRF.reg_file[rs1]=op1;
	DUT.IRF.reg_file[rs2]=op2;
	mp_instr_hready_in=1'b1;
	mp_data_hready_in=1'b1;
	temp_add=op1+IMMI;
	temp_add2={temp_add[31:2],2'b00};
	case(operation)
	SB:
	begin
		case(temp_add[1:0])
			2'b00: byte_dout={8'b0,8'b0,8'b0,op2[7:0]};
			2'b01: byte_dout={8'b0,8'b0,op2[15:3],8'b0};
			2'b10: byte_dout={8'b0,op2[23:16],8'b0,8'b0};
			2'b11: byte_dout={op2[31:24],8'b0,8'b0,8'b0};
			default:byte_dout = 32'b0;
		endcase
		results=byte_dout;
		string_cmd="SB";
	end
	SH:
	begin
		case(temp_add[1])
			1'b0:halfword_dout ={16'b0, op2[15:0]};
			1'b1:halfword_dout ={op2[31:16],16'b0};
			default:halfword_dout = 32'b0;
		endcase
		results=halfword_dout;
		funct3=3'b001;
		string_cmd="SH";
	end
	SW:
	begin
		results=op2;
		funct3=3'b010;
		string_cmd="SW";
	end
	endcase
	mp_instr_in={immi[11:5], rs2, rs1, funct3,immi[4:0], Opcode};
	repeat(2)
	@(posedge mp_clk_in);
	#thold
	if(DUT.SU.data_out !== results)
	begin
		$display("The Store Type of %s instruction is not working",string_cmd);
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888        d88888     888888888     688");
			$display("888              68888888       089        888"); 
			$display("d8B            88888888888      888        888");
			$display("888      	8888     8888     888        888");
			$display("88888888     6880 	 8888 	  881        888");
			$display("888         d8ap       6888     888        888");
			$display("888        desen88888888888     888        888");
			$display("888       dasp         8888     888        868");
			$display("888      8888          8888  888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		$display("The Store Type instruction %s is working perfect",string_cmd);
		$display("the Expected address is =%h and sampled DUT result in immediate adder = %h",temp_add2,DUT.SU.d_addr_out);
		$display ("The result EXEPECTED in store unit =%h && sampled DUT result in LU =%h",results,DUT.SU.data_out);
	mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask


//BType instruction

task automatic B_type_inst(input [2:0]operation);
begin:B1
	reg signed [31:0]op1;
	reg signed [31:0]op2;
	reg [6:0] Opcode;
	reg [2:0] funct3;
	reg [4:0] rs2;
	reg [4:0]rs1;
	reg [12:0]immi;
	reg [4:0]rd;
	reg [31:0] resultb;
	reg [5*8:0] string_cmd;
	reg [31:0]IMMB;
	reg branch_taken;
	op1={$random};
	op2={$random};
	Opcode=7'b110_0011;
	funct3=3'b000;
	rs2=5'd5;
	rs1=5'd2;
	immi=13'd12;
	rd=5'd8;
	branch_taken=1'b0;
	IMMB=immi[12]?{{19{1'b1}},immi[12:1],1'b0}:{{19{1'b0}},immi[12:1],1'b0};
	DUT.IRF.reg_file[rs1]=op1;
	DUT.IRF.reg_file[rs2]=op2;
	mp_instr_hready_in=1'b1;
	case(operation)
	BEQ: 
	begin
		funct3=3'b000;
		if(DUT.IRF.reg_file[rs1]==DUT.IRF.reg_file[rs2])
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BEQ";
	end
	BNE:
	begin
		funct3=3'b001;
		if(DUT.IRF.reg_file[rs1]!=DUT.IRF.reg_file[rs2])
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BNE";
	end
	BLT:
	begin
		funct3=3'b100;
		if(DUT.IRF.reg_file[rs1][31]^DUT.IRF.reg_file[rs2][31]?DUT.IRF.reg_file[rs1][31]:(DUT.IRF.reg_file[rs1]<(DUT.IRF.reg_file[rs2])))
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BLT";
	end
	BGE:
	begin
		funct3=3'b101;
		if(DUT.IRF.reg_file[rs1][31]^DUT.IRF.reg_file[rs2][31]?!(DUT.IRF.reg_file[rs1][31]):!(DUT.IRF.reg_file[rs1]<(DUT.IRF.reg_file[rs2])))
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BGE";
	end
	BLTU:
	begin
		funct3=3'b110;
		if(DUT.IRF.reg_file[rs1]<DUT.IRF.reg_file[rs2])
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BLTU";
	end
	BGTE:
	begin
		funct3=3'b111;
		if(!(DUT.IRF.reg_file[rs1]<DUT.IRF.reg_file[rs2]))
			branch_taken=1'b1;
		else
			branch_taken=1'b0;
		string_cmd="BGTE";
	end
	endcase
	mp_instr_in={immi[12],immi[10:5] ,rs2, rs1, funct3,immi[4:1],immi[11], Opcode};
	repeat(2)
	@(posedge mp_clk_in);
	#thold
	if(DUT.BU.branch_taken_out !== branch_taken)
	begin
		$display("The B_Type of %s instruction is not working",string_cmd);
		$display("the rs1=%d rs2=%d branch taken=%d branch taken dut=%d and DUT RS1 %d and DUT RS2 %d",DUT.IRF.reg_file[rs1],DUT.IRF.reg_file[rs2],branch_taken,DUT.BU.branch_taken_out,DUT.BU.rs1_in,DUT.BU.rs2_in);
		$display("Error at tame %t", $time);
			$display("---------------------------------------------------------");
			$display("8888888888       d8888     888888888     688");
			$display("888             6888888       089        888"); 
			$display("d8B            888888888      888        888");
			$display("888      	888    888      888        888");
			$display("88888888     880     888 	881        888");
			$display("88888888    8ap888888888      888        888");
			$display("888        esen888888888      888        888");
			$display("888       asp        888      888        868");
			$display("888      888         888   888888888     8888888888");
			$display("---------------------------------------------------------");
			$stop;
		end
		if(branch_taken==1'b1)
			resultb=DUT.REG1.pc_out+IMMB;
		else
			resultb=DUT.PC.pc_mux_out;
	
		$display("the Expected address is =%h and sampled DUT result in immediate adder = %h",resultb,mp_imaddr_out);
		
	mp_instr_hready_in=1'bx;
		#(cycle-thold-tsetup);
end
endtask
	


task flush;
begin

	//Flush in with an instruction (NOP)
	mp_instr_in=32'h000013;
	mp_instr_hready_in=1'b1;
	@(posedge mp_clk_in);
	#thold;
	$display("The Program counter is byte addressable during flush >> PC=%d",mp_imaddr_out);
	#(cycle-thold-tsetup);
end
endtask


task flush_1;
begin

	//Flush in with an instruction (NOP)
	mp_instr_in=32'h000013;
	mp_instr_hready_in=1'b1;
	@(posedge mp_clk_in);
	#thold;
	#(cycle-thold-tsetup);
end
endtask


initial
begin
	initialize;
	$display("\n\n\n");
	$display("**********LOAD TYPE TESTCASE*********");
	reset_dut;
	#20;
	repeat(3)
	begin
		flush_1;
		Load_inst({$random}%5);
	end
	$display("********LOAD_TYPE TESTCASE PASSED***********");
	$display("\n\n\n");
	$display("***R TYPE TESTCASE********");
	reset_dut;
	#10	
	reset_dut;
	repeat(10)
	begin
		flush;
		Rtype_inst({$random}%10);
	end
	$display("*****R TYPE TESTCASE PASSED****");
	$display("\n\n\n");
	$display("*****I_TYPE TESTCASE********");
	reset_dut;
	repeat(10)
	begin
		flush;
		Itype_inst({$random}%19);
	end
	$display("****I TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	$display("**********STORE TYPE TESTCASE*********");
	reset_dut;
	repeat(5)
	begin
		flush_1;
		Store_inst({$random}%3);
	end
	$display("****STORE TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	$display("**********JAL TYPE TESTCASE*********");
	reset_dut;
	repeat(10)
	begin
		flush_1;
		JAL_type_inst;
	end
	$display("****JAL_TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	$display("**********JALR TYPE TESTCASE*********");
	reset_dut;
	repeat(10)
	begin
		flush_1;
		JALR_type_inst;
	end
	$display("****JALR TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	$display("**********LUI TYPE TESTCASE*********");
	reset_dut;
	repeat(10)
	begin
		flush_1;
		LUI_type_inst;
	end
	$display("****LUI TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	$display("**********B_TYPE TESTCASE*********");
	reset_dut;
	repeat(10)
	begin
		flush_1;
		B_type_inst({$random}%7);
	end
	$display("****B TYPE TESTCASE PASSED*******");
	$display("\n\n\n");
	//reset_dut;
	$display("*************RISC-V PROCESSOR CORE VERIFICATION PASSED**************");
	$display("--------------------------------------------------------------------");
	$display("8883888658        das8as   .desaAab.       .d8888b.                 ");
	$display("888    yaab      d888888  deepA  AYaab   daAap  Oyaab               ");
	$display("888     888     6888 888  YaebA          AS88P                      ");
	$display("888    dsap    dasp  888   Yasab.         Y888b                     ");
	$display("880Y68bPPP    D888   777      YS78O          OU88J                  ");
	$display("888          deap    898        OGHPO          POJNN                ");
	$display("888         d88888888888         PYa8b           Od88P              ");
	$display("888        888P      88P HSKX    UU4GG   SDJJH   GHSUI              ");
	$display("888       8788       887   *SS4SCHB*       *DSHDBHB*                ");
	$display("--------------------------------------------------------------------");
	#100 $finish;

end
endmodule

*/