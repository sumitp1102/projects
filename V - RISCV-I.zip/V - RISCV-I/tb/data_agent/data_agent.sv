class data_agent extends uvm_agent;

	`uvm_component_utils(data_agent)

	data_driver drvh;
	data_monitor monh;
	data_sequencer seqrh;
	data_config m_cfg;

	function new(string name="data_agent",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(data_config)::get(this,"","data_config",m_cfg))
			`uvm_fatal("data_agent","configuration getting failed")


		monh=data_monitor::type_id::create("monh",this);

		if(m_cfg.is_active)
		begin
			drvh=data_driver::type_id::create("drvh",this);
			seqrh=data_sequencer::type_id::create("seqrh",this);
		end
	endfunction

	function void connect_phase(uvm_phase phase);
		if(m_cfg.is_active)
			drvh.seq_item_port.connect(seqrh.seq_item_export);

	endfunction


endclass
