class data_config extends uvm_object;

	`uvm_object_utils(data_config)

	uvm_active_passive_enum is_active;

	virtual msrv32_ahb_data_if vif;

	function new(string name="data_config");
		super.new(name);
	endfunction

endclass
