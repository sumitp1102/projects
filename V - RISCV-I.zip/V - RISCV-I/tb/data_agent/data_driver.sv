class data_driver extends uvm_driver#(data_trans);

	`uvm_component_utils(data_driver)

	data_config m_cfg;
	
	virtual msrv32_ahb_data_if.DRV_MP vif;


	function new(string name="data_driver",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		
		if(!uvm_config_db#(data_config)::get(this,"","data_config",m_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

	endfunction

	function void connect_phase(uvm_phase phase);

		vif=m_cfg.vif;

	endfunction

	task run_phase(uvm_phase phase);

		forever
		begin
			seq_item_port.get_next_item(req);
			`uvm_info(get_type_name(),$sformatf("from data driver %s",req.sprint),UVM_LOW)
			send_to_dut(req);
			seq_item_port.item_done();

		end

	endtask

	task send_to_dut(data_trans xtn);

		@(vif.drv_cb);
		vif.drv_cb.ms_riscv32_mp_data_hready_in<=xtn.ms_riscv32_mp_data_hready_in;
		vif.drv_cb.ms_riscv32_mp_hresp_in<=xtn.ms_riscv32_mp_hresp_in;
		vif.drv_cb.ms_riscv32_mp_data_in<=xtn.ms_riscv32_mp_data_in;

		@(vif.drv_cb);
		//vif.drv_cb.ms_riscv32_mp_hresp_in<=1;
		vif.drv_cb.ms_riscv32_mp_data_hready_in<=0;

		//repeat(2)
		//@(vif.drv_cb);
	endtask
endclass