class data_monitor extends uvm_monitor;

	`uvm_component_utils(data_monitor)

	uvm_analysis_port#(data_trans) analysis_port;

	virtual msrv32_ahb_data_if.MON_MP vif;

	data_trans data_xtn;

	data_config m_cfg;

	function new(string name="data_monitor",uvm_component parent);
		super.new(name,parent);
		analysis_port=new("analysis_port",this);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(data_config)::get(this,"","data_config",m_cfg))
			`uvm_fatal(get_type_name(),"interface gettig failed")
		
	endfunction


	function void connect_phase(uvm_phase phase);
		vif=m_cfg.vif;

	endfunction

	task run_phase(uvm_phase phase);
		forever
		begin
			@(vif.mon_cb);
			collect_data;
		end

	endtask

	task collect_data;
		data_xtn=data_trans::type_id::create("xtn");
		if(vif.mon_cb.ms_riscv32_mp_data_hready_in==1'b1)
		begin
			data_xtn.ms_riscv32_mp_data_hready_in=vif.mon_cb.ms_riscv32_mp_data_hready_in;
			data_xtn.ms_riscv32_mp_hresp_in=vif.mon_cb.ms_riscv32_mp_hresp_in;
			data_xtn.ms_riscv32_mp_data_in=vif.mon_cb.ms_riscv32_mp_data_in;
			data_xtn.ms_riscv32_mp_dmaddr_out=vif.mon_cb.ms_riscv32_mp_dmaddr_out;
			data_xtn.ms_riscv32_mp_dmdata_out=vif.mon_cb.ms_riscv32_mp_dmdata_out;
			data_xtn.ms_riscv32_mp_dmwr_req_out=vif.mon_cb.ms_riscv32_mp_dmwr_req_out;
    			data_xtn.ms_riscv32_mp_dmwr_mask_out=vif.mon_cb.ms_riscv32_mp_dmwr_mask_out;
			`uvm_info(get_type_name(),$sformatf("from data monitor %s",data_xtn.sprint),UVM_LOW)
			analysis_port.write(data_xtn);

		end
		
		@(vif.mon_cb);
	
	endtask		
endclass
