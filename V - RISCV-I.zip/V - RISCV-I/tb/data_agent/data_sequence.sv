class data_sequence extends uvm_sequence#(data_trans);

	`uvm_object_utils(data_sequence)

	env_config env_cfg;

	function new(string name="data_sequence");
		super.new(name);
	endfunction

	task body;
		req=data_trans::type_id::create("req");
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b0;ms_riscv32_mp_hresp_in==1'b1;ms_riscv32_mp_data_in==32'd0;});
			finish_item(req);
		end
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b0;ms_riscv32_mp_hresp_in==1'b1;ms_riscv32_mp_data_in==32'd0;});
			finish_item(req);
		end
	endtask


endclass

class data_s_sequence extends uvm_sequence#(data_trans);

	`uvm_object_utils(data_s_sequence)

	env_config env_cfg;

	function new(string name="data_s_sequence");
		super.new(name);
	endfunction

	task body;
		req=data_trans::type_id::create("req");
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b0;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==32'd0;});
			finish_item(req);
		end
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b1;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b1;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		start_item(req);
		assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b1;ms_riscv32_mp_hresp_in==1'b1;ms_riscv32_mp_data_in==env_cfg.data_in;});
		finish_item(req);
		//#10ns;

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {ms_riscv32_mp_data_hready_in==1'b0;ms_riscv32_mp_hresp_in==1'b0;ms_riscv32_mp_data_in==32'd0;});
			finish_item(req);
		end

	endtask

endclass


