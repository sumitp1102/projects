class data_sequencer extends uvm_sequencer#(data_trans);

	`uvm_component_utils(data_sequencer)

	function new(string name="data_sequencer",uvm_component parent);
		super.new(name,parent);
	endfunction

endclass