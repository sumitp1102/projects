class data_trans extends uvm_sequence_item;

	`uvm_object_utils(data_trans)

	rand logic [31:0]ms_riscv32_mp_data_in;
	rand logic ms_riscv32_mp_data_hready_in,ms_riscv32_mp_hresp_in;

 	bit [31:0] ms_riscv32_mp_dmaddr_out;
	bit [31:0] ms_riscv32_mp_dmdata_out;
 	bit [3:0 ] ms_riscv32_mp_dmwr_mask_out;

//Newly created please check with alistair
//	bit [3:0 ] ms_riscv32_mp_dmwr_out;

 	bit ms_riscv32_mp_dmwr_req_out;
 	bit [1:0] ms_riscv32_mp_data_htrans_out;

	//constraint a1{ms_riscv32_mp_data_in inside{[1:500]};}

	function new(string name="data_trans");
		super.new(name);
	endfunction

	function void do_print(uvm_printer printer);
	
		printer.print_field("data_in",ms_riscv32_mp_data_in,32,UVM_DEC);
		printer.print_field("data_hready",ms_riscv32_mp_data_hready_in,1,UVM_DEC);
		printer.print_field("mp_hresp",ms_riscv32_mp_hresp_in,1,UVM_DEC);
		printer.print_field("dm_addr_out",ms_riscv32_mp_dmaddr_out,32,UVM_DEC);
		printer.print_field("dm_data_out",ms_riscv32_mp_dmdata_out,32,UVM_DEC);
		printer.print_field("dmwr_mask_out",ms_riscv32_mp_dmwr_mask_out,4,UVM_DEC);
		printer.print_field("dmwr_req_out",ms_riscv32_mp_dmwr_req_out,1,UVM_DEC);
		printer.print_field("data_htrans_out",ms_riscv32_mp_data_htrans_out,2,UVM_DEC);

	endfunction

	
endclass