class env extends uvm_env;

	`uvm_component_utils(env)

	scoreboard sbh;
	ref_model refh;
	virtual_sequencer vseqrh;
	data_agent dagnth[];
	instr_agent iagnth[];
	rst_agent ragnth[];
	irq_agent intagnth[];
	env_config m_cfg;
	subscriber subh;

	function new(string name="env",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		sbh=scoreboard::type_id::create("sbh",this);
		refh=ref_model::type_id::create("refh",this);
		vseqrh=virtual_sequencer::type_id::create("vseqrh",this);
		subh=subscriber::type_id::create("subh",this);
		if(!uvm_config_db#(env_config)::get(this,"","m_cfg",m_cfg))
			`uvm_fatal("env","configuration getting error")

		if(m_cfg.has_data_agent)
			dagnth=new[m_cfg.no_of_data_agents];

		if(m_cfg.has_instr_agent)
			iagnth=new[m_cfg.no_of_instr_agents];
		
		if(m_cfg.has_rst_agent)
			ragnth=new[m_cfg.no_of_rst_agents];
		
		if(m_cfg.has_irq_agent)
			intagnth=new[m_cfg.no_of_irq_agents];

		if(m_cfg.has_data_agent)
		begin
		foreach(dagnth[i])
		begin
			dagnth[i]=data_agent::type_id::create($sformatf("dagnth[%0d]",i),this);
			uvm_config_db#(data_config)::set(this,$sformatf("dagnth[%0d]*",i),"data_config",m_cfg.d_cfg[i]);
			if(i==1)
				uvm_config_db#(data_config)::set(this,"refh","data_config",m_cfg.d_cfg[i]);

		end
		end

		if(m_cfg.has_instr_agent)
		begin
		foreach(iagnth[i])
		begin
			iagnth[i]=instr_agent::type_id::create($sformatf("iagnth[%0d]",i),this);
			uvm_config_db#(instr_config)::set(this,$sformatf("iagnth[%0d]*",i),"instr_config",m_cfg.i_cfg[i]);
			if(i==1)
				uvm_config_db#(instr_config)::set(this,"refh","instr_config",m_cfg.i_cfg[i]);

		end
		end

		if(m_cfg.has_rst_agent)
		begin
		foreach(ragnth[i])
		begin
			ragnth[i]=rst_agent::type_id::create($sformatf("ragnth[%0d]",i),this);
			uvm_config_db#(rst_config)::set(this,$sformatf("ragnth[%0d]*",i),"rst_config",m_cfg.r_cfg[i]);
			if(i==1)
				uvm_config_db#(rst_config)::set(this,"refh","rst_config",m_cfg.r_cfg[i]);

		end
		end

		if(m_cfg.has_irq_agent)	
		begin	
		foreach(intagnth[i])
		begin
			intagnth[i]=irq_agent::type_id::create($sformatf("intagnth[%0d]",i),this);
			uvm_config_db#(irq_config)::set(this,$sformatf("intagnth[%0d]*",i),"irq_config",m_cfg.int_cfg[i]);
			if(i==1)
				uvm_config_db#(irq_config)::set(this,"refh","irq_config",m_cfg.int_cfg[i]);

		end
		end

	endfunction		

	function void connect_phase(uvm_phase phase);
		if(m_cfg.has_data_agent)
			foreach(dagnth[i])
				vseqrh.dseqrh[i]=dagnth[i].seqrh;
		
		if(m_cfg.has_instr_agent)
			foreach(iagnth[i])
				vseqrh.iseqrh[i]=iagnth[i].seqrh;

		if(m_cfg.has_rst_agent)
			foreach(ragnth[i])
				vseqrh.rseqrh[i]=ragnth[i].seqrh;
		
		if(m_cfg.has_irq_agent)
			foreach(intagnth[i])
				vseqrh.intseqrh[i]=intagnth[i].seqrh;

		if(m_cfg.has_data_agent)
			foreach(dagnth[i])
				dagnth[i].monh.analysis_port.connect(sbh.data_fifo[i].analysis_export);

		if(m_cfg.has_instr_agent)
			foreach(iagnth[i])
			begin
				iagnth[i].monh.analysis_port.connect(sbh.instr_fifo[i].analysis_export);
				if(i==0)
					iagnth[i].monh.analysis_port.connect(subh.fifo_instr_duvh.analysis_export);
			end
		if(m_cfg.has_rst_agent)
			foreach(ragnth[i])
				ragnth[i].monh.analysis_port.connect(sbh.rst_fifo[i].analysis_export);

		if(m_cfg.has_irq_agent)
			foreach(intagnth[i])
				intagnth[i].monh.analysis_port.connect(sbh.irq_fifo[i].analysis_export);

		refh.analysis_port.connect(sbh.ref_fifo.analysis_export);
		refh.analysis_porti.connect(sbh.ref_fifoi.analysis_export);
		
	endfunction

endclass
