class env_config extends uvm_object;

	`uvm_object_utils(env_config)

	data_config d_cfg[];
	instr_config i_cfg[];
	rst_config r_cfg[];
	irq_config int_cfg[];

	int no_of_data_agents;
	int no_of_instr_agents;
	int no_of_rst_agents;
	int no_of_irq_agents;

	int has_data_agent;
	int has_instr_agent;
	int has_rst_agent;
	int has_irq_agent;
	bit nop=1;

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	rand uvm_reg_data_t data1,data2;
	randc bit [4:0] rs1,rs2,rd;
	rand bit [31:0] imm_temp_value,data_in;

	

	bit [31:0] passed_cmds[$];
	bit [31:0] failed_cmds[$];

	function new(string name="env_conig");
		super.new(name);
	endfunction
endclass
