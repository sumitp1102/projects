class internal_reg_model;

	int reg_file[31:0];
	bit [31:0] pc;

	function void display();
		foreach(reg_file[i])
			$write("the reg file is %0d\t",reg_file[i]);
		$display();
		$display("the pc value is %0d",pc);
	endfunction


endclass
