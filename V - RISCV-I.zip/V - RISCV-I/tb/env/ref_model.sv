class ref_model extends uvm_scoreboard;

	`uvm_component_utils(ref_model)

	internal_reg_model reg_mod,reg_modi;

	virtual msrv32_rst_if.RM_MP vif;	
	virtual msrv32_ahb_instr_if.RM_MP vifi;
	virtual msrv32_ahb_data_if.RM_MP vifd;
	
	rst_config rst_cfg;
	instr_config instr_cfg;
	data_config data_cfg;
	env_config rv_cfg;

	rst_trans rst_xtn;
	instr_trans instr_xtn;
	static int tt,ttt,tttt;
	instr_trans sb;
	data_trans data_xtn,sbd;

	reg_block_for_pc reg_block_pc_h;
	int pc_data;
	rand uvm_reg_data_t pc_d;
	uvm_status_e status;	

	uvm_analysis_port#(internal_reg_model) analysis_port;
	uvm_analysis_port#(internal_reg_model) analysis_porti;


	bit [6:0] opcode,funct7;
	bit [4:0] rd,rs1,rs2;
	bit [2:0] funct3;
	bit [31:0] imm,immb,immu,immj;
	bit [31:0] rd_data;
	bit [31:0] rs2_data,rs1_data,addrs;


	parameter f3_add 	= 3'b000;	//0
	parameter f3_slt	= 3'b010;	//2
	parameter f3_sltu 	= 3'b011;	//3
	parameter f3_or 	= 3'b110;	//6
	parameter f3_xor 	= 3'b100;	//4
	parameter f3_and	= 3'b111;	//7
	parameter f3_sll	= 3'b001;	//1
	parameter f3_srl	= 3'b101;	//5
	parameter f3_sra	= 3'b101;	//5
	
	parameter f3_lb		= 3'b000;
	parameter f3_lh		= 3'b001;
	parameter f3_lw		= 3'b010;
	parameter f3_lbu	= 3'b100;
	parameter f3_lhu	= 3'b101;

	parameter f3_sb		= 3'b000;
	parameter f3_sh		= 3'b001;
	parameter f3_sw		= 3'b010;


	parameter f3_beq	= 3'b000;
	parameter f3_bne	= 3'b001;
	parameter f3_blt	= 3'b100;
	parameter f3_bge	= 3'b101;
	parameter f3_bltu	= 3'b110;
	parameter f3_bgeu	= 3'b111;

	// register file
	bit [31:0] rf[31:1];
	bit [31:0] instr_q[$],temp;
	bit [31:0] data_q[$];


	function new(string name="ref_model",uvm_component parent);
		super.new(name,parent);
		analysis_port=new("analysis_port",this);
		analysis_porti=new("analysis_porti",this);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(rst_config)::get(this,"","rst_config",rst_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		if(!uvm_config_db#(instr_config)::get(this,"","instr_config",instr_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		if(!uvm_config_db#(data_config)::get(this,"","data_config",data_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		if(!uvm_config_db#(env_config)::get(this,"","m_cfg",rv_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")		

//		rst_xtn=rst_trans::type_id::create("rst_xtn");
//		instr_xtn=instr_trans::type_id::create("instr_xtn");
//		sb=instr_trans::type_id::create("sb");

		
		
	
		reg_mod=new();
		reg_modi=new();
	endfunction

	function void connect_phase(uvm_phase phase);
			vif=rst_cfg.vif;
			vifi=instr_cfg.vif;
			vifd=data_cfg.vif;
			reg_block_pc_h=rv_cfg.reg_block_pc_h;
	endfunction

	task run_phase(uvm_phase phase);
		forever
		begin
			@(vif.rm_cb);
			fork
				begin
					get_rst;
				end
				begin
					get_instr;
				end
				begin
					get_data;
				end
				begin
					if(rst_xtn.mp_rst_in==1'b1)
					begin
						//`uvm_info(get_type_name(),"reset in reference model",UVM_NONE)
						//$display("reset called");
						rst_ip;
					end
					else
					begin
						//`uvm_info(get_type_name(),$sformatf("this much time i have came hear %0d",tt++),UVM_LOW)
						execute_instr;
					end
				end
			join_any
			@(vif.rm_cb);
		end
	endtask

	task get_rst;	
		rst_xtn=rst_trans::type_id::create("rst_xtn");
		if(vif.rm_cb.mp_rst_in==1'b1)
		begin
			rst_xtn.mp_rst_in=vif.rm_cb.mp_rst_in;
			//`uvm_info(get_type_name,$sformatf("reference model %s",rst_xtn.sprint),UVM_LOW)
		end
	endtask

	function void rst_ip;
		for(int i=0;i<32;i++)
			reg_mod.reg_file[i]=32'd0;
		reg_mod.pc=32'd0;
		//reg_mod.display;
		analysis_port.write(reg_mod);
	endfunction

	task get_instr;
		if(vif.rm_cb.mp_rst_in==1'b0)
		begin
			instr_xtn=instr_trans::type_id::create("instr_xtn");
			//`uvm_info(get_type_name(),$sformatf("first in instruction get %0d",tttt++),UVM_LOW)
			wait((vifi.rm_cb.ms_riscv32_mp_instr_hready_in==1'b1));
			//`uvm_info(get_type_name(),$sformatf("this much time in instruction get %0d",ttt++),UVM_LOW)
			instr_xtn.instruction=vifi.rm_cb.ms_riscv32_mp_instr_in;
			//`uvm_info(get_type_name(),$sformatf("from ref mod is instr ready %0d",instr_xtn.ms_riscv32_mp_instr_hready_in),UVM_LOW)
			//`uvm_info(get_type_name(),$sformatf("from ref mod in get instr %s",instr_xtn.sprint),UVM_LOW)			
			update_rf;
			instr_q.push_front(instr_xtn.instruction);
		end
	endtask

	task get_data;
		if(vif.rm_cb.mp_rst_in==1'b0)
		begin
			data_xtn=data_trans::type_id::create("data_xtn");	
			wait(vifd.rm_cb.ms_riscv32_mp_data_hready_in==1'b1);
			data_xtn.ms_riscv32_mp_data_in=vifd.rm_cb.ms_riscv32_mp_data_in;
			data_xtn.ms_riscv32_mp_data_hready_in=vifd.rm_cb.ms_riscv32_mp_data_hready_in;
			data_xtn.ms_riscv32_mp_hresp_in=vifd.rm_cb.ms_riscv32_mp_hresp_in;
			//`uvm_info(get_type_name(),$sformatf("first in data get and the size is %0d and %s",data_q.size,data_xtn.sprint),UVM_LOW)
			update_rf;
			data_q.push_front(data_xtn.ms_riscv32_mp_data_in);
			//@(vifd.rm_cb);
		end
	endtask
			

	task update_rf;
	begin
		rf[rv_cfg.rs1]=rv_cfg.data1;
		rf[rv_cfg.rs2]=rv_cfg.data2;
		if(vifd.rm_cb.ms_riscv32_mp_data_hready_in)
			rf[(rv_cfg.rs1+rv_cfg.imm_temp_value)]=rv_cfg.data_in;
	//	$display("the rs1 adr %0d and data %0d and rs2 addr %0d and data %0d",rv_cfg.rs1,rf[rv_cfg.rs1],rv_cfg.rs2,rf[rv_cfg.rs2]);
	end
	endtask

	task execute_instr;
		fork
			begin
				wait(instr_q.size!==0);
				//	$display("running execute instr");
				//$display("the instr que size %0d",instr_q.size);
				sb=instr_trans::type_id::create("sb");
				begin
					sb.instruction=instr_q.pop_back();
					sb.opcode=sb.instruction[6:0];
					sb.funct3=sb.instruction[14:12];
					sb.funct7=sb.instruction[31:25];
					sb.rs1=sb.instruction[19:15];
					sb.rs2=sb.instruction[24:20];
					sb.rd=sb.instruction[11:7];
					immb[4:1]=sb.instruction[11:8];
					immb[10:5]=sb.instruction[30:25];
					immb[11]=sb.instruction[7];
					immb[12]=sb.instruction[31];
					sb.ms_riscv32_mp_imaddr_out=sb.instruction[31:20];
					$display("====================  ");
					/*if(sb.opcode==7'b0010011 && sb.rd!=5'b0) 
					begin
						//rs2_data=instr_xtn.ms_riscv32_mp_imaddr_out;
						rs2_data=rv_cfg.imm_temp_value;
						temp=alu(sb.rs1,rs2_data,sb.funct3,sb.funct7);
						rf[sb.rd]=temp;
						reg_modi.reg_file[sb.rd]=rf[sb.rd];				
						//`uvm_info(get_type_name(),$sformatf("data in reg file %s",reg_modi.display),UVM_LOW)
						$display("values from the ref model for instr %0d and %0d",rf[sb.rs1],rs2_data);
						$display("this much time i have been here %0d",tt++);	
						analysis_porti.write(reg_modi);					
						$display(" data in reg file for instr:%p",reg_modi);				

					end*/
					// Check Wheather R-TYPE or I-TYPE through OPCODE
					if(sb.opcode == 7'b001_0011 && sb.rd != 5'b0) //FOR I TYPE INSTRUCTION
					begin
						`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
						case(sb.funct3) 
							f3_sll :
							begin
								if(sb.funct7[5] == 0) 
								begin
									rs2_data = sb.ms_riscv32_mp_imaddr_out[4:0];
									//$display($sformatf("================================/n rs2_data = %0d /n==============================",rs2_data));
								end
							end
							f3_srl :
							begin
								if(sb.funct7[5] == 0)
									rs2_data = sb.ms_riscv32_mp_imaddr_out[4:0];
								if(sb.funct7[5] == 1) 
									rs2_data = sb.ms_riscv32_mp_imaddr_out[4:0];
							end
							default:rs2_data = sb.ms_riscv32_mp_imaddr_out;
						endcase				
						temp = alu(sb.rs1, rs2_data, sb.funct3, sb.funct7);
						rf[sb.rd] = temp;			
						rf[sb.rs1] = rs1_data;
						rf[sb.rs2] = rs2_data;
						reg_modi.reg_file[sb.rs1] = rf[sb.rs1];
						reg_modi.reg_file[sb.rs2] = rf[sb.rs2];
						reg_modi.reg_file[sb.rd] = rf[sb.rd];
						//`uvm_info(get_type_name(),$sformatf("  \n DATA IN REG_FILE : %p \n ", regh1),UVM_LOW)				
						analysis_porti.write(reg_modi);
					end		
					else if(sb.opcode == 7'b011_0011 && sb.rd != 5'b0) //FOR R TYPE INSTRUCTION	
					begin
						`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
						case(sb.funct3) 
								f3_sll :
							begin
								if(sb.funct7[5] == 0) 
								begin
									rs2_data = rf[sb.rs2][4:0];
								end
							end
							f3_srl :
							begin
								if(sb.funct7[5] == 0)
									rs2_data = rf[sb.rs2][4:0];
								if(sb.funct7[5] == 1) 
								begin
									rs2_data = rf[sb.rs2][4:0];
								end
							end
							default:rs2_data = rf[sb.rs2];
						endcase
 						//rs2_data = rf[sb.rs2]; //m_cfg.data2;
						// To get Result call ALU method
						temp = alu(sb.rs1, rs2_data, sb.funct3, sb.funct7);
						rf[sb.rd] = temp;	
						// To print the Reg_file Data
						rf[sb.rs1] = rs1_data;
						rf[sb.rs2] = rs2_data;
						reg_modi.reg_file[sb.rd] = rf[sb.rd];
						reg_modi.reg_file[sb.rs1] = rf[sb.rs1];
						reg_modi.reg_file[sb.rs2] = rf[sb.rs2];
						//`uvm_info(get_type_name(),$sformatf("  \n DATA IN REG_FILE : %p \n ", reg_modi),UVM_LOW)
						analysis_porti.write(reg_modi);
					end
					else if(sb.opcode == 7'b1100011 && sb.rs1!=0 && sb.rs2!=0)// FOR B TYPE INSTRUCTION
					begin
						sb.ms_riscv32_mp_imaddr_out=immb;
						`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
						reg_block_pc_h.pc_h.read(status,pc_d,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
						`uvm_info(get_type_name(),$sformatf("the pc value form dut %0d",pc_d),UVM_LOW)
						temp=branchh(sb.rs1,sb.rs2,sb.funct3,immb,pc_d);
						reg_modi.pc=temp;
						rf[sb.rs1] = rs1_data;
						rf[sb.rs2] = rs2_data;
						reg_modi.reg_file[sb.rs1] = rf[sb.rs1];
						reg_modi.reg_file[sb.rs2] = rf[sb.rs2];
						analysis_porti.write(reg_modi);
					end
					else if((sb.opcode == 7'b0110111 || sb.opcode == 7'b0010111) && sb.rd!=0)//FOR U TYPE INSTRUCTION
					begin
						sb.ms_riscv32_mp_imaddr_out[31:12]=sb.instruction[31:12];
						sb.rd=sb.instruction[11:7];
						`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
						immu={sb.instruction[31:12],12'b0};
						reg_block_pc_h.pc_h.read(status,pc_d,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
						`uvm_info(get_type_name(),$sformatf("the pc value form dut %0d",pc_d),UVM_LOW)
						if(sb.opcode == 7'b0110111)
							reg_modi.reg_file[sb.rd]=immu;
						else
							reg_modi.reg_file[sb.rd]=immu+(pc_d-4);	
						analysis_porti.write(reg_modi);
					end
					else if((sb.opcode == 7'b1101111 || sb.opcode == 7'b1100111) && sb.rd!=0)//FOR J TYPE INSTRUCTION	
					begin
						//@(vif.rm_cb);
						//pc_data=pc_data+4;
						if(sb.opcode==7'b1101111)
						begin
							sb.ms_riscv32_mp_imaddr_out[10:1]=sb.instruction[30:21];
							sb.ms_riscv32_mp_imaddr_out[11]=sb.instruction[20];
							sb.ms_riscv32_mp_imaddr_out[19:12]=sb.instruction[19:12];
							sb.ms_riscv32_mp_imaddr_out[20]=sb.instruction[31];
							immj={sb.ms_riscv32_mp_imaddr_out[20:1],1'b0};
							`uvm_info(get_type_name(),$sformatf("from ref mod as jump instr %s ",sb.sprint),UVM_LOW)
							//reg_block_pc_h.pc_h.read(status,pc_data,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
							`uvm_info(get_type_name(),$sformatf("the innj %0d and pc_data %0d",immj,reg_modi.pc),UVM_LOW)
							reg_modi.reg_file[sb.rd]=reg_modi.pc+4;
							reg_modi.pc=reg_modi.pc+immj+immj+reg_modi.pc;
							analysis_porti.write(reg_modi);
						end
						else
						begin
							`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s and imm %0d",sb.sprint,sb.ms_riscv32_mp_imaddr_out),UVM_LOW)
							//reg_block_pc_h.pc_h.read(status,pc_data,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
							reg_modi.reg_file[sb.rd]=reg_modi.pc+4;
							reg_modi.pc={sb.ms_riscv32_mp_imaddr_out[31:1],1'b0};
							analysis_porti.write(reg_modi);
						end
					end							
				end
			end
			begin
				//`uvm_info(get_type_name(),"waiting to get inside of data block",UVM_LOW)
				//wait(instr_q.size!==0);
				wait(data_q.size!==0);
				//`uvm_info(get_type_name(),"i am inside of data block",UVM_LOW)
				sbd=data_trans::type_id::create("sbd");
				sbd.ms_riscv32_mp_data_in=data_q.pop_back();
				`uvm_info(get_type_name(),$sformatf("from ref mod as data %s",sbd.sprint),UVM_LOW)
				if(sb.opcode==7'b0000011 && sb.rd!=0)//FOR L TYPE INSTRUCTION
				begin
					`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
					//`uvm_info(get_type_name(),"inside the load block",UVM_LOW)
					//sbd.ms_riscv32_mp_data_in=data_q.pop_back();
					rd=rv_cfg.rd;
					addrs=rv_cfg.imm_temp_value+rv_cfg.data1;
					temp=load(sb.funct3,sbd.ms_riscv32_mp_data_in,addrs);
					reg_modi.reg_file[rd]=temp;
					//reg_modi.display;
					analysis_porti.write(reg_modi);
				end
				if(sb.opcode==7'b0100011 && sb.rd!=0)// FOR S TYPE INSTRUCTION
				begin
					`uvm_info(get_type_name(),$sformatf("from ref mod as instr %s",sb.sprint),UVM_LOW)
					//`uvm_info(get_type_name(),"inside the load block",UVM_LOW)
					//sbd.ms_riscv32_mp_data_in=data_q.pop_back();
					rs2=rv_cfg.rs2;
					addrs=rv_cfg.imm_temp_value+rv_cfg.data1;
					temp=storre(sb.funct3,addrs,rv_cfg.data2);
					reg_modi.reg_file[rs2]=temp;
					//reg_modi.display;
					//$display("the address on the ref model rjfnrjhfbrwhfbwqrhjfnjwqknf is %0d and %0d",rv_cfg.imm_temp_value,rv_cfg.data1);
					analysis_porti.write(reg_modi);
				end					
			end
		join
	endtask

	function bit [31:0] load(bit[2:0]funct3 , bit[31:0] mp_dmdata_in ,bit[31:0] temp_add );

		bit [31:0] resultl;
		bit [7:0]data_byte;
		bit [15:0] data_half;

		case(funct3)
		f3_lb:
		begin
			case(temp_add[1:0])
				2'b00: data_byte=mp_dmdata_in[7:0];
				2'b01: data_byte=mp_dmdata_in[15:8];
				2'b10: data_byte=mp_dmdata_in[23:16];
				2'b11: data_byte=mp_dmdata_in[31:24];
			endcase
			resultl= {{24{data_byte[7]}},data_byte};
		end
		f3_lh:	
		begin
			case(temp_add[1])
				1'b0: data_half = mp_dmdata_in[15:0];
				1'b1: data_half = mp_dmdata_in[31:16];
			endcase
			resultl = {{16{data_half[15]}},data_half};
		end
		f3_lw:
		begin
			resultl=mp_dmdata_in;
		end
		f3_lbu:
		begin
			case(temp_add[1:0])
				2'b00: data_byte=mp_dmdata_in[7:0];
				2'b01: data_byte=mp_dmdata_in[15:8];
				2'b10: data_byte=mp_dmdata_in[23:16];
				2'b11: data_byte=mp_dmdata_in[31:24];
			endcase
			resultl= {24'b0,data_byte};
		end
		f3_lhu:
		begin
			case(temp_add[1])
				1'b0: data_half = mp_dmdata_in[15:0];
				1'b1: data_half = mp_dmdata_in[31:16];
			endcase
			resultl = {16'b0,data_half};
		end
		endcase		

		load=resultl;
	endfunction

	function bit [31:0] storre(bit[2:0]funct3 , bit[31:0]temp_add , bit[31:0]op2);
		
		bit [31:0]results;
		bit [31:0]byte_dout;
		bit [31:0]halfword_dout;
		case(funct3)
		f3_sb:
		begin
			case(temp_add[1:0])
				2'b00: byte_dout={8'b0,8'b0,8'b0,op2[7:0]};
				2'b01: byte_dout={8'b0,8'b0,op2[15:8],8'b0};
				2'b10: byte_dout={8'b0,op2[23:16],8'b0,8'b0};
				2'b11: byte_dout={op2[31:24],8'b0,8'b0,8'b0};
				default:byte_dout = 32'b0;
			endcase
			results=byte_dout;
		end
		f3_sh:
		begin
			case(temp_add[1])
				1'b0:halfword_dout ={16'b0, op2[15:0]};
				1'b1:halfword_dout ={op2[31:16],16'b0};
				default:halfword_dout = 32'b0;
			endcase
			results=halfword_dout;
		end
		f3_sw:
		begin
			results=op2;
		end
		endcase	
		storre=results;
	endfunction

	function bit[31:0] branchh(bit[4:0] rs1, bit[4:0] rs2, bit[2:0] f3, bit[31:0] immb,bit[31:0] temp);
		
		bit [31:0] resultb=temp;
		reg signed[31:0]  rs1_data_s;
		reg signed[31:0]  rs2_data_s;

		rs1_data = rf[rs1];
		rs1_data_s = rf[rs1];
		rs2_data = rf[rs2];
		rs2_data_s = rf[rs2];

		begin
			case(f3)
				f3_beq:
				begin
					if(rs1_data==rs2_data)
						resultb=temp+immb;
					else
						resultb+=4;
				end
				f3_bne:
				begin
					if(rs1_data!=rs2_data)
						resultb=temp+immb;
					else
						resultb+=4;
				end
				f3_blt:
				begin
					if(rs1_data_s<rs2_data_s)
						resultb=temp+immb;
					else
						resultb+=4;
				end
				f3_bge:
				begin
					if(rs1_data_s>=rs2_data_s)
						resultb=temp+immb;
					else
						resultb+=4;
				end
				f3_bltu:
				begin
					if(rs1_data<rs2_data)
						resultb=temp+immb;
					else
						resultb+=4;
				end
				f3_bgeu:
				begin
					if(rs1_data>rs2_data)
						resultb=temp+immb;
					else
						resultb+=4;
				end
			endcase
		end
		branchh=resultb;
	
	endfunction		
		
		
	function int alu(bit[4:0] rs1, bit [31:0] rs2_data, bit [2:0] f3, bit [6:0] f7 );

		bit [31:0] ops1,ops2;
		bit [31:0] result;
		reg signed[31:0]  rs1_data_s;
	
		rs1_data = rf[rs1];
		rs1_data_s = rf[rs1];
		
		begin
			case(f3)
				f3_add :
					begin
						if(f7[5] == 1)
							result = rs1_data - rs2_data;
						else	
							result = rs1_data + rs2_data;
					end
				f3_and :
					begin
							result = rs1_data & rs2_data;
					end
				f3_or :
					begin	
							result = rs1_data | rs2_data;
					end
				f3_xor :
					begin	
							result = rs1_data ^ rs2_data;
					end
				f3_sll :
					begin
						if(f7[5] == 0)
							result = rs1_data << rs2_data[4:0];
						end
				f3_srl :
					begin
						if(f7[5] == 0)
							result = rs1_data >> rs2_data[4:0];
						else 
						begin
							//`uvm_info(get_type_name,$sformatf("====rs1_data = %0d ===== rs2_data = %0d",rs1_data,rs2_data),UVM_LOW);
							result = rs1_data_s >>>rs2_data[4:0];
						end
					end
				f3_sra :
					begin
						if(f7[5] == 1) 
						begin
							//`uvm_info(get_type_name,$sformatf("====rs1_data = %0d ===== rs2_data = %0d",rs1_data,rs2_data),UVM_LOW);
							result = rs1_data >>> rs2_data[4:0];
						end
					end
				f3_slt :
					begin
						result = (rs1_data < rs2_data)? 1:0;
					end
				f3_sltu :
					begin
						result = (rs1_data < rs2_data)? 1:0;
					end				
			endcase
			rd_data = result;
			return rd_data;
		end
	endfunction

		
			
endclass
