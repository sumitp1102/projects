class scoreboard extends uvm_scoreboard;

	`uvm_component_utils(scoreboard)
	uvm_tlm_analysis_fifo#(data_trans) data_fifo[];
	uvm_tlm_analysis_fifo#(instr_trans) instr_fifo[];
	uvm_tlm_analysis_fifo#(rst_trans) rst_fifo[];
	uvm_tlm_analysis_fifo#(irq_trans) irq_fifo[];
	
	uvm_tlm_analysis_fifo#(internal_reg_model) ref_fifo;
	uvm_tlm_analysis_fifo#(internal_reg_model) ref_fifoi;

	virtual msrv32_ahb_instr_if vif;
	virtual msrv32_ahb_data_if vif2;
	
	env_config m_cfg;
	internal_reg_model reg_mod,reg_modi;
	uvm_status_e status;
	rand uvm_reg_data_t rd_data,rd_addr,pc_d;

	rst_trans ref_rst_xtn,dut_rst_xtn;
	instr_trans ref_instr,dut_instr;
	data_trans dut_data,ref_data;

	int checck=1;
	bit[31:0]pc_reg;

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	static int tt,ttt;
	cmdd cmd;
	rand uvm_reg_data_t rs1_addr,rs2_addr,rs1_data,rs2_data;
	bit[31:0] imm,temp,pc_data;	

	function new(string name="scoreboard",uvm_component parent);
		super.new(name,parent);
		
	endfunction
	
	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(env_config)::get(this,"","m_cfg",m_cfg))
			`uvm_fatal("scoreboard","configuration getting failed")
		if(m_cfg.has_data_agent)
		data_fifo=new[m_cfg.no_of_data_agents];
		if(m_cfg.has_instr_agent)
		instr_fifo=new[m_cfg.no_of_instr_agents];
		if(m_cfg.has_rst_agent)
		rst_fifo=new[m_cfg.no_of_rst_agents];
		if(m_cfg.has_irq_agent)
		irq_fifo=new[m_cfg.no_of_irq_agents];

		if(m_cfg.has_data_agent)
		foreach(data_fifo[i])
			data_fifo[i]=new($sformatf("data_fifo[%0d]",i),this);
		if(m_cfg.has_instr_agent)
		foreach(instr_fifo[i])
			instr_fifo[i]=new($sformatf("instr_fifo[%0d]",i),this);
		if(m_cfg.has_rst_agent)
		foreach(rst_fifo[i])
			rst_fifo[i]=new($sformatf("rst_fifo[%0d]",i),this);
		if(m_cfg.has_irq_agent)
		foreach(irq_fifo[i])
			irq_fifo[i]=new($sformatf("irq_fifo[%0d]",i),this);

		ref_fifo=new("ref_fifo",this);
		ref_fifoi=new("ref_fifoi",this);
		
		if(!uvm_config_db#(virtual msrv32_ahb_instr_if)::get(this,"","instr_vif[1]",vif))
			`uvm_fatal("scoreboard","configuration getting failed")
	
		if(!uvm_config_db#(virtual msrv32_ahb_data_if)::get(this,"","data_vif[1]",vif2))
			`uvm_fatal("scoreboard","configuration getting failed")
	endfunction

	function void connect_phase(uvm_phase phase);
		reg_block_h=m_cfg.reg_block_h;
		reg_block_pc_h=m_cfg.reg_block_pc_h;

	endfunction

	task run_phase(uvm_phase phase);
		fork	
			forever
			begin
				fork
					rst_fifo[0].get(dut_rst_xtn);
					rst_fifo[1].get(ref_rst_xtn);
				join
				//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data %0d",tt++),UVM_LOW)
				if(dut_rst_xtn!=null && ref_rst_xtn!=null)
				begin
					reset_check(ref_rst_xtn,dut_rst_xtn);
				end
				//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data reset_data"),UVM_LOW)
			end
			forever
			begin
				fork
					instr_fifo[0].get(dut_instr);
					instr_fifo[1].get(ref_instr);
					begin
						wait(dut_instr!=null);
						if(dut_instr.opcode==7'b0000011 || dut_instr.opcode==7'b0100011)
						fork
							//@(vif.ms_riscv32_mp_clk_in);
							//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data %0d",tt++),UVM_LOW)
							data_fifo[0].get(dut_data);
							data_fifo[1].get(ref_data);
						join
					end
					//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data %0d",tt++),UVM_LOW)
				join
				if(dut_instr!=null && ref_instr!=null && dut_data==null && ref_data==null)
				begin
					//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data instr_data %s \n %s",dut_instr.sprint,ref_instr.sprint),UVM_LOW)
					if((dut_instr.opcode==7'b0010011 || dut_instr.opcode==7'b0110011 || dut_instr.opcode==7'b1100011 || dut_instr.opcode==7'b0110111 || dut_instr.opcode==7'b0010111 || dut_instr.opcode==7'b1101111 || dut_instr.opcode==7'b1100111) && dut_instr.rd!=0)
					begin
						//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data when it is not null"),UVM_LOW)
						instr_check(dut_instr,ref_instr);
					end
					//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data instr_data %s",dut_instr.sprint),UVM_LOW)
				end
				if(dut_instr!=null && ref_instr!=null && dut_data!=null && ref_data!=null)	
				begin	
					//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data packet %s",dut_instr.sprint),UVM_LOW)
					if((dut_instr.opcode==7'b0000011) && dut_instr.rd!=0)
					begin
						//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data but the packet is empty"),UVM_LOW)
						data_check;
					end
					if((dut_instr.opcode==7'b0100011) && dut_instr.rd!=0)
					begin
						//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data but the packet is empty"),UVM_LOW)
						data_out_check;
					end
				end
					//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data but the packet is empty"),UVM_LOW)
			end	
			/*forever
			begin	
				fork
					data_fifo[0].get(dut_data);
					data_fifo[1].get(ref_data);
					//instr_fifo[0].get(dut_instr);
					//instr_fifo[1].get(ref_instr);
				join
				if(dut_instr!=null && ref_instr!=null && dut_data!=null && ref_data!=null)	
				begin	
					if((dut_instr.opcode==7'b0000011) && dut_instr.rd!=0)
						data_check;
					else if((dut_instr.opcode==7'b0100011) && dut_instr.rd!=0)
						data_out_check;
				end
			end*/	
		join_none
	

		/*fork
		begin
			fork
				rst_fifo[0].get(dut_rst_xtn);
				rst_fifo[1].get(ref_rst_xtn);
			join
			forever
			begin
				fork
					instr_fifo[0].get(dut_instr);
					instr_fifo[1].get(ref_instr);
					`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get data %0d",tt++),UVM_LOW)
				join
				`uvm_info(get_type_name(),"got both the seq in scoreboard",UVM_LOW)
				if(ref_rst_xtn.mp_rst_in==1'b1 && dut_rst_xtn.mp_rst_in==1'b1)
				begin
					`uvm_info(get_type_name(),"inside reset block of scoreboard",UVM_LOW)
					if(ref_fifo.try_get(reg_mod))begin
					for(int i=0;i<32;i++)
					begin
						reg_block_h.reg_file.read(status,i,rd_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
						if(reg_mod.reg_file[i] != rd_data)
						begin
							checck=0;
							break;
						end
					end
					if(checck==0)
						`uvm_info(get_type_name(),"reset unsucessfull",UVM_LOW)
					else
						`uvm_info(get_type_name(),"reset sucessfull",UVM_LOW)
					end
				end
				`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get inside before ref mod "),UVM_LOW)
				ref_fifoi.get(reg_modi);//from the ref model
				`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get inside the if %0d",ttt++),UVM_LOW)
		 		if(ref_instr.instruction==dut_instr.instruction )
				begin	
					`uvm_info(get_type_name(),$sformatf("dut trans %s",dut_instr.sprint),UVM_LOW)
					`uvm_info(get_type_name(),$sformatf("ref trans %s",ref_instr.sprint),UVM_LOW)
					cmd=dut_instr.cmd;
					rs1_addr=dut_instr.rs1;
					rs2_addr=dut_instr.rs2;
					rd_addr=dut_instr.rd;
					if(dut_instr.instruction==32'b0 )
					begin
						@(vif.ms_riscv32_mp_clk_in);
						`uvm_info(get_type_name(),$sformatf("instruction is zero"),UVM_LOW)
					end
					else 
					begin
						//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to fetch data %0d",tt++),UVM_LOW)
						read_register(dut_instr);
					end
				end
				else
					`uvm_info(get_type_name(),"i am in scoreboard and instructions are diffrent",UVM_LOW)
			end
		end
		join_none*/
	endtask
	
	task reset_check(rst_trans ref_rst_xtn,rst_trans dut_rst_xtn);
				//`uvm_info(get_type_name(),"got both the seq in scoreboard",UVM_LOW)
				if(ref_rst_xtn.mp_rst_in==1'b1 && dut_rst_xtn.mp_rst_in==1'b1)
				begin
					//`uvm_info(get_type_name(),"inside reset block of scoreboard",UVM_LOW)
					ref_fifo.get(reg_mod);
					for(int i=0;i<32;i++)
					begin
						reg_block_h.reg_file.read(status,i,rd_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
						if(reg_mod.reg_file[i] != rd_data)
						begin
							checck=0;
							break;
						end
					end
					if(checck==0)
						`uvm_info(get_type_name(),"reset unsucessfull",UVM_LOW)
					else
						`uvm_info(get_type_name(),"reset sucessfull",UVM_LOW)
					
				end
	endtask

	task instr_check(instr_trans dut_instr,instr_trans ref_instr);
				//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get inside before ref mod "),UVM_LOW)
				ref_fifoi.get(reg_modi);//from the ref model
				//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to get inside the if %0d",ttt++),UVM_LOW)
		 		if(ref_instr.instruction==dut_instr.instruction)
				begin	
					`uvm_info(get_type_name(),$sformatf("dut instr trans %s",dut_instr.sprint),UVM_LOW)
					`uvm_info(get_type_name(),$sformatf("ref instr trans %s",ref_instr.sprint),UVM_LOW)
					cmd=dut_instr.cmd;
					rs1_addr=dut_instr.rs1;
					rs2_addr=dut_instr.rs2;
					rd_addr=dut_instr.rd;
					imm=dut_instr.ms_riscv32_mp_imaddr_out;
					if(dut_instr.instruction==32'b0)
					begin
						@(vif.ms_riscv32_mp_clk_in);
						//`uvm_info(get_type_name(),$sformatf("instruction is zero"),UVM_LOW)
					end
					else 
					begin
						//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to fetch data %0d",tt++),UVM_LOW)
						read_register(dut_instr);
					end
				end
				else
					`uvm_info(get_type_name(),"i am in scoreboard and instructions are diffrent",UVM_LOW)
	endtask	

	task data_out_check;
		ref_fifoi.get(reg_modi);
		if(ref_data.ms_riscv32_mp_data_in==dut_data.ms_riscv32_mp_data_in && ref_instr.instruction==dut_instr.instruction)
		begin
			`uvm_info(get_type_name(),$sformatf("dut data trans %s",dut_data.sprint),UVM_LOW)
			`uvm_info(get_type_name(),$sformatf("ref data trans %s",ref_data.sprint),UVM_LOW)
			cmd=dut_instr.cmd;
			rs1_addr=dut_instr.rs1;
			rs2_addr=dut_instr.rs2;
			imm=dut_instr.ms_riscv32_mp_imaddr_out;
			if(dut_instr.instruction==32'd0)
			begin
				@(vif.ms_riscv32_mp_clk_in)
				`uvm_info(get_type_name(),$sformatf("instruction is zero"),UVM_LOW)
			end
			else
				read_register(dut_instr);
		end
	endtask
					

	task data_check;
		ref_fifoi.get(reg_modi);
		if(ref_data.ms_riscv32_mp_data_in==dut_data.ms_riscv32_mp_data_in && ref_instr.instruction==dut_instr.instruction)
		begin
			//`uvm_info(get_type_name(),$sformatf("dut data trans %s",dut_data.sprint),UVM_LOW)
			//`uvm_info(get_type_name(),$sformatf("ref data trans %s",ref_data.sprint),UVM_LOW)
			cmd=dut_instr.cmd;
			rs1_addr=dut_instr.rs1;
			rs2_addr=dut_instr.rs2;
			rd_addr=dut_instr.rd;
			if(dut_instr.instruction==32'b0)
			begin
				@(vif.ms_riscv32_mp_clk_in);
				`uvm_info(get_type_name(),$sformatf("instruction is zero"),UVM_LOW)
			end
			else 
			begin
				//`uvm_info(get_type_name(),$sformatf("i am in scoreboard to fetch data %0d",tt++),UVM_LOW)
				read_register(dut_instr);
			end
		end
		else
			`uvm_info(get_type_name(),"i am in scoreboard and instructions are diffrent",UVM_LOW)	
	endtask		


	task read_register(instr_trans instr_xtn);
		//`uvm_info(get_type_name(),$sformatf("cmd instr %s",instr_xtn.sprint),UVM_LOW)
		if(instr_xtn.cmd inside{addi,xori,ori,andi,slli,srli,srai,slti,sltiu,add,sub,xor_op,or_op,and_op,sll,srl,sra,slt,sltu}) 
		begin
			//`uvm_info(get_type_name(),"i am in scoreboard first",UVM_LOW)
			//ref_fifoi.get(reg_modi);//from the ref model

			repeat(3) 
			@(vif.ms_riscv32_mp_clk_in);

			//`uvm_info(get_type_name(),"i am in scoreboard",UVM_LOW)
			reg_block_h.reg_file.read(status,rd_addr,rd_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
			reg_block_h.reg_file.read(status, rs1_addr, rs1_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			reg_block_h.reg_file.read(status, rs2_addr, rs2_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("dut rd_addr %0d ,rd_data %0d, data1 %0d data2 %0d",rd_addr,rd_data,rs1_data,rs2_data),UVM_LOW)			
			`uvm_info(get_type_name(), $sformatf("data from ref model rd_addr %0d and addr %0d", reg_modi.reg_file[rd_addr],rd_addr), UVM_LOW)
			if(rd_data==reg_modi.reg_file[rd_addr])  
			begin
 					`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
  				//	m_cfg.passed_cmds.push_back(cmd);

			end
			else  
			begin	
 				/*	for(int i=0;i<32;i++)
					begin
						reg_block_h.reg_file.read(status,i,ref_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
						$display("all the integer file memory addr %0d and data %0d",i,ref_data);
					end*/
					`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

			//	m_cfg.failed_cmds.push_back(cmd);
			end
		end
		else if(instr_xtn.cmd inside{lb,lh,lw,lbu,lhu})
		begin
			repeat(3) 
			@(vif.ms_riscv32_mp_clk_in);
			//#10000;
			
			reg_block_h.reg_file.read(status, rs1_addr, rs1_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			reg_block_h.reg_file.read(status, rs2_addr, rs2_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			
			reg_block_h.reg_file.read(status,rd_addr,rd_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("dut rd_addr %0d ,rd_data %0d",rd_addr,rd_data),UVM_LOW)	
			`uvm_info(get_type_name(),$sformatf("the rs1 addr %0d and rs2 addr %0d",rs1_addr,rs2_addr),UVM_LOW)		
			`uvm_info(get_type_name(), $sformatf("data from ref model rd_data %0d and addr %0d", reg_modi.reg_file[rd_addr],rd_addr), UVM_LOW)
			if(status == UVM_IS_OK) 
			begin
				`uvm_info(get_full_name(), $sformatf("Read successful! Register value"), UVM_LOW)
				if(rd_data==reg_modi.reg_file[rd_addr])  
				begin
 					`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
  				//	m_cfg.passed_cmds.push_back(cmd);

				end
				else  
				begin	
 				/*	for(int i=0;i<32;i++)
					begin
						reg_block_h.reg_file.read(status,i,ref_data,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
						$display("all the integer file memory addr %0d and data %0d",i,ref_data);
					end*/
					`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

				//	m_cfg.failed_cmds.push_back(cmd);
				end
			end
			else if(status == UVM_NOT_OK)
				`uvm_info(get_full_name(),"the RAL is not working properly",UVM_LOW)	
		end
			
		else if(instr_xtn.cmd inside{sb,sh,sw})
		begin
			repeat(3) 
			@(vif.ms_riscv32_mp_clk_in);

			`uvm_info(get_type_name(),$sformatf("the data from scoreboard to compare rm: %0d and dut: %0d",reg_modi.reg_file[rs2_addr],dut_data.ms_riscv32_mp_dmdata_out),UVM_LOW)
			reg_block_h.reg_file.read(status, rs1_addr, rs1_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			reg_block_h.reg_file.read(status, rs2_addr, rs2_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("the data1 %0d at addr %0d data2 %0d at addr %0d",rs1_data,rs1_addr,rs2_data,rs2_addr),UVM_LOW)
			imm=imm+rs1_data;
			temp={imm[31:2],2'b00};
			if(reg_modi.reg_file[rs2_addr]==dut_data.ms_riscv32_mp_dmdata_out && temp==dut_data.ms_riscv32_mp_dmaddr_out)	
				`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
			else
			begin	
				`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

			//	m_cfg.failed_cmds.push_back(cmd);
			end
		end	
		else if(instr_xtn.cmd inside{beq,bne,blt,bge,bltu,bgeu})
		begin
			repeat(3) 
			@(vif.ms_riscv32_mp_clk_in);
			#2;

			reg_block_h.reg_file.read(status, rs1_addr, rs1_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			reg_block_h.reg_file.read(status, rs2_addr, rs2_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("the rs1 data %0d and rs2 data %0d",rs1_data,rs2_data),UVM_LOW)
			reg_block_pc_h.pc_h.read(status,pc_d, .path(UVM_BACKDOOR), .map(reg_block_pc_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("the ref_model data %0d and dut data %0d",reg_modi.pc,pc_d),UVM_LOW)
			if (status == UVM_IS_OK) 
			begin
    				`uvm_info(get_full_name(), $sformatf("Read successful! Register value"), UVM_LOW)
				if(reg_modi.pc==pc_d)
					`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
				else
				begin
					`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

					//	m_cfg.failed_cmds.push_back(cmd);
				end
			end
			else if(status == UVM_NOT_OK)
				`uvm_info(get_full_name(),"the RAL is not working properly",UVM_LOW)
		
			
		end
		else if(instr_xtn.cmd inside{lui,auipc})
		begin	
			repeat(3) 
			@(vif.ms_riscv32_mp_clk_in);
	
			reg_block_h.reg_file.read(status, rd_addr, rd_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("the dut rd data %0d and rd addr %0d",rd_data,rd_addr),UVM_LOW)
			`uvm_info(get_type_name(),$sformatf("the ref_mod data %0d and addr %0d",reg_modi.reg_file[rd_addr],rd_addr),UVM_LOW)
			if(reg_modi.reg_file[rd_addr]==rd_data)
				`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
			else
			begin
				`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

			//	m_cfg.failed_cmds.push_back(cmd);
			end
		end
		else if(instr_xtn.cmd inside{jal,jalr})
		begin
			repeat(3)
			@(vif.ms_riscv32_mp_clk_in);

			reg_block_pc_h.pc_h.read(status,pc_d, .path(UVM_BACKDOOR), .map(reg_block_pc_h.reg_map));
			reg_block_h.reg_file.read(status, rd_addr, rd_data, .path(UVM_BACKDOOR), .map(reg_block_h.reg_map));
			`uvm_info(get_type_name(),$sformatf("the dut rd data %0d and rd addr %0d",rd_data,rd_addr),UVM_LOW)
			`uvm_info(get_type_name(),$sformatf("the ref_mod data %0d and addr %0d",reg_modi.reg_file[rd_addr],rd_addr),UVM_LOW)
			`uvm_info(get_type_name(),$sformatf("the ref_model data %0d and dut data %0d",reg_modi.pc,pc_d),UVM_LOW)
			if((reg_modi.reg_file[rd_addr]==rd_data) && (reg_modi.pc==pc_d))
				`uvm_info(get_type_name(), $sformatf(" %s operation is successful in sb", cmd), UVM_LOW)
			else
			begin
				`uvm_info(get_type_name(), $sformatf(" %s operation is failed in sb", cmd), UVM_LOW)
					$display("---------------------------------------------------------");
					$display("8888888888        d88888     888888888     688");
					$display("888              68888888       089        888"); 
					$display("d8B            88888888888      888        888");
					$display("888      	8888     8888     888        888");
					$display("88888888     6880 	 8888 	  881        888");
					$display("888         d8ap       6888     888        888");
					$display("888        desen88888888888     888        888");
					$display("888       dasp         8888     888        868");
					$display("888      8888          8888  888888888     8888888888");
					$display("---------------------------------------------------------");

			//	m_cfg.failed_cmds.push_back(cmd);
			end
		end
							
	endtask


endclass
