 class subscriber extends uvm_component;
	`uvm_component_utils(subscriber)

	uvm_tlm_analysis_fifo #(instr_trans) fifo_instr_duvh;
	instr_trans instr_xtnh;
	logic [4:0] rd,rs1,rs2;
	logic  [31:0] ms_riscv32_mp_imaddr_out;
	covergroup instr_coverage;
		option.per_instance=1;
		CP_ADD :coverpoint instr_xtnh.cmd{ bins bin_add ={add};}
		CP_SUB :coverpoint instr_xtnh.cmd{ bins bin_sub ={sub};}
		CP_XOR :coverpoint instr_xtnh.cmd{ bins bin_xor ={xor_op};}
		CP_OR :coverpoint instr_xtnh.cmd{ bins bin_or ={or_op};}
		CP_AND :coverpoint instr_xtnh.cmd{ bins bin_and ={and_op};}
		CP_SRL :coverpoint instr_xtnh.cmd{ bins bin_srl ={srl};}
		CP_SLL :coverpoint instr_xtnh.cmd{ bins bin_sll ={sll};}
		CP_SRA :coverpoint instr_xtnh.cmd{ bins bin_sra ={sra};}
		CP_SLT :coverpoint instr_xtnh.cmd{ bins bin_slt ={slt};}
		CP_SLTU :coverpoint instr_xtnh.cmd{ bins bin_sltu ={sltu};}
		CP_ADDI :coverpoint instr_xtnh.cmd{ bins bin_addi ={addi};}
		CP_XORI :coverpoint instr_xtnh.cmd{ bins bin_xori ={xori};}
		CP_ORI :coverpoint instr_xtnh.cmd{ bins bin_ori ={ori};}
		CP_ANDI :coverpoint instr_xtnh.cmd{ bins bin_andi ={andi};}
		CP_SLLI :coverpoint instr_xtnh.cmd{ bins bin_slli ={slli};}
		CP_SRLI :coverpoint instr_xtnh.cmd{ bins bin_srli ={srli};}
		CP_SRAI :coverpoint instr_xtnh.cmd{ bins bin_srai ={srai};}
		CP_SLTI :coverpoint instr_xtnh.cmd{ bins bin_slti ={slti};}
		CP_SLTIU :coverpoint instr_xtnh.cmd{ bins bin_sltiu ={sltiu};}
		CP_LB :coverpoint instr_xtnh.cmd{ bins bin_lb ={lb};}
		CP_LH :coverpoint instr_xtnh.cmd{ bins bin_lh ={lh};}
		CP_LW :coverpoint instr_xtnh.cmd{ bins bin_lw ={lw};}
		CP_LBU :coverpoint instr_xtnh.cmd{ bins bin_lbu ={lbu};}
		CP_LHU :coverpoint instr_xtnh.cmd{ bins bin_lhu ={lhu};}
		CP_SB :coverpoint instr_xtnh.cmd{ bins bin_sb ={sb};}
		CP_SH :coverpoint instr_xtnh.cmd{ bins bin_sh ={sh};}
		CP_SW :coverpoint instr_xtnh.cmd{ bins bin_sw ={sw};}
		CP_BEQ :coverpoint instr_xtnh.cmd{ bins bin_beq ={beq};}
		CP_BNE :coverpoint instr_xtnh.cmd{ bins bin_bne ={bne};}
		CP_BLT :coverpoint instr_xtnh.cmd{ bins bin_blt ={blt};}
		CP_BGE :coverpoint instr_xtnh.cmd{ bins bin_bge ={bge};}
		CP_BLTU :coverpoint instr_xtnh.cmd{ bins bin_bltu ={bltu};}
		CP_BGEU :coverpoint instr_xtnh.cmd{ bins bin_bgeu ={bgeu};}
		CP_JAL :coverpoint instr_xtnh.cmd{ bins bin_jal ={jal};}
		CP_JALR :coverpoint instr_xtnh.cmd{ bins bin_salr ={jalr};}
		CP_LUI:coverpoint instr_xtnh.cmd{ bins bin_lui ={lui};}
		CP_AUIPC :coverpoint instr_xtnh.cmd{ bins bin_auipc ={auipc};}

		CP_RS1:coverpoint instr_xtnh.rs1{bins bin_rs1_min={1};
						 bins bin_rs1_min1={[2:15]};
						 bins bin_rs1_min2={[16:30]};
						 bins bin_rs1_max={31};}
		CP_RS2:coverpoint instr_xtnh.rs2{bins bin_rs2_min={1};
						 bins bin_rs2_min1={[2:15]};
						 bins bin_rs2_min2={[16:30]};
						 bins bin_rs2_max={31};}
		CP_RD:coverpoint instr_xtnh.rd{bins bin_rd_min={1};
						 bins bin_rd_min1={[2:15]};
						 bins bin_rd_min2={[16:30]};
						 bins bin_rd_max={31};}

		CP_IMM:coverpoint instr_xtnh.ms_riscv32_mp_imaddr_out
						{bins bin1={[32'h00000000:32'h3FFFFFFF]};
						 bins bin2={[32'h4FFFFFFF:32'h6FFFFFFF]};

						 bins bin3={[32'h8FFFFFFF:32'hBFFFFFFF]};

						 bins bin4={[32'hCFFFFFFF:32'hFFFFFFFF]};}

		CROSS_ADD:cross CP_ADD,CP_RS1,CP_RS2,CP_RD;
		CROSS_SUB:cross CP_SUB,CP_RS1,CP_RS2,CP_RD;
		CROSS_XOR:cross CP_XOR,CP_RS1,CP_RS2,CP_RD;
		CROSS_OR:cross CP_OR,CP_RS1,CP_RS2,CP_RD;
		CROSS_AND:cross CP_AND,CP_RS1,CP_RS2,CP_RD;
		CROSS_SLL:cross CP_SLL,CP_RS1,CP_RS2,CP_RD;
		CROSS_SRL:cross CP_SRL,CP_RS1,CP_RS2,CP_RD;
		CROSS_SRA:cross CP_SRA,CP_RS1,CP_RS2,CP_RD;
		CROSS_SLT:cross CP_SLT,CP_RS1,CP_RS2,CP_RD;
		CROSS_SLTU:cross CP_SLTU,CP_RS1,CP_RS2,CP_RD;
	
    CROSS_ADDI  : cross CP_ADDI,  CP_RS1, CP_RD;
    CROSS_XORI  : cross CP_XORI,  CP_RS1, CP_RD;
    CROSS_ORI   : cross CP_ORI,   CP_RS1, CP_RD;
    CROSS_ANDI  : cross CP_ANDI,  CP_RS1, CP_RD;
    CROSS_SLLI  : cross CP_SLLI,  CP_RS1, CP_RD;
    CROSS_SRLI  : cross CP_SRLI,  CP_RS1, CP_RD;
    CROSS_SRAI  : cross CP_SRAI,  CP_RS1, CP_RD;
    CROSS_SLTI  : cross CP_SLTI,  CP_RS1, CP_RD;
    CROSS_SLTIU : cross CP_SLTIU, CP_RS1, CP_RD;

    CROSS_LW    : cross CP_LW,    CP_RS1, CP_RD;
    CROSS_SW    : cross CP_SW,    CP_RS1, CP_RS2;
    CROSS_LB    : cross CP_LB,    CP_RS1, CP_RD;
    CROSS_LH    : cross CP_LH,    CP_RS1, CP_RD;
    CROSS_LBU   : cross CP_LBU,   CP_RS1, CP_RD;
    CROSS_LHU   : cross CP_LHU,   CP_RS1, CP_RD;
    CROSS_SB    : cross CP_SB,    CP_RS1, CP_RS2;
    CROSS_SH    : cross CP_SH,    CP_RS1, CP_RS2;

    CROSS_BEQ   : cross CP_BEQ,   CP_RS1, CP_RS2;
    CROSS_BNE   : cross CP_BNE,   CP_RS1, CP_RS2;
    CROSS_BLT   : cross CP_BLT,   CP_RS1, CP_RS2;
    CROSS_BGE   : cross CP_BGE,   CP_RS1, CP_RS2;
    CROSS_BLTU  : cross CP_BLTU,  CP_RS1, CP_RS2;
    CROSS_BGEU  : cross CP_BGEU,  CP_RS1, CP_RS2;

    CROSS_JALR  : cross CP_JALR,  CP_RS1, CP_RD;
    CROSS_JAL   : cross CP_JAL,   CP_RD;

    CROSS_LUI   : cross CP_LUI,   CP_RD;
    CROSS_AUIPC : cross CP_AUIPC, CP_RD;
		
endgroup

	function  new(string name="subscriber",uvm_component parent);
		super.new(name,parent);
		fifo_instr_duvh=new("fifo_instr_duvh",this);
		instr_coverage=new();
	endfunction

task run_phase(uvm_phase phase);
	forever begin
		 fifo_instr_duvh.get(instr_xtnh);
		if(instr_xtnh.cmd!=nop) 
			begin
			    `uvm_info(get_type_name(),$sformatf("In subcriber :%s",instr_xtnh.cmd),UVM_LOW)
			instr_coverage.sample();
		end
	end
endtask

function void report_phase(uvm_phase phase);
	`uvm_info(get_type_name(),$sformatf("the coverage is %0d",instr_coverage.get_coverage),UVM_LOW)

endfunction

endclass

							
		


		
							
