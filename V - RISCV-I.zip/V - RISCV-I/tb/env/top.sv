/*********************************

//File Name: msrv32_tb_top.sv

//Description: This file contains the design (processor core) instantiation and interface.

//Version: 1.0

//Engineer:

//Email: tech_support@maven-silicon.com

//************************************/

`timescale 1ns/1ps

module top;
  //import uvm pkg and test pkg
   import uvm_pkg::*;
   import pkg::*;
`include "uvm_macros.svh"

   bit clk;

   initial
   clk=0;
   always #5 clk=~clk;  
 
   msrv32_ahb_instr_if instr_if(clk);
   msrv32_ahb_instr_if rm_instr_if(clk);
   msrv32_ahb_data_if  data_if(clk);
  msrv32_ahb_data_if  rm_data_if(clk);
   msrv32_rst_if       rst_if(clk);
  msrv32_rst_if       rm_rst_if(clk);
   msrv32_irq_if       irq_if(clk);
  msrv32_irq_if       rm_irq_if(clk);


   msrv32_top_wrapper DUV(instr_if,data_if,rst_if,irq_if);


   initial
   begin
      uvm_config_db #(virtual msrv32_ahb_instr_if) :: set(null,"*","instr_vif[0]",instr_if);
     uvm_config_db #(virtual msrv32_ahb_instr_if) :: set(null,"*","instr_vif[1]",rm_instr_if);
      uvm_config_db #(virtual msrv32_ahb_data_if) :: set(null,"*","data_vif[0]",data_if);
      uvm_config_db #(virtual msrv32_ahb_data_if) :: set(null,"*","data_vif[1]",rm_data_if);
      uvm_config_db #(virtual msrv32_rst_if) :: set(null,"*","rst_vif[0]",rst_if);
     uvm_config_db #(virtual msrv32_rst_if) :: set(null,"*","rst_vif[1]",rm_rst_if);
      uvm_config_db #(virtual msrv32_irq_if) :: set(null,"*","irq_vif[0]",irq_if);
     uvm_config_db #(virtual msrv32_irq_if) :: set(null,"*","irq_vif[1]",rm_irq_if);
      $display("\nrun_test is getting executred now\n");
      run_test("r_type_test");
   end
endmodule

