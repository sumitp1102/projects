class virtual_sequence extends uvm_sequence #(uvm_sequence_item);

	`uvm_object_utils(virtual_sequence)

	data_sequencer dseqrh[];
	instr_sequencer iseqrh[];
	rst_sequencer rseqrh[];
	irq_sequencer intseqrh[];
	env_config m_cfg;
	virtual_sequencer vseqrh;

	rand uvm_reg_data_t data1,data2;
	randc bit [4:0] rs1,rs2,rd;
	rand bit [31:0] imm_temp_value;
	int instr_addr_temp=0;
	rand bit [31:0]data_in;
	
	constraint addr_c{ rs1 inside {[1:31]};
					   rs2 inside {[1:31]};
					   rd inside {[1:31]};
					   rs1 !=rs2;
					   rd !=rs1;
					   rd !=rs2;}

	function new(string name="virtual_sequencer");
		super.new(name);
	endfunction

	task body;
		assert($cast(vseqrh, m_sequencer))
                else
                        `uvm_error("Body", "Error in casting virtual sequencer")

		if(!uvm_config_db#(env_config)::get(null,"uvm_test_top.envh","m_cfg",m_cfg))
			`uvm_fatal("virtual_sequence","configuration is not getting")

		dseqrh=new[m_cfg.no_of_data_agents];
		iseqrh=new[m_cfg.no_of_instr_agents];
		rseqrh=new[m_cfg.no_of_rst_agents];
		intseqrh=new[m_cfg.no_of_irq_agents];


		foreach(dseqrh[i])
			dseqrh[i]=vseqrh.dseqrh[i];
		foreach(iseqrh[i])
			iseqrh[i]=vseqrh.iseqrh[i];
		foreach(rseqrh[i])
			rseqrh[i]=vseqrh.rseqrh[i];
		foreach(intseqrh[i])
			intseqrh[i]=vseqrh.intseqrh[i];

	endtask

endclass

class reset_seq_v extends virtual_sequence;

	`uvm_object_utils(reset_seq_v)

	reset_dut seqh[2];

	function new(string name="reset_req_v");
		super.new(name);
	endfunction

	task body;
		super.body;
		if(m_cfg.has_rst_agent)
		begin
			foreach(rseqrh[i])
			begin
				seqh[i]=reset_dut::type_id::create($sformatf("seqh[%0d]",i));
			end
			
			if(rseqrh[0] ==null || rseqrh[1] ==null) 
			begin
				`uvm_fatal("reset_vSeq"," Sequencer handles are not properly assigned")
			end

		//foreach(rseqrh[i])
			fork
				seqh[0].start(rseqrh[0]);
				seqh[1].start(rseqrh[1]);
			join
		//`uvm_info(get_type_name(),"I am in virtual sequence",UVM_LOW)
		end
	endtask

endclass


class instr_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_seq_v)

	instr_sequence seqh[2];

	function new(string name="instr_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=instr_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end
	
		if(!this.randomize() with {data1 inside {[1:100]}; imm_temp_value inside {[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		m_cfg.data2=data2;
		m_cfg.rs1=rs1;
		m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref
		join
		end
	endtask
endclass


class instr_r_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_r_seq_v)

	r_type_sequence seqh[2];

	function new(string name="instr_r_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=r_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end
	
		if(!this.randomize() with {data1 inside {[1:100]}; data2 inside {[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		m_cfg.data2=data2;
		m_cfg.rs1=rs1;
		m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref
		join
		end
	endtask
endclass


class instr_l_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_l_seq_v)

	l_type_sequence seqh[2];
	data_sequence dseqh[2];

	function new(string name="instr_l_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent && m_cfg.has_data_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=l_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end
			foreach(dseqrh[i])
			begin
				dseqh[i]=data_sequence::type_id::create($sformatf("dseqh[%0d]",i));
			end
	
		if(!this.randomize() with {data1 inside {[1:100]}; data2 inside {[1:100]}; data_in inside {[1:10000000]}; imm_temp_value inside {[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		m_cfg.data2=data2;
		m_cfg.data_in=data_in;
		m_cfg.rs1=rs1;
		m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
		
		if(dseqrh[0] ==null || dseqrh[1] ==null) 
		begin
			`uvm_fatal("data_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref
			dseqh[0].start(dseqrh[0]);//dut
			dseqh[1].start(dseqrh[1]);//ref
		join
		end
	endtask
endclass


class instr_s_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_s_seq_v)

	s_type_sequence seqh[2];
	data_s_sequence sseqh[2];

	function new(string name="instr_s_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent && m_cfg.has_data_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=s_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end
			foreach(dseqrh[i])
			begin
				sseqh[i]=data_s_sequence::type_id::create($sformatf("sseqh[%0d]",i));
			end
	
		if(!this.randomize() with {data1 inside {[1:100]}; data2 inside {[1:100]}; data_in inside {[1:10000000]}; imm_temp_value inside {[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		m_cfg.data2=data2;
		m_cfg.data_in=data_in;
		m_cfg.rs1=rs1;
		m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
		
		if(dseqrh[0] ==null || dseqrh[1] ==null) 
		begin
			`uvm_fatal("data_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref
			sseqh[0].start(dseqrh[0]);//dut
			sseqh[1].start(dseqrh[1]);//ref
		join
		end
	endtask
endclass


class instr_b_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_b_seq_v)

	b_type_sequence seqh[2];

	function new(string name="instr_b_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent ) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=b_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end

	
		if(!this.randomize() with {data1 inside {[1:100]}; data2 inside {[1:100]}; imm_temp_value inside {[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		m_cfg.data2=data2;
		m_cfg.rs1=rs1;
		m_cfg.rs2=rs2;
		//m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref

		join
		end
	endtask
endclass


class instr_u_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_u_seq_v)

	u_type_sequence seqh[2];

	function new(string name="instr_u_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=u_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end

	
		if(!this.randomize() with {imm_temp_value inside {[1000:100000]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		//m_cfg.data1=data1;
		//m_cfg.data2=data2;
		//m_cfg.rs1=rs1;
		//m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref

		join
		end
	endtask
endclass


class instr_j_seq_v extends virtual_sequence;

	`uvm_object_utils(instr_j_seq_v)

	j_type_sequence seqh[2];

	function new(string name="instr_j_seq_v");
		super.new(name);
	endfunction

	task body();
		super.body();

		if(m_cfg.has_instr_agent) 
		begin	
			foreach(iseqrh[i])
			begin
				seqh[i]=j_type_sequence::type_id::create($sformatf("seqh[%0d]",i));
			end

	
		if(!this.randomize() with {imm_temp_value inside {[1:100]}; data1 inside{[1:100]};})
			`uvm_fatal(get_full_name(),"randomization is not happening")
		
		m_cfg.data1=data1;
		//m_cfg.data2=data2;
		m_cfg.rs1=rs1;
		//m_cfg.rs2=rs2;
		m_cfg.rd=rd;
		m_cfg.imm_temp_value=imm_temp_value;
	
		if(iseqrh[0] ==null || iseqrh[1] ==null) 
		begin
			`uvm_fatal("Instr_vSeq"," Sequencer handles are not properly assigned")
		end
	
		fork 
			seqh[0].start(iseqrh[0]);//dut
			seqh[1].start(iseqrh[1]);//ref

		join
		end
	endtask
endclass
