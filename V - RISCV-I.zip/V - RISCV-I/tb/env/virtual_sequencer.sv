class virtual_sequencer extends uvm_sequencer#(uvm_sequence_item);

	`uvm_component_utils(virtual_sequencer)

	data_sequencer dseqrh[];
	instr_sequencer iseqrh[];
	rst_sequencer rseqrh[];
	irq_sequencer intseqrh[];
	env_config m_cfg;

	function new(string name="virtual_sequencer",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		
		if(!uvm_config_db#(env_config)::get(this,"","m_cfg",m_cfg))
			`uvm_fatal("virtual_sequencer","configuration is not getting")

		dseqrh=new[m_cfg.no_of_data_agents];
		iseqrh=new[m_cfg.no_of_instr_agents];
		rseqrh=new[m_cfg.no_of_rst_agents];
		intseqrh=new[m_cfg.no_of_irq_agents];
	endfunction


endclass
