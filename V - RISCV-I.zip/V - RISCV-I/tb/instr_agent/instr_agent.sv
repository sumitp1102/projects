class instr_agent extends uvm_agent;

	`uvm_component_utils(instr_agent)

	instr_driver drvh;
	instr_monitor monh;
	instr_sequencer seqrh;
	instr_config m_cfg;

	function new(string name="instr_agent",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(instr_config)::get(this,"","instr_config",m_cfg))
			`uvm_fatal("instr_agent","configuration getting failed")


		monh=instr_monitor::type_id::create("monh",this);

		if(m_cfg.is_active)
		begin
			drvh=instr_driver::type_id::create("drvh",this);
			seqrh=instr_sequencer::type_id::create("seqrh",this);
		end
	
	endfunction

	function void connect_phase(uvm_phase phase);
		if(m_cfg.is_active)
			drvh.seq_item_port.connect(seqrh.seq_item_export);
	endfunction



endclass
