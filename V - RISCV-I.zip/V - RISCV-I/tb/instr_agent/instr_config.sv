class instr_config extends uvm_object;

	`uvm_object_utils(instr_config)

	uvm_active_passive_enum is_active;

	virtual msrv32_ahb_instr_if vif; 

	function new(string name="instr_config");
		super.new(name);
	endfunction

endclass
