class instr_driver extends uvm_driver#(instr_trans);

	`uvm_component_utils(instr_driver)

	virtual msrv32_ahb_instr_if.DRV_MP vif;

	instr_config instr_cfg;
	env_config env_cfg;

	bit[7:0] mem[bit[31:0]];

	function new(string name="instr_driver",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(instr_config)::get(this,"","instr_config",instr_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		if(!uvm_config_db#(env_config)::get(this,"","m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=instr_cfg.vif;

	endfunction

	task run_phase(uvm_phase phase);
		forever
		begin
			seq_item_port.get_next_item(req);
			storage(req);
			send_to_dut(req);
			`uvm_info(get_type_name(),$sformatf("from driver %s",req.sprint),UVM_LOW)
			seq_item_port.item_done();
		end

	endtask

	task storage(instr_trans reqq);
		//$display("the instr addr %0d",reqq.instr_addr);
		mem[reqq.instr_addr+32'h0]=reqq.instruction[7:0];
		mem[reqq.instr_addr+32'h1]=reqq.instruction[15:8];	
		mem[reqq.instr_addr+32'h2]=reqq.instruction[23:16];
		mem[reqq.instr_addr+32'h3]=reqq.instruction[31:24];
		reqq.instr_addr=reqq.instr_addr+32'h4;
		//`uvm_info(get_full_name,$sformatf("memory in instruction drv : \n %p",mem),UVM_LOW)

	endtask

	task send_to_dut(instr_trans xtn);
		begin
			while(((vif.drv_cb.ms_riscv32_mp_imaddr_out==32'hz) || (vif.drv_cb.ms_riscv32_mp_imaddr_out==32'hx))) 
			begin
				@(vif.drv_cb);
				`uvm_info(get_full_name(),$sformatf("ms_riscv32_mp_imaddr_out:%0d",vif.drv_cb.ms_riscv32_mp_imaddr_out),UVM_LOW)
			end
		@(vif.drv_cb);
		vif.drv_cb.ms_riscv32_mp_instr_hready_in<=1'b1;


		vif.drv_cb.ms_riscv32_mp_instr_in[7:0]<=mem[xtn.instr_addr_next+32'h00000000];
		vif.drv_cb.ms_riscv32_mp_instr_in[15:8]<=mem[xtn.instr_addr_next+32'h0000001];
		vif.drv_cb.ms_riscv32_mp_instr_in[23:16]<=mem[xtn.instr_addr_next+32'h00000002];
		vif.drv_cb.ms_riscv32_mp_instr_in[31:24]<=mem[xtn.instr_addr_next+32'h00000003];
		xtn.instr_addr_next=xtn.instr_addr_next+32'h4;

/*
		vif.drv_cb.ms_riscv32_mp_instr_in[7:0]<=xtn.instruction[7:0];
		vif.drv_cb.ms_riscv32_mp_instr_in[15:8]<=xtn.instruction[15:8];
		vif.drv_cb.ms_riscv32_mp_instr_in[23:16]<=xtn.instruction[23:16];
		vif.drv_cb.ms_riscv32_mp_instr_in[31:24]<=xtn.instruction[31:24];
*/			
		//repeat(3)
		@(vif.drv_cb);
		vif.drv_cb.ms_riscv32_mp_instr_hready_in<=1'b0;

		//`uvm_info(get_full_name(),$sformatf("instrction drv :%0d",vif.drv_cb.ms_riscv32_mp_instr_in),UVM_LOW)

		end

	endtask



endclass