class instr_monitor extends uvm_monitor;

	`uvm_component_utils(instr_monitor)

	uvm_analysis_port#(instr_trans) analysis_port;

	virtual msrv32_ahb_instr_if.MON_MP vif;

	instr_config instr_cfg;

	//instr_trans data_sent;

	bit [31:0]instruction;
	int nop;

	function new(string name="instr_monitor",uvm_component parent);
		super.new(name,parent);
		analysis_port=new("analysis_port",this);
	endfunction


	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(instr_config)::get(this,"","instr_config",instr_cfg))
			`uvm_fatal(get_type_name(),"interface getting failed")

		//data_sent=instr_trans::type_id::create("data_sent");

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=instr_cfg.vif;
	endfunction

	task run_phase(uvm_phase phase);
		forever
		begin

			@(vif.mon_cb);
			instruction=vif.mon_cb.ms_riscv32_mp_instr_in;
			//$display("%0d",instruction);
			if((instruction==32'h00000013 ) || (instruction ==32'h00000000) || (instruction ==32'h00000033) || (instruction ==32'h00000003) || (instruction ==32'h00000023) ||(instruction ==32'h00000063) || (instruction ==32'h00000037) || (instruction ==32'h0000006F))
				nop=1;
			else 
				decode_instruction();
		
	
		//analysis_port.write(data_sent);
		//repeat(3)
		@(vif.mon_cb);
		end		
	endtask

	function void decode_instruction;
		instr_trans data_sent;
		data_sent=instr_trans::type_id::create("data_sent");
		data_sent.nop=nop;
		case(instruction[6:0])
			7'b0010011:begin 
				case(instruction[14:12])
					3'b000:begin	
							data_sent.cmd=addi;
						end
					3'b100:begin	
							data_sent.cmd=xori;
						end
					3'b110:begin	
							data_sent.cmd=ori;
						end
					3'b111:begin	
							data_sent.cmd=andi;
						end
					3'b001:begin	
							data_sent.cmd=slli;
						end
					3'b101:case(instruction [31:25])
							7'b0000000:data_sent.cmd=srli;
							7'b0100000:data_sent.cmd=srai;
						endcase
					3'b010:begin	
							data_sent.cmd=slti;
						end
					3'b011:begin	
							data_sent.cmd=sltiu;
						end
				endcase
				data_sent.rd=instruction[11:7];
				data_sent.rs1=instruction[19:15];
				data_sent.ms_riscv32_mp_imaddr_out[11:0]=instruction[31:20];
				data_sent.funct3=instruction[14:12];	
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b0110011:begin 
				case(instruction[14:12])
					3'b000:case(instruction[31:25])	
							7'b0000000:data_sent.cmd=add;
							7'b0100000:data_sent.cmd=sub;
						endcase
					3'b100:begin	
							data_sent.cmd=xor_op;
						end
					3'b110:begin	
							data_sent.cmd=or_op;
						end
					3'b111:begin	
							data_sent.cmd=and_op;
						end
					3'b001:begin	
							data_sent.cmd=sll;
						end
					3'b101:case(instruction[31:25])
							7'b0000000:data_sent.cmd=srl;
							7'b0100000:data_sent.cmd=sra;
						endcase
					3'b010:begin	
							data_sent.cmd=slt;
						end
					3'b011:begin	
							data_sent.cmd=sltu;
						end
				endcase			
				data_sent.rd=instruction[11:7];
				data_sent.rs1=instruction[19:15];
				data_sent.rs2=instruction[24:20];
				data_sent.funct7=instruction[31:25];
				data_sent.funct3=instruction[14:12];	
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b0100011:begin 
				case(instruction[14:12])
					3'b000:begin	
							data_sent.cmd=sb;
						end
					3'b001:begin	
							data_sent.cmd=sh;
						end
					3'b010:begin	
							data_sent.cmd=sw;
						end
				endcase
				data_sent.rd=instruction[11:7];
				data_sent.ms_riscv32_mp_imaddr_out[4:0]=instruction[11:7];
				data_sent.rs1=instruction[19:15];
				data_sent.rs2=instruction[24:20];
				data_sent.ms_riscv32_mp_imaddr_out[11:5]=instruction[31:25];
				data_sent.funct3=instruction[14:12];	
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b0000011:begin 
				case(instruction[14:12])
					3'b000:begin	
							data_sent.cmd=lb;
						end
					3'b100:begin	
							data_sent.cmd=lbu;
						end
					3'b001:begin	
							data_sent.cmd=lh;
						end
					3'b101:begin	
							data_sent.cmd=lhu;
						end
					3'b010:begin	
							data_sent.cmd=lw;
						end
				endcase
				data_sent.rd=instruction[11:7];
				data_sent.rs1=instruction[19:15];
				data_sent.ms_riscv32_mp_imaddr_out[11:0]=instruction[31:20];
				data_sent.funct3=instruction[14:12];	
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b1100011:begin 
				case(instruction[14:12])
					3'b000:begin	
							data_sent.cmd=beq;
						end
					3'b001:begin	
							data_sent.cmd=bne;
						end
					3'b100:begin	
							data_sent.cmd=blt;
						end
					3'b101:begin	
							data_sent.cmd=bge;
						end
					3'b110:begin	
							data_sent.cmd=bltu;
						end
					3'b111:begin	
							data_sent.cmd=bgeu;
						end
				endcase
				data_sent.rd=instruction[11:7];
				data_sent.ms_riscv32_mp_imaddr_out[4:1]=instruction[11:8];
				data_sent.rs1=instruction[19:15];
				data_sent.rs2=instruction[24:20];
				data_sent.ms_riscv32_mp_imaddr_out[10:5]=instruction[30:25];
				data_sent.ms_riscv32_mp_imaddr_out[11]=instruction[7];
				data_sent.ms_riscv32_mp_imaddr_out[12]=instruction[31];
				data_sent.funct3=instruction[14:12];	
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b0110111:begin 
				data_sent.cmd=lui;
				data_sent.rd=instruction[11:7];
				data_sent.ms_riscv32_mp_imaddr_out=instruction[31:12];
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b0010111:begin 
				data_sent.cmd=auipc;
				data_sent.rd=instruction[11:7];
				data_sent.ms_riscv32_mp_imaddr_out=instruction[31:12];
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b1101111:begin 
				data_sent.cmd=jal;
				data_sent.rd=instruction[11:7];
				data_sent.ms_riscv32_mp_imaddr_out[10:1]=instruction[30:21];
				data_sent.ms_riscv32_mp_imaddr_out[11]=instruction[20];
				data_sent.ms_riscv32_mp_imaddr_out[19:12]=instruction[19:12];
				data_sent.ms_riscv32_mp_imaddr_out[20]=instruction[31];
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
			7'b1100111:begin 
				case(instruction[14:12])
					3'b000:begin	
							data_sent.cmd=jalr;
						end
				endcase
				data_sent.rd=instruction[11:7];
				data_sent.rs1=instruction[19:15];
				data_sent.funct3=instruction[14:12];
				data_sent.ms_riscv32_mp_imaddr_out=instruction[31:20];
				//`uvm_info(get_full_name(),"I_type_instr",UVM_LOW)
				end
		endcase
	
	data_sent.opcode=instruction[6:0];
	data_sent.instruction=instruction[31:0];
	analysis_port.write(data_sent);
   	`uvm_info(get_full_name(),$sformatf("In  decode instr function data is \n %s",data_sent.sprint()),UVM_LOW)

	//`uvm_info(get_full_name(),$sformatf("cmd name in monitor %s",Instr_sent.cmd1),UVM_LOW)

	//$display("Instr data sent to Sb");
	
endfunction



endclass
