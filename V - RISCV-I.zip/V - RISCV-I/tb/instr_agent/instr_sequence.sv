class instr_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(instr_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="instr_sequence");
		super.new(name);
	endfunction

	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");
	
		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==I_type;command ==addi ; rs1==0; rd==0; ms_riscv32_mp_imaddr_out[11:0] ==12'd0; funct3==3'b000; opcode ==7'b0010011;funct7==32;});
			`uvm_info(get_type_name(),"I_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10s;

		//////addi logic /////////
		
		this.reg_block_h.reg_file.write(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
/*

		start_item(req);
		assert(req.randomize() with{inst_type==I_type; command == sltiu; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b011; opcode ==7'b0010011;funct7==32;});
		`uvm_info(get_type_name(),"I_type instruction 2nd nop ",UVM_LOW)
		finish_item(req);*/
	

//ADDI
   		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for addi sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == addi; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b000; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
  		finish_item(req);
   		//`uvm_info(get_full_name, "addi_Sequence is completed", UVM_NONE);
		#100;
//XORI
 		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for xori sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == xori; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b100; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "xori_Sequence is completed", UVM_NONE);
		//#100;


//ORI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for ori sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == ori; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b110; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "ori_Sequence is completed", UVM_NONE);
		//#100;
//ANDI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for andi sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == andi; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b111; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
  	 	finish_item(req);
   		//`uvm_info(get_full_name, "andi_Sequence is completed", UVM_NONE);
		//#100;
//SLLI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for slli sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == slli; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b001; opcode ==7'b0010011;funct7==7'd0;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "slli_Sequence is completed", UVM_NONE);
		//#100;

//SRLI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for srli sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == srli; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b101; opcode ==7'b0010011;funct7==7'd0;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "srli_Sequence is completed", UVM_NONE);
		//#100;

//SRAI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for srai sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == srai; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b101; opcode ==7'b0010011;funct7==7'd32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "srai_Sequence is completed", UVM_NONE);
		//#100;
//SLTI
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for slti sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == slti; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b010; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
		 finish_item(req);
   		//`uvm_info(get_full_name, "slti_Sequence is completed", UVM_NONE);
		//#100;
//SLTIU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has been for sltui sequence"), UVM_NONE);
		assert(req.randomize() with{inst_type==I_type; command == sltiu; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value;rs1== env_cfg.rs1; rd==env_cfg.rd; funct3==3'b011; opcode ==7'b0010011;funct7==32;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "sltui_Sequence is completed", UVM_NONE);
		//#100;

		repeat(env_cfg.nop)
		begin		
			start_item(req);
			assert(req.randomize() with {inst_type==I_type;command == sltiu; rs1==0; rd==0; ms_riscv32_mp_imaddr_out[11:0] ==12'd0; funct3==3'b011; opcode ==7'b0010011;funct7==32;});
			`uvm_info(get_type_name(),"I_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end
			
	endtask

endclass

class r_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(r_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="r_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==R_type;command ==nop ; rs1==0; rs2==0;rd==0; funct3==3'b000; opcode ==7'b0110011;});
			`uvm_info(get_type_name(),$sformatf("R_type instruction 1st nop %s",req.sprint),UVM_LOW)
			finish_item(req);
		end

		this.reg_block_h.reg_file.write(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));

		this.reg_block_h.reg_file.write(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		#100;
//ADD
   		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
  	 	assert(req.randomize()with {inst_type==R_type;command==add; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b000; opcode == 'b0110011;});
  		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, $sformatf("add_Sequence is completed %s",req.sprint), UVM_NONE);


//SUB
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==sub; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b000; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "sub_Sequence is completed", UVM_NONE);

//XOR
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==xor_op; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b100; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "xor_Sequence is completed", UVM_NONE);

//OR	
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==or_op; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b110; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "or_Sequence is completed", UVM_NONE);

//AND
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==and_op; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b111; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "and_Sequence is completed", UVM_NONE);

//SLL
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==sll; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b001; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "sll_Sequence is completed", UVM_NONE);

//SRL
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==srl; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b101; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "srl_Sequence is completed", UVM_NONE);

//SRA
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==sra; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b101; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "sra_Sequence is completed", UVM_NONE);

//SLT
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
  		assert(req.randomize()with {inst_type==R_type;command==slt; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b010; opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
  		finish_item(req);
   		//`uvm_info(get_full_name, "slt_Sequence is completed", UVM_NONE);

//SLTU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==R_type;command==sltu; rs2==env_cfg.rs2; rs1 == env_cfg.rs1; rd == env_cfg.rd; funct3==3'b011;opcode == 'b0110011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "sltu_Sequence is completed", UVM_NONE);

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==R_type;command ==add ; rs1==0; rd==0; funct3==3'b000; opcode ==7'b0110011;});
			`uvm_info(get_type_name(),"R_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass	
	

class l_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(l_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="l_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==I_type;command ==lb ; ms_riscv32_mp_imaddr_out==12'd0;rs1==0; rd==0;funct3==3'b000; opcode ==7'b0000011;});
			`uvm_info(get_type_name(),"L_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10ns;
		this.reg_block_h.reg_file.write(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));


//LB
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==I_type;command==lb; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b000; opcode == 'b0000011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;
//LH
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==I_type;command==lh; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b001; opcode == 'b0000011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;
//LW
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==I_type;command==lw; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b010; opcode == 'b0000011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;
//LBU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
  		assert(req.randomize()with {inst_type==I_type;command==lbu; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs1 == env_cfg.rs1; rd == env_cfg.rd;funct3==3'b100; opcode == 'b0000011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
  		finish_item(req);
   		//`uvm_info(get_full_name, "lbu_Sequence is completed", UVM_NONE);
		//#10ns;
//LHU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==I_type;command==lhu;ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs1 == env_cfg.rs1; rd == env_cfg.rd; funct3==3'b101;opcode == 'b0000011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lhu_Sequence is completed", UVM_NONE);
		//#10ns;
		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==I_type;command ==lh ;ms_riscv32_mp_imaddr_out==12'd0; rs1==0; rd==0;funct3==3'b001; opcode ==7'b0000011;});
			`uvm_info(get_type_name(),"L_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass




class s_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(s_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="s_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==S_type;command ==sb ; ms_riscv32_mp_imaddr_out==12'd0;rs1==0;rs2==0; rd==env_cfg.imm_temp_value[4:0];funct3==3'b000; opcode ==7'b0100011;});
			`uvm_info(get_type_name(),"L_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10ns;
		this.reg_block_h.reg_file.write(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));

		this.reg_block_h.reg_file.write(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));


//SB
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==S_type;command==sb; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == env_cfg.imm_temp_value[4:0];funct3==3'b000; opcode == 'b0100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;

//SH
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==S_type;command==sh; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == env_cfg.imm_temp_value[4:0];funct3==3'b001; opcode == 'b0100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;

//SW
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==S_type;command==sw; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == env_cfg.imm_temp_value[4:0];funct3==3'b010; opcode == 'b0100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==S_type;command ==sb ; ms_riscv32_mp_imaddr_out==12'd0;rs1==0;rs2==0; rd==env_cfg.imm_temp_value[4:0];funct3==3'b000; opcode ==7'b0100011;});
			`uvm_info(get_type_name(),"L_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass



class b_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(b_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="b_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==B_type;command==beq ; ms_riscv32_mp_imaddr_out==32'd0;rs1==0;rs2==0; rd==0;funct3==3'b000; opcode ==7'b1100011;});
			`uvm_info(get_type_name(),"B_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10ns;
		this.reg_block_h.reg_file.write(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs1,env_cfg.data1,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));

		this.reg_block_h.reg_file.write(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));
		this.reg_block_h.reg_file.read(status,env_cfg.rs2,env_cfg.data2,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map),.parent(this));


//BEQ
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==beq; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b000; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;

//BNE
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==bne; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b001; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lh_Sequence is completed", UVM_NONE);
		//#10ns;

//BLT
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==blt; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b100; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;

//BGE
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==bge; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b101; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;

//BLTU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==bltu; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b110; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;

//BGEU
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==B_type;command==bgeu; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rs2 == env_cfg.rs2; rs1 == env_cfg.rs1;rd == {env_cfg.imm_temp_value[4:1],env_cfg.imm_temp_value[11]};funct3==3'b111; opcode == 'b1100011;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lw_Sequence is completed", UVM_NONE);
		//#10ns;


		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==B_type;command ==beq ; ms_riscv32_mp_imaddr_out==12'd0;rs1==0;rs2==0; rd==0;funct3==3'b000; opcode ==7'b1100011;});
			`uvm_info(get_type_name(),"b_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass



class u_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(u_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="u_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==U_type;command==lui ; ms_riscv32_mp_imaddr_out==32'd0; rd==0; opcode ==7'b0110111;});
			`uvm_info(get_type_name(),"U_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10ns;


//LUI		
		
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==U_type;command==lui; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rd == env_cfg.rd;  opcode == 'b0110111;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_LOW) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "lui_Sequence is completed", UVM_NONE);
		//#10ns;
	
//AUIPC
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==U_type;command==auipc; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rd ==env_cfg.rd; opcode == 'b0010111;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "luipc_Sequence is completed", UVM_NONE);
		//#10ns;

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==U_type;command==lui ; ms_riscv32_mp_imaddr_out==32'd0; rd==0; opcode ==7'b0110111;});
			`uvm_info(get_type_name(),"b_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass



class j_type_sequence extends uvm_sequence#(instr_trans);

	`uvm_object_utils(j_type_sequence)

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;

	env_config env_cfg;

	uvm_status_e status;

	function new(string name="j_type_sequence");
		super.new(name);
	endfunction


	task body();
		req=instr_trans::type_id::create("req");
		
		if(!uvm_config_db#(env_config)::get(null,get_full_name(),"m_cfg",env_cfg))
			`uvm_fatal(get_type_name(),"inteface getting failed")

		reg_block_h=env_cfg.reg_block_h;
		reg_block_pc_h=env_cfg.reg_block_pc_h;

		if(!env_cfg.reg_block_pc_h)
			`uvm_fatal(get_type_name(),"env_cfg internal handles are NULL.");

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==J_type;command==jal ; ms_riscv32_mp_imaddr_out==32'd0; rd==0; opcode ==7'b1101111;});
			`uvm_info(get_type_name(),"J_type instruction 1st nop ",UVM_LOW)
			finish_item(req);
		end
		//#10ns;

//JAL		
		//repeat(4)
		begin
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==J_type;command==jal; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rd == env_cfg.rd;  opcode == 'b1101111;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_LOW) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "jal_Sequence is completed", UVM_NONE);
		//#10ns;
		end
	
//JALR
		//repeat(4)
		begin
		start_item(req);
   		//`uvm_info(get_type_name, $sformatf("request has come form %s", get_full_name()), UVM_NONE);
   		assert(req.randomize()with {inst_type==I_type;command==jalr; ms_riscv32_mp_imaddr_out==env_cfg.imm_temp_value; rd ==env_cfg.rd;funct3==3'b000;rs1==env_cfg.rs1; opcode == 'b1100111;});
   		`uvm_info("EXTENDED-SEQUENCE",$sformatf("printing from SEQUENCE \n %s", req.sprint()),UVM_HIGH) 
   		finish_item(req);
   		//`uvm_info(get_full_name, "jalr_Sequence is completed", UVM_NONE);
		//#10ns;
		end

		repeat(env_cfg.nop)
		begin
			start_item(req);
			assert(req.randomize() with {inst_type==J_type;command==jal ; ms_riscv32_mp_imaddr_out==32'd0; rd==0; opcode ==7'b1101111;});
			`uvm_info(get_type_name(),"J_type instruction 2nd nop ",UVM_LOW)
			finish_item(req);
		end

	endtask

endclass