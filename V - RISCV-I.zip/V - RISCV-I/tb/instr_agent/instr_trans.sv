class instr_trans extends uvm_sequence_item;

	`uvm_object_utils(instr_trans)

  	rand logic [31:0] ms_riscv32_mp_instr_in;
    	rand logic ms_riscv32_mp_instr_hready_in;

	typedef enum{R_type,I_type,B_type,S_type,U_type,J_type}instr_type;

    typedef enum {
        add = 0, sub, xor_op, or_op, and_op, sll, srl, sra, slt, sltu,
        addi = 10, xori, ori, andi, slli, srli, srai, slti, sltiu,
        lb = 19, lh, lw, lbu, lhu,
        sb = 24, sh, sw,
        beq = 27, bne, blt, bge, bltu, bgeu,
        jal = 33, jalr,
        lui = 35, auipc,
        ecall = 37, ebreak
    }cmd_type;

	rand instr_type inst_type;
	rand cmd_type command;
	bit [31:0]instruction;
	bit nop;
	int instr_addr;
	int instr_addr_next;
	rand bit[6:0]opcode,funct7;
	rand bit[4:0]rd,rs1,rs2;
	rand bit[2:0]funct3;
	rand bit[31:0]ms_riscv32_mp_imaddr_out;
	cmdd cmd;
	

    	constraint instr_type_cnt{if (int'(command) <= 9)
            				inst_type == R_type;
        			  else if (int'(command) inside {[10:23], 34, 37, 38})
            				inst_type == I_type;
        			  else if (int'(command) >= 24 && int'(command) <= 26)
           				inst_type == S_type;
        		  	  else if (int'(command) >= 27 && int'(command) <= 32)
            				inst_type == B_type;
        			  else if (int'(command) == 33)
            				inst_type == J_type;
        			  else if (int'(command) == 35 || int'(command) == 36)
            				inst_type == U_type;}

    	constraint funct3_value {if(command inside {add, addi, sub, lb, sb, beq, jalr, ecall, ebreak})
            				funct3 == 3'b000;
        			 else if (command inside {sll, slli, lh, sh, bne})
            				funct3 == 3'b001;
        			 else if (command inside {slt, slti, lw, sw})
            				funct3 == 3'b010;
        			 else if (command inside {sltu, sltiu})
            				funct3 == 3'b011;
        			 else if (command inside {xor_op, xori, lbu, blt})
            				funct3 == 3'b100;
        			 else if (command inside {srl, sra, srli, srai, lhu, bge})
            				funct3 == 3'b101;
        			 else if (command inside {or_op, ori, bltu})
            				funct3 == 3'b110;
        			else if (command inside {and_op, andi, bgeu})
            				funct3 == 3'b111;}

    constraint funct7_value {if (command inside {add, sll, slt, xor_op, or_op, and_op, srl, sltu})
            			funct7 == 7'h00;
        		    else if (command inside {sub, sra})
            			funct7 == 7'h20;}

    constraint opcode_value {if (inst_type == R_type)
            			opcode == 7'b0110011;
        		    else if (inst_type == I_type)
            			opcode inside {7'b0010011, 7'b0000011, 7'b1100111, 7'b1110011};
        		    else if (inst_type == S_type)
            			opcode == 7'b0100011;
        		    else if (inst_type == B_type)
            			opcode == 7'b1100011;
        		    else if (inst_type == U_type)
            			opcode inside {7'b0110111, 7'b0010111};
        		    else if (inst_type == J_type)
            			opcode == 7'b1101111;}

    function void post_randomize();
        if (inst_type == R_type)
            instruction = {funct7, rs2, rs1, funct3, rd, opcode};
        else if (inst_type == I_type) begin
            if (command inside {slli, srli, srai})
                instruction = {funct7, ms_riscv32_mp_imaddr_out[4:0], rs1, funct3, rd, opcode};
            else
                instruction = {ms_riscv32_mp_imaddr_out[11:0], rs1, funct3, rd, opcode};
        end
        else if (inst_type == S_type)
            instruction = {ms_riscv32_mp_imaddr_out[11:5], rs2, rs1, funct3, ms_riscv32_mp_imaddr_out[4:0], opcode};
        else if (inst_type == B_type)
            instruction = {ms_riscv32_mp_imaddr_out[12], ms_riscv32_mp_imaddr_out[10:5], rs2, rs1, funct3, ms_riscv32_mp_imaddr_out[4:1], ms_riscv32_mp_imaddr_out[11], opcode};
        else if (inst_type == U_type)
            instruction = {ms_riscv32_mp_imaddr_out[31:12], rd, opcode};
        else if (inst_type == J_type)
            instruction = {ms_riscv32_mp_imaddr_out[20], ms_riscv32_mp_imaddr_out[10:1], ms_riscv32_mp_imaddr_out[11], ms_riscv32_mp_imaddr_out[19:12], rd, opcode};
    endfunction
	


	function new(string name="instr_trans");
		super.new(name);
	endfunction


	function void do_print(uvm_printer printer);
        

        printer.print_field("ms_riscv32_mp_imaddr_out", this.ms_riscv32_mp_imaddr_out, 32, UVM_DEC);
        printer.print_field("ms_riscv32_mp_instr_in", this.ms_riscv32_mp_instr_in, 32, UVM_DEC);
        printer.print_field("ms_riscv32_mp_instr_hready_in", this.ms_riscv32_mp_instr_hready_in, 1, UVM_DEC);
        printer.print_field("instruction", this.instruction, 32, UVM_DEC);
        printer.print_field("nop", this.nop, 1, UVM_DEC);
        printer.print_field("opcode", this.opcode, 7, UVM_BIN);
        printer.print_field("instr_addr", this.instr_addr, 32, UVM_DEC);
        printer.print_field("instr_addr_next", this.instr_addr_next, 32, UVM_DEC);
        printer.print_field("funct7", this.funct7, 7, UVM_DEC);
        printer.print_field("rd", this.rd, 5, UVM_DEC);
        printer.print_field("rs1", this.rs1, 5, UVM_DEC);
        printer.print_field("rs2", this.rs2, 5, UVM_DEC);
        printer.print_field("funct3", this.funct3, 3, UVM_DEC);
	printer.print_generic("cmdd","cmd",$bits(cmd),cmd.name);
	printer.print_generic("cmd","command",$bits(command),command.name);


       // printer.print_field("ms_riscv32_mp_imaddr_out", this.ms_riscv32_mp_imaddr_out, 32, UVM_DEC);
    endfunction


endclass
