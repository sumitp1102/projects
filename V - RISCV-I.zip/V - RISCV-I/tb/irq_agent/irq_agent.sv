class irq_agent extends uvm_agent;

	`uvm_component_utils(irq_agent)

	irq_driver drvh;
	irq_monitor monh;
	irq_sequencer seqrh;
	irq_config m_cfg;

	function new(string name="irq_agent",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(irq_config)::get(this,"","irq_config",m_cfg))
			`uvm_fatal("irq_agent","configuration getting failed")


		monh=irq_monitor::type_id::create("monh",this);

		if(m_cfg.is_active)
		begin
			drvh=irq_driver::type_id::create("drvh",this);
			seqrh=irq_sequencer::type_id::create("seqrh",this);
		end

	endfunction

	function void connect_phase(uvm_phase phase);	
		if(m_cfg.is_active)
			drvh.seq_item_port.connect(seqrh.seq_item_export);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
	//	uvm_top.print_topology;
	endfunction

endclass
