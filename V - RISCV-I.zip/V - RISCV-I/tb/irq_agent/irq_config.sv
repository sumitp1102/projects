class irq_config extends uvm_object;

	`uvm_object_utils(irq_config)

	uvm_active_passive_enum is_active;

	virtual msrv32_irq_if vif;

	function new(string name="irq_config");
		super.new(name);
	endfunction

endclass
