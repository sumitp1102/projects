class irq_driver extends uvm_driver#(irq_trans);

	`uvm_component_utils(irq_driver)

	function new(string name="irq_driver",uvm_component parent);
		super.new(name,parent);
	endfunction

endclass