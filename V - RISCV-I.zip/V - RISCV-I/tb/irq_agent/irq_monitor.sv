class irq_monitor extends uvm_monitor;

	`uvm_component_utils(irq_monitor)
	uvm_analysis_port#(irq_trans) analysis_port;


	function new(string name="irq_monitor",uvm_component parent);
		super.new(name,parent);
		analysis_port=new("analysis_port",this);

	endfunction

endclass
