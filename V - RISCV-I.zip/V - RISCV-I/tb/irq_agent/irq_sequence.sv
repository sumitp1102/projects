class irq_sequence extends uvm_sequence#(irq_trans);

	`uvm_object_utils(irq_sequence)

	function new(string name="irq_sequence");
		super.new(name);
	endfunction

endclass