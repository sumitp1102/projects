class irq_sequencer extends uvm_sequencer#(irq_trans);

	`uvm_component_utils(irq_sequencer)

	function new(string name="irq_sequencer",uvm_component parent);
		super.new(name,parent);
	endfunction

endclass