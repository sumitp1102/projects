class irq_trans extends uvm_sequence_item;

	`uvm_object_utils(irq_trans)

	function new(string name="irq_trans");
		super.new(name);
	endfunction
endclass