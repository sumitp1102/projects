class rst_agent extends uvm_agent;

	`uvm_component_utils(rst_agent)

	rst_driver drvh;
	rst_monitor monh;
	rst_sequencer seqrh;
	rst_config m_cfg;

	function new(string name="rst_agent",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(rst_config)::get(this,"","rst_config",m_cfg))
			`uvm_fatal("rst_agent","configuration getting failed")


		monh=rst_monitor::type_id::create("monh",this);

		if(m_cfg.is_active)
		begin
			drvh=rst_driver::type_id::create("drvh",this);
			seqrh=rst_sequencer::type_id::create("seqrh",this);
		end

	endfunction

	function void connect_phase(uvm_phase phase);
		if(m_cfg.is_active)
			drvh.seq_item_port.connect(seqrh.seq_item_export);

	endfunction



endclass
