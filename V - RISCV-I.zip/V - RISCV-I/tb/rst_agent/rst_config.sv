class rst_config extends uvm_object;

	`uvm_object_utils(rst_config)

	uvm_active_passive_enum is_active;

	virtual msrv32_rst_if vif;

	function new(string name="rst_config");
		super.new(name);
	endfunction

endclass
