class rst_driver extends uvm_driver#(rst_trans);

	`uvm_component_utils(rst_driver)

	virtual msrv32_rst_if.DRV_MP vif;

	rst_config m_cfg;

	function new(string name="rst_driver",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(rst_config)::get(this,"","rst_config",m_cfg))
			`uvm_fatal("rst_driver","configaration getting failed")

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=m_cfg.vif;
	endfunction	

	task run_phase(uvm_phase phase);
		forever
		begin
			seq_item_port.get_next_item(req);
			send_to_dut(req);
			seq_item_port.item_done();
		end
		//`uvm_info(get_type_name(),"I am in reset driver",UVM_LOW)

	endtask

	task send_to_dut(rst_trans rst_xtn);
		`uvm_info(get_type_name(),$sformatf("driver data %s",rst_xtn.sprint),UVM_LOW)	

		@(vif.drv_cb);
		if(rst_xtn.mp_rst_in==1'b1)
		vif.drv_cb.mp_rst_in <= rst_xtn.mp_rst_in;
		vif.drv_cb.mp_rc_in <= rst_xtn.mp_rc_in;



		repeat(2)
		@(vif.drv_cb);



		vif.drv_cb.mp_rst_in <= 1'b0;

	endtask

endclass
