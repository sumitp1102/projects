class rst_monitor extends uvm_monitor;

	`uvm_component_utils(rst_monitor)

	virtual msrv32_rst_if.MON_MP vif;

	rst_config m_cfg;

	rst_trans rst_xtn;

	uvm_analysis_port#(rst_trans) analysis_port;

	function new(string name="rst_monitor",uvm_component parent);
		super.new(name,parent);
		analysis_port=new("analysis_port",this);

	endfunction

	function void build_phase(uvm_phase phase);
		if(!uvm_config_db#(rst_config)::get(this," ","rst_config",m_cfg))
			`uvm_fatal("rst_monitor","configaration getting failed")

	endfunction

	function void connect_phase(uvm_phase phase);
		vif=m_cfg.vif;
	endfunction


	task run_phase(uvm_phase phase);
		forever
		begin
			collect_data;
			//`uvm_info(get_type_name(),"I am in reset monitor",UVM_LOW)

		end
	endtask

	task collect_data;
		rst_xtn=rst_trans::type_id::create("rst_xtn");
		if(vif.mon_cb.mp_rst_in==1'b1)
		begin
			rst_xtn.mp_rst_in=vif.mon_cb.mp_rst_in;
			rst_xtn.mp_rc_in=vif.mon_cb.mp_rc_in;
			`uvm_info(get_type_name(),$sformatf("monitor data %s",rst_xtn.sprint),UVM_LOW)
			analysis_port.write(rst_xtn);
	

		end/*
		else
		begin
			rst_xtn.mp_rst_in=0;
			analysis_port.write(rst_xtn);
		end*/

	
		repeat(2)
		@(vif.mon_cb);
	
	endtask
endclass
