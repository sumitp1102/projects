class rst_sequence extends uvm_sequence#(rst_trans);

	`uvm_object_utils(rst_sequence)

	function new(string name="rst_sequence");
		super.new(name);
	endfunction



endclass

class reset_dut extends rst_sequence;

	`uvm_object_utils(reset_dut)

	function new(string name="reset_dut");
		super.new(name);
	endfunction

	task body;
		req=rst_trans::type_id::create("req");
		start_item(req);
		assert(req.randomize() with {mp_rst_in==1'b1;});
		finish_item(req);
		//`uvm_info(get_type_name(),"I am in reset sequence",UVM_LOW)


	endtask

endclass


	
