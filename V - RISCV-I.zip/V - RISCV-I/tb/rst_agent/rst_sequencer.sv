class rst_sequencer extends uvm_sequencer#(rst_trans);

	`uvm_component_utils(rst_sequencer)

	function new(string name="rst_sequencer",uvm_component parent);
		super.new(name,parent);
	endfunction

endclass