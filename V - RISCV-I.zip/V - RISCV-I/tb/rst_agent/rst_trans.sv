class rst_trans extends uvm_sequence_item;

	`uvm_object_utils(rst_trans)

	rand bit mp_rst_in;
	rand bit[63:0] mp_rc_in;

	//bit rst;

	constraint a1{mp_rc_in<100;}

	function new(string name="rst_trans");
		super.new(name);
	endfunction

	function void do_print(uvm_printer printer);
        super.do_print(printer);

        printer.print_field("mp_rst_in", this.mp_rst_in, 1, UVM_DEC);
        printer.print_field("mp_rc_in", this.mp_rc_in, 64, UVM_HEX);
       // printer.print_field("rst", this.rst, 1, UVM_DEC);


	endfunction


endclass
