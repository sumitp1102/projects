/*********************************

//File Name: msrv32_test_pkg.sv

//Description: The msrv32_test_pkg contains all the all the fileas related to design verification (i.e. processor verification).

//Version: 1.0

//Engineer:

//Email: tech_support@maven-silicon.com

//************************************/

package pkg;

   import uvm_pkg::*;

/*  typedef enum {NOP,ADD,SUB,XOR,OR,AND,SLL,SRL,SRA,SLT,SLTU,
		  ADDI,XORI,ORI,ANDI,SLLI,SRLI,SRAI,SLTI,SLTIU,
		  LB,LH,LW,LBU,LHU,SB,SH,SW,BEQ,BNE,BLT,BGE,BLTU,BGEU,JAL,JALR,LUI,AUIPC,ECALL,EBREAK} cmdd;*/

    typedef enum {
        nop,add , sub, xor_op, or_op, and_op, sll, srl, sra, slt, sltu,
        addi, xori, ori, andi, slli, srli, srai, slti, sltiu,
        lb , lh, lw, lbu, lhu,
        sb , sh, sw,
        beq, bne, blt, bge, bltu, bgeu,
        jal, jalr,
        lui, auipc,
        ecall , ebreak
    }cmdd;

   `include "uvm_macros.svh"
   `include "data_trans.sv"
   `include "irq_trans.sv"
   `include "rst_trans.sv"
   `include "instr_trans.sv"

   `include "data_config.sv"
   `include "rst_config.sv"
   `include "instr_config.sv"
   `include "irq_config.sv"

   `include "reg_integerfile.sv"
   `include "reg_block.sv"
   `include "internal_reg_model.sv"

   `include "env_config.sv"

   `include "data_driver.sv"
   `include "data_monitor.sv"
   `include "data_sequencer.sv"
   `include "data_agent.sv"
   `include "data_sequence.sv"

   `include "irq_driver.sv"
   `include "irq_monitor.sv"
   `include "irq_sequencer.sv"
   `include "irq_agent.sv"
   `include "irq_sequence.sv"

   `include "rst_driver.sv"
   `include "rst_monitor.sv"
   `include "rst_sequencer.sv"
   `include "rst_agent.sv"
   `include "rst_sequence.sv"
   `include "instr_sequence.sv"
   `include "instr_driver.sv"
   `include "instr_monitor.sv"
   `include "instr_sequencer.sv"
   `include "instr_agent.sv"
   `include "virtual_sequencer.sv"
   `include "virtual_sequence.sv"
   `include "ref_model.sv"
   //`include "msrv32_ral_agent.svp"

   `include "subscriber.sv"	//Instruction Subscriber
   //`include "risc_v_data_subscriber.svp"		//Data Subscriber
  // `include "risc_v_irq_subscriber.svp"		//IRQ Subscriber
   //`include "risc_v_rst_subscriber.svp"		//RST Subscriber

   `include "scoreboard.sv"
   `include "env.sv"
   `include "test.sv"


endpackage
