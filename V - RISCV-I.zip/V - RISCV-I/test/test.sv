class test extends uvm_test;

	`uvm_component_utils(test)

	env envh;

	env_config m_cfg;
	data_config d_cfg[];
	instr_config i_cfg[];
	rst_config r_cfg[];
	irq_config int_cfg[];

	int has_data_agent=1;
	int has_instr_agent=1;
	int has_rst_agent=1;
	int has_irq_agent=0;

	
	int no_of_data_agents=2;
	int no_of_instr_agents=2;
	int no_of_rst_agents=2;
	int no_of_irq_agents=0;

	uvm_status_e status,status2;

	reg_block reg_block_h;
	reg_block_for_pc reg_block_pc_h;
	int a=144,b,c=23,d;	

	function new(string name="test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		m_cfg=env_config::type_id::create("m_cfg");
		m_cfg.d_cfg=new[no_of_data_agents];
		m_cfg.i_cfg=new[no_of_instr_agents];
		m_cfg.r_cfg=new[no_of_rst_agents];
		m_cfg.int_cfg=new[no_of_irq_agents];

		d_cfg=new[no_of_data_agents];
		i_cfg=new[no_of_instr_agents];
		r_cfg=new[no_of_rst_agents];
		int_cfg=new[no_of_irq_agents];

		foreach(d_cfg[i])
			d_cfg[i]=data_config::type_id::create($sformatf("d_cfg[%0d]",i));
		foreach(i_cfg[i])
			i_cfg[i]=instr_config::type_id::create($sformatf("i_cfg[%0d]",i));
		foreach(r_cfg[i])
			r_cfg[i]=rst_config::type_id::create($sformatf("r_cfg[%0d]",i));
		foreach(int_cfg[i])
			int_cfg[i]=irq_config::type_id::create($sformatf("int_cfg[%0d]",i));

		foreach(d_cfg[i])
			d_cfg[i].is_active=UVM_ACTIVE;
		foreach(i_cfg[i])
			i_cfg[i].is_active=UVM_ACTIVE;
		foreach(r_cfg[i])
			r_cfg[i].is_active=UVM_ACTIVE;
		foreach(int_cfg[i])
			int_cfg[i].is_active=UVM_ACTIVE;


		foreach(i_cfg[i])
			if(!uvm_config_db#(virtual msrv32_ahb_instr_if)::get(this,"",$sformatf("instr_vif[%0d]",i),i_cfg[i].vif))
				`uvm_fatal("test","interface getting failed")
		foreach(d_cfg[i])
			if(!uvm_config_db#(virtual msrv32_ahb_data_if)::get(this,"",$sformatf("data_vif[%0d]",i),d_cfg[i].vif))
				`uvm_fatal("test","interface getting failed")
		foreach(r_cfg[i])
			if(!uvm_config_db#(virtual msrv32_rst_if)::get(this,"",$sformatf("rst_vif[%0d]",i),r_cfg[i].vif))
				`uvm_fatal("test","interface getting failed")
		foreach(int_cfg[i])
			if(!uvm_config_db#(virtual msrv32_irq_if)::get(this,"",$sformatf("irq_vif[%0d]",i),int_cfg[i].vif))
				`uvm_fatal("test","interface getting failed")

		m_cfg.no_of_data_agents=no_of_data_agents;
		m_cfg.no_of_instr_agents=no_of_instr_agents;
		m_cfg.no_of_rst_agents=no_of_rst_agents;
		m_cfg.no_of_irq_agents=no_of_irq_agents;

		m_cfg.has_data_agent=has_data_agent;
		m_cfg.has_instr_agent=has_instr_agent;
		m_cfg.has_rst_agent=has_rst_agent;
		m_cfg.has_irq_agent=has_irq_agent;

		foreach(d_cfg[i])
			m_cfg.d_cfg[i]=d_cfg[i];
		foreach(i_cfg[i])
			m_cfg.i_cfg[i]=i_cfg[i];
		foreach(r_cfg[i])
			m_cfg.r_cfg[i]=r_cfg[i];
		foreach(int_cfg[i])
			m_cfg.int_cfg[i]=int_cfg[i];

		reg_block_h=reg_block::type_id::create("reg_block_h");
		reg_block_h.build;

		reg_block_pc_h=reg_block_for_pc::type_id::create("reg_block_pc_h");
		reg_block_pc_h.build;
	
		m_cfg.reg_block_h=reg_block_h;
		m_cfg.reg_block_pc_h=reg_block_pc_h;

		uvm_config_db#(env_config)::set(this,"*","m_cfg",m_cfg);
		envh=env::type_id::create("envh",this);


	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		uvm_top.print_topology;
	endfunction

	task run_phase(uvm_phase phase);
		
		phase.raise_objection(this);
		reg_block_h.reg_file.write(status,1,a,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
		reg_block_h.reg_file.read(status,1,b,.path(UVM_BACKDOOR),.map(reg_block_h.reg_map));
		$display("the value return in the ral register is %0d",b);
		#100;
		reg_block_pc_h.pc_h.write(status2,c,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
		reg_block_pc_h.pc_h.read(status2,d,.path(UVM_BACKDOOR),.map(reg_block_pc_h.reg_map));
		$display("the value return in the ral pc is %0d",d);
/*
		reg_block_pc_h.pc_h.write(.status(status2), .value(c), .path(UVM_BACKDOOR), .map(reg_block_pc_h.reg_map));


		reg_block_pc_h.pc_h.read(.status(status2),  .value(d), .path(UVM_BACKDOOR), .map(reg_block_pc_h.reg_map));

		$display("the value return in the ral pc is %0d",d);*/

		
		phase.drop_objection(this);
	endtask


endclass


class reset_test extends test;

	`uvm_component_utils(reset_test)

	reset_seq_v vseqh;

	function new(string name="reset_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);
	

	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		vseqh=reset_seq_v::type_id::create("vseqh");
		vseqh.start(envh.vseqrh);
		#1000;
		`uvm_info(get_type_name(),"Hiii I am shivam I am in test",UVM_LOW)
		phase.drop_objection(this);
	endtask

endclass



class instr_test extends test;

	`uvm_component_utils(instr_test)

	reset_seq_v rvseqh;
	instr_seq_v ivseqh;

	function new(string name="instr_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);
	

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		ivseqh=instr_seq_v::type_id::create("ivseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		ivseqh.start(envh.vseqrh);
		#500;

		phase.drop_objection(this);
	endtask

endclass



class r_type_test extends test;

	`uvm_component_utils(r_type_test)

	reset_seq_v rvseqh;
	instr_r_seq_v Rvseqh;

	function new(string name="r_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		Rvseqh=instr_r_seq_v::type_id::create("Rvseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		Rvseqh.start(envh.vseqrh);
		//#500;

		phase.drop_objection(this);
	endtask

endclass

class l_type_test extends test;

	`uvm_component_utils(l_type_test)

	reset_seq_v rvseqh;
	instr_l_seq_v lvseqh;

	function new(string name="l_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		lvseqh=instr_l_seq_v::type_id::create("lvseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		lvseqh.start(envh.vseqrh);
		#50ns;

		phase.drop_objection(this);
	endtask

endclass


class s_type_test extends test;

	`uvm_component_utils(s_type_test)

	reset_seq_v rvseqh;
	instr_s_seq_v svseqh;

	function new(string name="s_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		svseqh=instr_s_seq_v::type_id::create("svseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		svseqh.start(envh.vseqrh);
		#50ns;

		phase.drop_objection(this);
	endtask

endclass



class b_type_test extends test;

	`uvm_component_utils(b_type_test)

	reset_seq_v rvseqh;
	instr_b_seq_v bvseqh;

	function new(string name="b_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		bvseqh=instr_b_seq_v::type_id::create("bvseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		bvseqh.start(envh.vseqrh);
		#50ns;

		phase.drop_objection(this);
	endtask

endclass


class u_type_test extends test;

	`uvm_component_utils(u_type_test)

	reset_seq_v rvseqh;
	instr_u_seq_v uvseqh;

	function new(string name="u_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		uvseqh=instr_u_seq_v::type_id::create("uvseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		uvseqh.start(envh.vseqrh);
		#50ns;

		phase.drop_objection(this);
	endtask

endclass


class j_type_test extends test;

	`uvm_component_utils(j_type_test)

	reset_seq_v rvseqh;
	instr_j_seq_v jvseqh;

	function new(string name="j_type_test",uvm_component parent);
		super.new(name,parent);
	endfunction

	function void build_phase(uvm_phase phase);
		super.build_phase(phase);

	endfunction

	function void start_of_simulation_phase(uvm_phase phase);
		super.start_of_simulation_phase(phase);
	endfunction

	task run_phase(uvm_phase phase);
		phase.raise_objection(this);
		rvseqh=reset_seq_v::type_id::create("rvseqh");
		jvseqh=instr_j_seq_v::type_id::create("jvseqh");
		rvseqh.start(envh.vseqrh);
		#100;
		jvseqh.start(envh.vseqrh);
		#50ns;

		phase.drop_objection(this);
	endtask

endclass

